<?php require_once ('header.php'); ?>

<div class="span8" style="margin-left:0px;">
	
<div class="page-header white-content">
	<h1><?=_('Listing inactive.</h1>') ?>
	<?=_('The website/domain listing page you are looking is inactive.') ?> 
	<?php echo anchor(base_url(), _('Return to home')); ?>
</div>

</div>

<?php require_once 'sidebar.php'; ?>

<?php require_once ('footer.php'); ?>