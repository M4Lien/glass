<?php require_once ('header.php'); ?>

<div class="col-xs-12 col-md-8">
	
<div class="page-header">
	<h1><?=_('Login') ?></h1>

	 <?=_('Please login using the form on right side') ?> 
	 <b class="icon-arrow-right"></b><b class="icon-arrow-right"></b><b class="icon-arrow-right"></b>
	
</div>

</div>

<?php require_once 'sidebar.php'; ?>

<?php require_once ('footer.php'); ?>