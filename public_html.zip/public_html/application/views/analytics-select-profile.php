<?php require_once ('header.php'); ?>

<div class="col-xs-12 col-md-8">

<div class="white-content">
	<h3><?=_('Analytics Data Sync') ?>.</h3>
</div>

<div class="white-content">
	<?= $output ?>
</div>

</div>

<?php require_once 'sidebar.php'; ?>

<?php require_once ('footer.php'); ?>
