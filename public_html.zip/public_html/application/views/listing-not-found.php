<?php require_once ('header.php'); ?>

<div class="span8" style="margin-left:0px;">
	
<div class="page-header">
	<h1><?=_('Listing not found.</h1>') ?>
	<?=_('The website/domain listing page you are looking for was not found.') ?> 
	<?php echo anchor(base_url(), _('Return to home')); ?>
</div>

</div>

<?php require_once 'sidebar.php'; ?>

<?php require_once ('footer.php'); ?>