<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 9th December 2014 09:26:37 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'flippa' /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 9th December 2014 09:26:37 --> Unable to connect to the database
ERROR - 9th December 2014 09:36:38 --> Query error: Table 'flippa.listings' doesn't exist
