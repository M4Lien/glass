<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 29th July 2019 00:55:31 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 02:55:37 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 05:33:50 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 07:26:18 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 09:06:46 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 09:06:57 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 10:26:57 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 17:04:12 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 17:04:53 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 17:43:42 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 18:08:53 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 20:49:55 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 20:59:13 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 23:27:34 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 29th July 2019 23:29:06 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
