<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 29th November 2012 11:57:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '="">Delete</a>'
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 1
ERROR - 29th November 2012 11:57:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '="">Delete</a>
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 1
ERROR - 29th November 2012 11:57:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<a href="">Delete</a>
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 1
ERROR - 29th November 2012 11:58:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '="">Delete</a>'
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 1
ERROR - 29th November 2012 11:58:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '="">Delete</a>' as d
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 1
ERROR - 29th November 2012 12:00:57 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/system/libraries/Table.php 353
ERROR - 29th November 2012 12:00:57 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/system/libraries/Table.php 353
ERROR - 29th November 2012 12:01:30 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/system/libraries/Table.php 353
ERROR - 29th November 2012 12:01:30 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/system/libraries/Table.php 353
ERROR - 29th November 2012 12:01:31 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/system/libraries/Table.php 353
ERROR - 29th November 2012 12:01:31 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/system/libraries/Table.php 353
ERROR - 29th November 2012 14:22:50 --> Query error: Unknown column 'expires' in 'field list'
ERROR - 29th November 2012 14:25:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '14'' at line 1
ERROR - 29th November 2012 14:28:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM_UNIXTIME(list_expires, '%D %b %Y') ELSE '-' AS list_expires, sold, sold_dat' at line 2
ERROR - 29th November 2012 14:29:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '> 0 THEN 
 FROM_UNIXTIME(list_expires, '%D %b %Y') ELSE '-' AS list_expires, sol' at line 1
ERROR - 29th November 2012 14:30:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS list_expires, sold, sold_date
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 2
ERROR - 29th November 2012 14:35:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS list_expires END, sold, sold_date
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 2
ERROR - 29th November 2012 14:37:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AS sold_date
FROM (`listings`)
WHERE `list_uID` =  '14'' at line 3
ERROR - 29th November 2012 14:38:54 --> Query error: FUNCTION flippa.NUMBER_FORMAT does not exist
ERROR - 29th November 2012 14:39:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(bin, 2 ) AS BIN, FROM_UNIXTIME(list_date, '%D %b %Y') as list_date, CASE list_e' at line 1
ERROR - 29th November 2012 14:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(bin, 2 )) AS BIN, FROM_UNIXTIME(list_date, '%D %b %Y') as list_date, CASE list_' at line 1
ERROR - 29th November 2012 14:42:00 --> Query error: Unknown column 'edit' in 'field list'
ERROR - 29th November 2012 14:42:25 --> Query error: Unknown column 'edit' in 'field list'
ERROR - 29th November 2012 14:42:31 --> Query error: Unknown column 'edit' in 'field list'
ERROR - 29th November 2012 15:02:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '('<a href="/users/goedit/', listingID, '">Edit</a>')
FROM (`listings`)
WHERE `li' at line 5
ERROR - 29th November 2012 15:04:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '< NOW() THEN 
 CONCAT('<a href="/payments/relist/', listingID, '">Relist</a>') E' at line 3
ERROR - 29th November 2012 15:07:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '> 0 THEN 
 CONCAT('<a href="/payments/relist/', listingID, '">Relist</a>') ELSE ' at line 3
ERROR - 29th November 2012 21:11:33 --> Severity: Notice  --> Undefined variable: l /Users/crivion/www/flippa/application/controllers/payments.php 32
ERROR - 29th November 2012 21:11:54 --> Severity: Notice  --> Undefined index:  sandbox /Users/crivion/www/flippa/application/libraries/CRV_PayPalClass.php 67
ERROR - 29th November 2012 21:12:47 --> Severity: Notice  --> Undefined index:  sandbox /Users/crivion/www/flippa/application/libraries/CRV_PayPalClass.php 67
ERROR - 29th November 2012 21:13:27 --> Severity: Notice  --> Undefined index:  sandbox /Users/crivion/www/flippa/application/libraries/CRV_PayPalClass.php 67
ERROR - 29th November 2012 21:21:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/payments.php:20) /Users/crivion/www/flippa/application/controllers/payments.php 37
ERROR - 29th November 2012 21:22:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/payments.php:20) /Users/crivion/www/flippa/application/controllers/payments.php 37
ERROR - 29th November 2012 21:22:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/payments.php:20) /Users/crivion/www/flippa/application/controllers/payments.php 37
ERROR - 29th November 2012 21:23:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/payments.php:20) /Users/crivion/www/flippa/application/controllers/payments.php 37
ERROR - 29th November 2012 21:35:54 --> Query error: Table 'flippa.playlists' doesn't exist
