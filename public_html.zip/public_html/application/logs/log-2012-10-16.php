<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 16th October 2012 11:42:06 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 16th October 2012 11:42:23 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
