<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 24th October 2012 12:45:45 --> Severity: Notice  --> Use of undefined constant __DIR__ - assumed '__DIR__' /Users/crivion/Desktop/localwp/application/views/watch-movies.php 2
