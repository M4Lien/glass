<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2nd February 2015 08:41:37 --> Severity: Notice  --> Undefined variable: last_bid /Users/crivion/Sites/local.flippa/application/views/websites.php 37
ERROR - 2nd February 2015 08:41:37 --> Severity: Notice  --> Undefined variable: last_bid /Users/crivion/Sites/local.flippa/application/views/websites.php 37
ERROR - 2nd February 2015 08:41:37 --> Severity: Notice  --> Undefined variable: last_bid /Users/crivion/Sites/local.flippa/application/views/websites.php 37
ERROR - 2nd February 2015 08:41:37 --> Severity: Notice  --> Undefined variable: last_bid /Users/crivion/Sites/local.flippa/application/views/websites.php 37
ERROR - 2nd February 2015 12:50:09 --> Severity: Notice  --> Undefined variable: body /Users/crivion/Sites/local.flippa/application/controllers/home.php 51
ERROR - 2nd February 2015 12:56:43 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 2nd February 2015 12:56:43 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 2nd February 2015 12:56:43 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 2nd February 2015 12:56:44 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 2nd February 2015 12:56:51 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 2nd February 2015 12:56:57 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 2nd February 2015 13:00:31 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Sites/local.flippa/application/controllers/home.php 93
ERROR - 2nd February 2015 13:00:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/crivion/Sites/local.flippa/application/controllers/home.php 93
ERROR - 2nd February 2015 13:00:38 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Sites/local.flippa/application/controllers/home.php 93
ERROR - 2nd February 2015 13:00:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/crivion/Sites/local.flippa/application/controllers/home.php 93
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$thumbnail /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$release_date /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$film_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Undefined property: mysqli_result::$filmID /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 99
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 103
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:00:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 107
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Undefined property: mysqli::$listingID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Undefined property: mysqli::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Undefined property: mysqli::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Undefined property: mysqli_result::$listingID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Undefined property: mysqli_result::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Undefined property: mysqli_result::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Undefined property: mysqli::$listingID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Undefined property: mysqli::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Undefined property: mysqli::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Undefined property: mysqli_result::$listingID /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Undefined property: mysqli_result::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Undefined property: mysqli_result::$listing_title /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 97
ERROR - 2nd February 2015 13:02:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/home.php 98
ERROR - 2nd February 2015 13:05:45 --> Query error: Not unique table/alias: 'listings'
ERROR - 2nd February 2015 13:05:45 --> Query error: Not unique table/alias: 'listings'
ERROR - 2nd February 2015 13:05:47 --> Query error: Not unique table/alias: 'listings'
ERROR - 2nd February 2015 13:05:47 --> Query error: Not unique table/alias: 'listings'
ERROR - 2nd February 2015 13:05:48 --> Query error: Not unique table/alias: 'listings'
ERROR - 2nd February 2015 13:06:12 --> Query error: Not unique table/alias: 'listings'
ERROR - 2nd February 2015 13:15:50 --> Severity: Warning  --> strtotime(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /Users/crivion/Sites/local.flippa/application/models/stats.php 29
ERROR - 2nd February 2015 13:15:50 --> Severity: Warning  --> strtotime(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /Users/crivion/Sites/local.flippa/application/models/stats.php 40
ERROR - 2nd February 2015 13:15:50 --> Severity: Warning  --> date(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. /Users/crivion/Sites/local.flippa/application/models/stats.php 40
ERROR - 2nd February 2015 05:26:14 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 2nd February 2015 05:26:14 --> Unable to connect to the database
ERROR - 2nd February 2015 05:29:23 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 705
ERROR - 2nd February 2015 05:29:23 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 706
