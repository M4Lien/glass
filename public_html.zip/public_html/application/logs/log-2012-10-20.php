<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 20th October 2012 17:28:57 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 20th October 2012 17:29:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 20th October 2012 17:46:41 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
