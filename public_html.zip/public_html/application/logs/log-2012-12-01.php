<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 1st December 2012 12:05:22 --> Query error: Unknown column '0' in 'where clause'
ERROR - 1st December 2012 12:05:42 --> Query error: Unknown column '0' in 'where clause'
ERROR - 1st December 2012 12:10:01 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/www/flippa/application/models/Stats.php 46
ERROR - 1st December 2012 12:10:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Nov'' at line 3
ERROR - 1st December 2012 12:10:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/system/core/Exceptions.php:185) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 1st December 2012 12:10:26 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/www/flippa/application/models/Stats.php 46
ERROR - 1st December 2012 12:10:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''Nov'' at line 3
ERROR - 1st December 2012 12:10:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/system/core/Exceptions.php:185) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 1st December 2012 12:11:08 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/www/flippa/application/models/Stats.php 46
ERROR - 1st December 2012 12:11:31 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/www/flippa/application/models/Stats.php 46
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 11
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 12
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 13
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 14
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 15
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 19
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 20
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 21
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 22
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 23
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 28
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 29
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 30
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 31
ERROR - 1st December 2012 13:07:23 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-websites.php 32
ERROR - 1st December 2012 13:16:53 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 76
ERROR - 1st December 2012 13:17:12 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 76
ERROR - 1st December 2012 13:17:22 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 76
ERROR - 1st December 2012 13:19:16 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 76
ERROR - 1st December 2012 13:24:11 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 82
ERROR - 1st December 2012 13:26:16 --> Query error: Unknown column 'list-type' in 'where clause'
ERROR - 1st December 2012 13:27:49 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 1st December 2012 13:38:17 --> Severity: Warning  --> require_once(sidebar-single.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory /Users/crivion/www/flippa/application/views/single-listing.php 9
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 11
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 12
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 13
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 14
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 15
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 19
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 20
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 21
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 22
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 23
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 28
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 29
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 30
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 31
ERROR - 1st December 2012 13:38:38 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/views/sidebar-single.php 32
ERROR - 1st December 2012 13:45:19 --> Query error: Unknown column 'list_status' in 'where clause'
