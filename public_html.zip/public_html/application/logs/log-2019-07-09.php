<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 9th July 2019 00:31:58 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 9th July 2019 01:32:14 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 03:58:34 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 04:05:30 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 06:31:55 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 07:56:42 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 07:56:53 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 07:57:03 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 09:19:06 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 09:19:13 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 09:32:26 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 09:42:08 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 09:42:10 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 10:20:59 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 10:56:56 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 11:16:30 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 9th July 2019 20:22:15 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
