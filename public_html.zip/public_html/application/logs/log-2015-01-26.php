<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 26th January 2015 00:09:13 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:09:13 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:09:47 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:09:47 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:16:43 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:16:43 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:17:13 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:17:13 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:17:24 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:17:24 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:17:44 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:17:44 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:17:52 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:17:52 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:18:02 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:18:02 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:18:16 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:18:16 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:18:18 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:18:18 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:18:23 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:18:23 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:18:27 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 26th January 2015 00:18:27 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 26th January 2015 00:23:32 --> Severity: Notice  --> Undefined variable: listings /Users/crivion/Sites/local.flippa/application/views/home.php 20
ERROR - 26th January 2015 00:24:14 --> Severity: Notice  --> Undefined property: Home::$Listings /Users/crivion/Sites/local.flippa/application/controllers/home.php 16
ERROR - 26th January 2015 00:25:06 --> Severity: Notice  --> Undefined property: Home::$Listings /Users/crivion/Sites/local.flippa/application/controllers/home.php 16
ERROR - 26th January 2015 00:25:07 --> Severity: Notice  --> Undefined property: Home::$Listings /Users/crivion/Sites/local.flippa/application/controllers/home.php 16
ERROR - 26th January 2015 00:25:14 --> Severity: Notice  --> Undefined property: Home::$Listings /Users/crivion/Sites/local.flippa/application/controllers/home.php 16
ERROR - 26th January 2015 00:25:31 --> Severity: Warning  --> Missing argument 1 for Listings::getNewListings(), called in /Users/crivion/Sites/local.flippa/application/controllers/home.php on line 17 and defined /Users/crivion/Sites/local.flippa/application/models/listings.php 91
ERROR - 26th January 2015 00:25:31 --> Severity: Notice  --> Undefined variable: start /Users/crivion/Sites/local.flippa/application/models/listings.php 98
