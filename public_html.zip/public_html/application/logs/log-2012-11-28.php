<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 28th November 2012 13:04:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 391
ERROR - 28th November 2012 13:08:45 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 391
ERROR - 28th November 2012 13:53:16 --> Severity: Notice  --> Undefined property: stdClass::$site_url /Users/crivion/www/flippa/application/views/newlisting.php 70
ERROR - 28th November 2012 14:10:55 --> Query error: Unknown column 'day' in 'field list'
ERROR - 28th November 2012 14:13:16 --> Query error: Unknown column 'day' in 'field list'
ERROR - 28th November 2012 14:13:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:499) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:13:56 --> Query error: Unknown column 'day' in 'field list'
ERROR - 28th November 2012 14:13:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:499) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:34:43 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:34:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:555) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:35:14 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:35:14 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:35:41 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:35:41 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:35:50 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:35:50 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:36:41 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:36:41 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:37:09 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:37:09 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:37:19 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:37:19 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:37:19 --> Severity: Notice  --> Undefined index:  monetization[] /Users/crivion/www/flippa/application/controllers/users.php 545
ERROR - 28th November 2012 14:37:34 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:37:34 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:38:26 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:38:26 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:38:35 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:38:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:555) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:38:56 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:38:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:555) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:40:13 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:40:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:40:26 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:40:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:40:26 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:40:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:24 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:51 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:51 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:53 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:53 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:54 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:54 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:54 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:55 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:55 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:42:55 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:42:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:43:13 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:43:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/users.php:558) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 28th November 2012 14:43:27 --> Query error: Unknown column '0' in 'field list'
ERROR - 28th November 2012 14:46:56 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:46:56 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:47:03 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:47:03 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:47:52 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:47:52 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 14:47:56 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 516
ERROR - 28th November 2012 14:47:56 --> Severity: Notice  --> Array to string conversion /Users/crivion/www/flippa/application/controllers/users.php 521
ERROR - 28th November 2012 15:23:37 --> Query error: Unknown column 'Array' in 'field list'
ERROR - 28th November 2012 15:23:49 --> Query error: Unknown column 'Array' in 'field list'
ERROR - 28th November 2012 15:24:05 --> Query error: Unknown column 'Array' in 'field list'
ERROR - 28th November 2012 16:41:54 --> Severity: Notice  --> Undefined variable: id /Users/crivion/www/flippa/application/controllers/users.php 733
ERROR - 28th November 2012 16:44:57 --> Query error: Unknown column 'verify_file' in 'field list'
