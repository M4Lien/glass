<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 14th July 2019 06:30:59 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 07:43:24 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 09:18:57 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 10:40:48 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 11:00:12 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 11:16:16 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 11:16:16 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 11:16:16 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 11:16:17 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 14:30:00 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 16:45:50 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 19:13:08 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 19:13:22 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 21:05:11 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 14th July 2019 21:21:10 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
