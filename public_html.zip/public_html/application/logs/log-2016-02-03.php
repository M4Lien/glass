<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 3rd February 2016 03:18:59 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 3rd February 2016 03:18:59 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 3rd February 2016 03:18:59 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/newlisting.php 41
ERROR - 3rd February 2016 03:20:20 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 3rd February 2016 03:20:20 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 3rd February 2016 03:20:20 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/newlisting.php 41
ERROR - 3rd February 2016 03:20:59 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /Users/crivion/Sites/local.flippa/application/views/single-listing.php 62
ERROR - 3rd February 2016 03:24:02 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg /Users/crivion/Sites/local.flippa/application/views/newlisting.php 259
ERROR - 3rd February 2016 03:24:31 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg /Users/crivion/Sites/local.flippa/application/views/newlisting.php 259
ERROR - 3rd February 2016 03:24:44 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg /Users/crivion/Sites/local.flippa/application/views/newlisting.php 259
ERROR - 3rd February 2016 03:25:42 --> Severity: Notice  --> Undefined property: stdClass::$traffic_avg /Users/crivion/Sites/local.flippa/application/views/newlisting.php 259
ERROR - 3rd February 2016 03:26:28 --> Severity: Notice  --> Undefined property: stdClass::$traffic_avg /Users/crivion/Sites/local.flippa/application/views/newlisting.php 233
ERROR - 3rd February 2016 03:26:46 --> Severity: Notice  --> Undefined property: stdClass::$traffic_rev_avg /Users/crivion/Sites/local.flippa/application/views/newlisting.php 233
