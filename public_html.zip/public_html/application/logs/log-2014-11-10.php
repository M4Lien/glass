<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 10th November 2014 07:54:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
AND `featured` =  'Y'
ORDER' at line 2
ERROR - 10th November 2014 07:55:15 --> Query error: No tables used
ERROR - 10th November 2014 07:55:17 --> Query error: No tables used
ERROR - 10th November 2014 07:55:18 --> Query error: No tables used
ERROR - 10th November 2014 07:58:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `featured` =  'Y'
ORDER BY `listingID` DESC
LIMIT 10' at line 5
ERROR - 10th November 2014 07:59:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `featured` =  'Y'
ORDER BY `listingID` DESC
LIMIT 10' at line 5
