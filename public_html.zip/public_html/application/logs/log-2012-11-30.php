<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 30th November 2012 17:52:31 --> Query error: Table 'flippa.active' doesn't exist
ERROR - 30th November 2012 17:52:46 --> Query error: Not unique table/alias: 'listings'
ERROR - 30th November 2012 17:52:56 --> Query error: Not unique table/alias: 'listings'
ERROR - 30th November 2012 18:23:07 --> Severity: Notice  --> Undefined variable: listings /Users/crivion/www/flippa/application/controllers/websites.php 50
ERROR - 30th November 2012 18:23:31 --> Severity: Notice  --> Undefined variable: listings /Users/crivion/www/flippa/application/controllers/websites.php 50
ERROR - 30th November 2012 18:23:31 --> Severity: Notice  --> Undefined variable: filter_title /Users/crivion/www/flippa/application/views/websites.php 8
ERROR - 30th November 2012 18:23:45 --> Severity: Notice  --> Undefined variable: filter_title /Users/crivion/www/flippa/application/views/websites.php 8
ERROR - 30th November 2012 18:24:06 --> Severity: Notice  --> Undefined variable: filter_title /Users/crivion/www/flippa/application/views/websites.php 8
ERROR - 30th November 2012 18:24:32 --> Severity: Notice  --> Undefined variable: filter_title /Users/crivion/www/flippa/application/views/websites.php 8
ERROR - 30th November 2012 18:24:33 --> Severity: Notice  --> Undefined variable: filter_title /Users/crivion/www/flippa/application/views/websites.php 8
ERROR - 30th November 2012 19:14:55 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 24
ERROR - 30th November 2012 19:14:55 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 24
ERROR - 30th November 2012 19:14:55 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 24
ERROR - 30th November 2012 19:15:53 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 24
ERROR - 30th November 2012 19:15:53 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 24
ERROR - 30th November 2012 19:15:53 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 24
ERROR - 30th November 2012 19:15:53 --> Severity: Warning  --> date() expects parameter 2 to be long, string given /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:17:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM (`listings`)
WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY ' at line 2
ERROR - 30th November 2012 19:18:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM (`listings`)
WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY ' at line 2
ERROR - 30th November 2012 19:18:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 2)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:19:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('8', FORMAT(rev_avg, 2)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:20:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, FORMAT(traffic_a' at line 1
ERROR - 30th November 2012 19:24:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, pagerank
FROM (`' at line 1
ERROR - 30th November 2012 19:25:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, CONCAT('$', FORMAT(rev_avg, 0)) as rev_avg, pagerank
FROM (`' at line 1
ERROR - 30th November 2012 19:25:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, rev_avg, pagerank
FROM (`listings`)
WHERE `listing_status` =' at line 1
ERROR - 30th November 2012 19:25:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'starting, site_age, rev_avg, pagerank
FROM (`listings`)
WHERE `listing_status` =' at line 1
ERROR - 30th November 2012 19:26:29 --> Severity: Notice  --> Undefined property: stdClass::$rev_avg /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:26:29 --> Severity: Notice  --> Undefined property: stdClass::$rev_avg /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:26:29 --> Severity: Notice  --> Undefined property: stdClass::$rev_avg /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:33:50 --> Severity: Notice  --> Undefined property: stdClass::$rev_avg /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:33:50 --> Severity: Notice  --> Undefined property: stdClass::$rev_avg /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:33:50 --> Severity: Notice  --> Undefined property: stdClass::$rev_avg /Users/crivion/www/flippa/application/views/websites.php 25
ERROR - 30th November 2012 19:34:25 --> Query error: Unknown column 'rev_ag' in 'field list'
ERROR - 30th November 2012 19:35:50 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg_visitors /Users/crivion/www/flippa/application/views/websites.php 26
ERROR - 30th November 2012 19:35:50 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg_visitors /Users/crivion/www/flippa/application/views/websites.php 26
ERROR - 30th November 2012 19:35:50 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg_visitors /Users/crivion/www/flippa/application/views/websites.php 26
ERROR - 30th November 2012 19:36:01 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg_visits /Users/crivion/www/flippa/application/views/websites.php 26
ERROR - 30th November 2012 19:36:01 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg_visits /Users/crivion/www/flippa/application/views/websites.php 26
ERROR - 30th November 2012 19:36:01 --> Severity: Notice  --> Undefined property: stdClass::$traffiv_avg_visits /Users/crivion/www/flippa/application/views/websites.php 26
