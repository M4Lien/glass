<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 22nd October 2012 17:22:48 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
