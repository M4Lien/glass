<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 24th January 2017 02:58:20 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 24th January 2017 03:01:42 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 785
ERROR - 24th January 2017 03:01:42 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 786
ERROR - 24th January 2017 03:12:20 --> Query error: Unknown column 'verify_meta' in 'field list'
ERROR - 24th January 2017 03:20:32 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 785
ERROR - 24th January 2017 03:20:32 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 786
ERROR - 24th January 2017 03:33:32 --> Severity: Notice  --> Undefined variable: progress /Users/crivion/Sites/local.flippa/application/controllers/users.php 1355
ERROR - 24th January 2017 03:33:32 --> Severity: Notice  --> Undefined variable: progress /Users/crivion/Sites/local.flippa/application/controllers/users.php 1355
ERROR - 24th January 2017 03:33:32 --> Severity: Notice  --> Undefined variable: progress /Users/crivion/Sites/local.flippa/application/controllers/users.php 1356
ERROR - 24th January 2017 03:33:32 --> Severity: Notice  --> Undefined variable: icon /Users/crivion/Sites/local.flippa/application/controllers/users.php 1357
ERROR - 24th January 2017 03:54:17 --> Query error: Unknown column 'verify_meta' in 'field list'
ERROR - 24th January 2017 03:58:35 --> Query error: Unknown column 'sbMeta' in 'field list'
ERROR - 24th January 2017 04:47:08 --> Severity: Notice  --> Undefined property: CI_Config::$currency_symbol /Users/crivion/Sites/local.flippa/application/views/newlisting.php 23
ERROR - 24th January 2017 04:47:25 --> Severity: Notice  --> Undefined property: CI_Config::$currency_symbol /Users/crivion/Sites/local.flippa/application/views/newlisting.php 23
ERROR - 24th January 2017 04:48:28 --> Severity: Notice  --> Undefined property: CI_Config::$currency_symbol /Users/crivion/Sites/local.flippa/application/views/newlisting.php 25
ERROR - 24th January 2017 04:48:42 --> Severity: Notice  --> Undefined property: CI_Config::$currency_code /Users/crivion/Sites/local.flippa/application/views/newlisting.php 25
ERROR - 24th January 2017 04:48:46 --> Severity: Notice  --> Undefined property: CI_Config::$currency_symbol /Users/crivion/Sites/local.flippa/application/views/newlisting.php 25
