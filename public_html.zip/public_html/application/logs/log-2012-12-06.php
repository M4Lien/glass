<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 6th December 2012 17:25:43 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 6th December 2012 17:37:57 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/www/flippa/application/views/single-listing.php 46
ERROR - 6th December 2012 17:37:57 --> Severity: Notice  --> Object of class stdClass to string conversion /Users/crivion/www/flippa/application/views/single-listing.php 46
ERROR - 6th December 2012 17:37:57 --> Severity: Notice  --> Undefined variable: Object /Users/crivion/www/flippa/application/views/single-listing.php 46
ERROR - 6th December 2012 17:39:30 --> Severity: Notice  --> Undefined variable: comments /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 6th December 2012 17:59:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-1, 10' at line 6
ERROR - 6th December 2012 18:09:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:09:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:10:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:11:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:11:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:11:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:11:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:11:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:11:53 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 100
ERROR - 6th December 2012 18:12:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:12:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:12:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:12:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:12:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:13:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:13:45 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 100
ERROR - 6th December 2012 18:13:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:14:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:14:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:15:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `list_expires` ASC' at line 2
ERROR - 6th December 2012 18:16:03 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:17:13 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:17:26 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:19:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:20:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:21:09 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:24:16 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:24:28 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:24:35 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:24:38 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:24:40 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:24:59 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:36:47 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:36:50 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 98
ERROR - 6th December 2012 18:37:11 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/controllers/websites.php 99
ERROR - 6th December 2012 18:37:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `listing_status` =  'active'
AND `sold` =  'N'
ORDER BY `listingID` DESC
L' at line 2
ERROR - 6th December 2012 18:38:22 --> Query error: Not unique table/alias: 'listings'
ERROR - 6th December 2012 18:39:02 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string /Users/crivion/www/flippa/application/controllers/websites.php 99
ERROR - 6th December 2012 18:39:08 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string /Users/crivion/www/flippa/application/controllers/websites.php 99
ERROR - 6th December 2012 18:47:58 --> Severity: Notice  --> Undefined variable: total_items /Users/crivion/www/flippa/application/views/websites.php 42
ERROR - 6th December 2012 18:49:00 --> Severity: Notice  --> Undefined variable: total_pages /Users/crivion/www/flippa/application/views/websites.php 42
ERROR - 6th December 2012 19:23:53 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 6th December 2012 19:24:15 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 6th December 2012 19:28:53 --> Query error: Unknown column 'amount' in 'field list'
ERROR - 6th December 2012 19:31:37 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 6th December 2012 19:31:49 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 6th December 2012 19:32:11 --> Query error: Table 'flippa.genres' doesn't exist
