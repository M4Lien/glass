<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 3rd November 2012 14:05:41 --> You did not select a file to upload.
ERROR - 3rd November 2012 14:08:51 --> You did not select a file to upload.
ERROR - 3rd November 2012 14:16:04 --> Severity: Notice  --> Undefined offset:  0 /Users/crivion/Desktop/localwp/application/views/admin-links.php 8
ERROR - 3rd November 2012 14:16:04 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/admin-links.php 8
ERROR - 3rd November 2012 14:17:16 --> Severity: Notice  --> Undefined variable: movie_info /Users/crivion/Desktop/localwp/application/views/admin-links.php 12
ERROR - 3rd November 2012 14:17:16 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/admin-links.php 12
ERROR - 3rd November 2012 14:42:07 --> Severity: Notice  --> Undefined variable: users /Users/crivion/Desktop/localwp/application/views/admin-users.php 12
ERROR - 3rd November 2012 14:43:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1
ERROR - 3rd November 2012 14:43:44 --> Query error: Unknown table 'users'
ERROR - 3rd November 2012 14:43:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT COUNT(*) as tUsers FROM users) as tUsers' at line 1
ERROR - 3rd November 2012 14:43:59 --> Query error: Unknown table 'users'
ERROR - 3rd November 2012 14:44:44 --> Severity: Notice  --> Undefined variable: users /Users/crivion/Desktop/localwp/application/views/admin-users.php 12
ERROR - 3rd November 2012 14:44:54 --> Severity: Notice  --> Undefined variable: userss /Users/crivion/Desktop/localwp/application/views/admin-users.php 13
ERROR - 3rd November 2012 14:51:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/user-account.php 6
ERROR - 3rd November 2012 14:51:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/user-account.php 16
ERROR - 3rd November 2012 14:51:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/user-account.php 23
ERROR - 3rd November 2012 14:51:21 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/user-account.php 35
ERROR - 3rd November 2012 15:02:35 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, array given /Users/crivion/Desktop/localwp/system/database/DB_active_rec.php 331
ERROR - 3rd November 2012 15:02:35 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, array given /Users/crivion/Desktop/localwp/system/database/DB_active_rec.php 331
ERROR - 3rd November 2012 15:02:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT COUNT(*) as tComments FROM comments) as tComments
FROM (`comments`)
LEFT ' at line 2
ERROR - 3rd November 2012 15:02:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 3rd November 2012 15:03:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT COUNT(*) as tComments FROM comments) as tComments
FROM (`comments`)
LEFT ' at line 2
ERROR - 3rd November 2012 15:03:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT COUNT(*) as tComments FROM comments) as tComments
FROM (`comments`)
LEFT ' at line 2
ERROR - 3rd November 2012 15:03:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'SELECT COUNT(*) as tComments FROM comments) as tComments
FROM (`comments`)
LEFT ' at line 2
ERROR - 3rd November 2012 15:04:13 --> Query error: Unknown column 'movies.title' in 'field list'
ERROR - 3rd November 2012 15:04:19 --> Severity: Notice  --> Undefined variable: commnets /Users/crivion/Desktop/localwp/application/controllers/Admin.php 317
ERROR - 3rd November 2012 15:04:31 --> Severity: Notice  --> Undefined variable: commnets /Users/crivion/Desktop/localwp/application/controllers/Admin.php 317
ERROR - 3rd November 2012 15:04:40 --> Severity: Notice  --> Undefined variable: users /Users/crivion/Desktop/localwp/application/views/admin-users.php 12
ERROR - 3rd November 2012 15:05:04 --> Severity: Notice  --> Undefined variable: users /Users/crivion/Desktop/localwp/application/views/admin-users.php 12
ERROR - 3rd November 2012 15:05:13 --> Severity: Notice  --> Undefined property: stdClass::$userID /Users/crivion/Desktop/localwp/application/views/admin-comments.php 29
ERROR - 3rd November 2012 15:05:13 --> Severity: Notice  --> Undefined property: stdClass::$ip /Users/crivion/Desktop/localwp/application/views/admin-comments.php 30
ERROR - 3rd November 2012 15:05:13 --> Severity: Notice  --> Undefined property: stdClass::$email /Users/crivion/Desktop/localwp/application/views/admin-comments.php 32
ERROR - 3rd November 2012 15:05:13 --> Severity: Notice  --> Undefined property: stdClass::$about /Users/crivion/Desktop/localwp/application/views/admin-comments.php 33
ERROR - 3rd November 2012 15:05:27 --> Severity: Notice  --> Undefined property: stdClass::$userID /Users/crivion/Desktop/localwp/application/views/admin-comments.php 29
ERROR - 3rd November 2012 15:05:27 --> Severity: Notice  --> Undefined property: stdClass::$email /Users/crivion/Desktop/localwp/application/views/admin-comments.php 32
ERROR - 3rd November 2012 15:05:27 --> Severity: Notice  --> Undefined property: stdClass::$about /Users/crivion/Desktop/localwp/application/views/admin-comments.php 33
ERROR - 3rd November 2012 15:05:39 --> Severity: Notice  --> Undefined property: stdClass::$email /Users/crivion/Desktop/localwp/application/views/admin-comments.php 32
ERROR - 3rd November 2012 15:05:39 --> Severity: Notice  --> Undefined property: stdClass::$about /Users/crivion/Desktop/localwp/application/views/admin-comments.php 33
ERROR - 3rd November 2012 15:06:00 --> Severity: Notice  --> Undefined property: stdClass::$email /Users/crivion/Desktop/localwp/application/views/admin-comments.php 32
ERROR - 3rd November 2012 15:06:00 --> Severity: Notice  --> Undefined property: stdClass::$about /Users/crivion/Desktop/localwp/application/views/admin-comments.php 33
ERROR - 3rd November 2012 15:06:17 --> Severity: Notice  --> Undefined property: stdClass::$email /Users/crivion/Desktop/localwp/application/views/admin-comments.php 32
ERROR - 3rd November 2012 15:06:17 --> Severity: Notice  --> Undefined property: stdClass::$about /Users/crivion/Desktop/localwp/application/views/admin-comments.php 33
ERROR - 3rd November 2012 15:07:06 --> Severity: Notice  --> Undefined property: stdClass::$about /Users/crivion/Desktop/localwp/application/views/admin-comments.php 33
ERROR - 3rd November 2012 15:12:57 --> Query error: Unknown column 'movies.film_ID' in 'where clause'
ERROR - 3rd November 2012 15:13:01 --> Query error: Unknown column 'genres.movID' in 'where clause'
ERROR - 3rd November 2012 15:13:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as tGenres
FROM (`genres`)' at line 1
ERROR - 3rd November 2012 15:13:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as tGenres
FROM (`genres`)' at line 1
ERROR - 3rd November 2012 15:16:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as tGenres
FROM (`genres`)' at line 1
ERROR - 3rd November 2012 15:16:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as tGenres
FROM (`genres`)' at line 1
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:16:35 --> Severity: Notice  --> Undefined property: stdClass::$tMovies /Users/crivion/Desktop/localwp/application/views/admin-genres.php 30
ERROR - 3rd November 2012 15:28:06 --> Severity: Notice  --> Undefined variable: tos /Users/crivion/Desktop/localwp/application/views/admin-tos.php 13
ERROR - 3rd November 2012 15:29:06 --> Severity: Notice  --> Use of undefined constant ARRAY_A - assumed 'ARRAY_A' /Users/crivion/Desktop/localwp/application/controllers/Admin.php 375
ERROR - 3rd November 2012 15:29:06 --> Severity: Notice  --> Undefined variable: tos /Users/crivion/Desktop/localwp/application/views/admin-tos.php 13
ERROR - 3rd November 2012 15:31:56 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/application/views/admin-tos.php 14
ERROR - 3rd November 2012 15:34:45 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/Admin.php 407
ERROR - 3rd November 2012 15:34:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 3rd November 2012 15:35:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/Admin.php 407
ERROR - 3rd November 2012 15:35:39 --> Severity: Notice  --> Undefined property: stdClass::$tos /Users/crivion/Desktop/localwp/application/controllers/Admin.php 407
ERROR - 3rd November 2012 15:58:22 --> Severity: Notice  --> Undefined index:  genres /Users/crivion/Desktop/localwp/application/controllers/Admin.php 242
ERROR - 3rd November 2012 15:58:22 --> Severity: Warning  --> implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed /Users/crivion/Desktop/localwp/application/controllers/Admin.php 242
ERROR - 3rd November 2012 15:59:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE '%Jackson Nicoll%', actors) OR FIND_IN_SET(' Jackson Nicoll', actors)' at line 1
ERROR - 3rd November 2012 16:19:31 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'db_user'@'localhost' (using password: YES) /Users/crivion/Desktop/localwp/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 3rd November 2012 16:19:31 --> Unable to connect to the database
