<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 20th July 2019 00:27:07 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 02:33:41 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 03:32:12 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 07:36:35 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 07:36:35 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 11:21:25 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 11:21:25 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 11:21:25 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 11:21:26 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 14:10:21 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 20th July 2019 19:17:29 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
