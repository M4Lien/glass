<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 30th July 2019 02:18:51 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 30th July 2019 02:19:02 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 30th July 2019 04:41:30 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 30th July 2019 05:47:24 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 30th July 2019 06:03:25 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 30th July 2019 14:15:33 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
