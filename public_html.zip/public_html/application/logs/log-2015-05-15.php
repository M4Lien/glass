<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 15th May 2015 22:41:57 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'flippa' /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 15th May 2015 22:41:57 --> Unable to connect to the database
