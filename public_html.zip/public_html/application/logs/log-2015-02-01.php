<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 1st February 2015 12:09:48 --> Severity: Notice  --> Undefined variable: viewdata /Users/crivion/Sites/local.flippa/application/views/paypal.php 10
ERROR - 1st February 2015 12:12:36 --> Severity: Notice  --> Undefined variable: settins /Users/crivion/Sites/local.flippa/application/views/newlisting.php 18
ERROR - 1st February 2015 12:12:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/newlisting.php 18
ERROR - 1st February 2015 12:23:22 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Sites/local.flippa/application/controllers/home.php 36
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 18
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 18
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 19
ERROR - 1st February 2015 19:34:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 19
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 18
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 18
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 19
ERROR - 1st February 2015 19:34:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 19
ERROR - 1st February 2015 19:35:40 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:35:40 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:35:40 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:35:40 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:35:40 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:35:40 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:35:52 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:35:52 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:35:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:35:52 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:35:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:06 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:36:06 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:06 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:06 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:06 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:08 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:36:08 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:08 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:08 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:08 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:35 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:36:35 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:35 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:35 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:35 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:38 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:36:38 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:38 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:38 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:38 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:46 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:36:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:53 --> Severity: Notice  --> Array to string conversion /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 15
ERROR - 1st February 2015 19:36:53 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:53 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:36:53 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:36:53 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:37:30 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:37:30 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:37:30 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:37:30 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:37:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:37:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 16
ERROR - 1st February 2015 19:37:46 --> Severity: Notice  --> Undefined variable: s /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:37:46 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/admin-seo.php 17
ERROR - 1st February 2015 19:45:49 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:45:49 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:45:52 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:45:52 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:45:54 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:45:54 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:48:35 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:48:35 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:48:37 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:48:37 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:49:13 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:49:13 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:49:30 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 1st February 2015 19:49:30 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 1st February 2015 19:51:59 --> Query error: Data too long for column 'revenue_details' at row 1
ERROR - 1st February 2015 19:54:05 --> Severity: Notice  --> Undefined variable: attachments_icon /Users/crivion/Sites/local.flippa/application/views/newlisting.php 88
ERROR - 1st February 2015 20:11:42 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/views/user-profiles.php 17
ERROR - 1st February 2015 20:11:42 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/user-profiles.php 17
ERROR - 1st February 2015 20:32:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 1st February 2015 20:32:54 --> PNG images are not supported.
ERROR - 1st February 2015 20:32:54 --> Your server does not support the GD function required to process this type of image.
ERROR - 1st February 2015 20:32:54 --> PNG images are not supported.
ERROR - 1st February 2015 20:33:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 1st February 2015 20:33:32 --> PNG images are not supported.
ERROR - 1st February 2015 20:33:32 --> Your server does not support the GD function required to process this type of image.
ERROR - 1st February 2015 20:33:32 --> PNG images are not supported.
