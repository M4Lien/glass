<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 27th July 2019 05:07:39 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 27th July 2019 06:57:12 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 27th July 2019 06:57:18 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 27th July 2019 12:59:15 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 27th July 2019 12:59:15 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 27th July 2019 14:11:33 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 27th July 2019 17:08:00 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 27th July 2019 23:11:32 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
