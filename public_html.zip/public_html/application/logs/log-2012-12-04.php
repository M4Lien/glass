<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 4th December 2012 17:01:07 --> Severity: Notice  --> Undefined variable: This /Users/crivion/www/flippa/application/controllers/listings.php 29
ERROR - 4th December 2012 17:01:07 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 29
ERROR - 4th December 2012 17:02:33 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$get /Users/crivion/www/flippa/application/controllers/listings.php 35
ERROR - 4th December 2012 17:10:23 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/bid.php 14
ERROR - 4th December 2012 17:15:44 --> Query error: Unknown column 'ownerID' in 'field list'
ERROR - 4th December 2012 17:22:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 128
ERROR - 4th December 2012 17:27:41 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 129
ERROR - 4th December 2012 17:44:26 --> Query error: Incorrect usage of UNION and ORDER BY
ERROR - 4th December 2012 17:45:23 --> Query error: No tables used
ERROR - 4th December 2012 17:45:54 --> Query error: No tables used
ERROR - 4th December 2012 17:46:40 --> Query error: No tables used
ERROR - 4th December 2012 17:46:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/listings.php:123) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 4th December 2012 17:47:04 --> Query error: No tables used
ERROR - 4th December 2012 17:47:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/application/controllers/listings.php:123) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 4th December 2012 17:48:10 --> Severity: Notice  --> Undefined variable: last_bid /Users/crivion/www/flippa/application/controllers/listings.php 123
ERROR - 4th December 2012 17:48:25 --> Query error: No tables used
ERROR - 4th December 2012 17:49:52 --> Severity: Notice  --> Undefined property: stdClass::$t_Bids /Users/crivion/www/flippa/application/controllers/listings.php 129
ERROR - 4th December 2012 17:50:05 --> Query error: No tables used
ERROR - 4th December 2012 17:55:29 --> Severity: Notice  --> Undefined property: stdClass::$t_Bids /Users/crivion/www/flippa/application/controllers/listings.php 126
ERROR - 4th December 2012 18:08:04 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 131
ERROR - 4th December 2012 18:12:18 --> Severity: Notice  --> Undefined variable: bid_amount /Users/crivion/www/flippa/application/views/bid.php 16
