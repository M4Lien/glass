<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2nd November 2012 12:10:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/system/core/Config.php 300
ERROR - 2nd November 2012 13:35:44 --> Severity: Notice  --> Undefined variable: user /Users/crivion/Desktop/localwp/application/views/user-profiles.php 10
ERROR - 2nd November 2012 13:36:43 --> Severity: Notice  --> Undefined variable: user /Users/crivion/Desktop/localwp/application/views/user-profiles.php 10
ERROR - 2nd November 2012 13:37:06 --> Severity: Notice  --> Undefined variable: user /Users/crivion/Desktop/localwp/application/views/user-profiles.php 10
ERROR - 2nd November 2012 13:43:03 --> Severity: Notice  --> Undefined variable: playlist /Users/crivion/Desktop/localwp/application/views/user-profiles.php 19
ERROR - 2nd November 2012 13:45:48 --> Severity: Notice  --> Undefined property: stdClass::$film_title /Users/crivion/Desktop/localwp/application/views/user-profiles.php 22
ERROR - 2nd November 2012 13:45:48 --> Severity: Notice  --> Undefined property: stdClass::$filmID /Users/crivion/Desktop/localwp/application/views/user-profiles.php 22
ERROR - 2nd November 2012 13:45:48 --> Severity: Notice  --> Undefined property: stdClass::$film_title /Users/crivion/Desktop/localwp/application/views/user-profiles.php 22
ERROR - 2nd November 2012 13:45:48 --> Severity: Notice  --> Undefined property: stdClass::$film_title /Users/crivion/Desktop/localwp/application/views/user-profiles.php 22
ERROR - 2nd November 2012 13:45:48 --> Severity: Notice  --> Undefined property: stdClass::$filmID /Users/crivion/Desktop/localwp/application/views/user-profiles.php 22
ERROR - 2nd November 2012 13:45:48 --> Severity: Notice  --> Undefined property: stdClass::$film_title /Users/crivion/Desktop/localwp/application/views/user-profiles.php 22
ERROR - 2nd November 2012 13:47:39 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, array given /Users/crivion/Desktop/localwp/system/database/DB_active_rec.php 331
ERROR - 2nd November 2012 13:47:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '? Array' at line 4
ERROR - 2nd November 2012 13:47:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 2nd November 2012 13:47:53 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, array given /Users/crivion/Desktop/localwp/system/database/DB_active_rec.php 331
ERROR - 2nd November 2012 13:47:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '? '9'' at line 4
ERROR - 2nd November 2012 13:47:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 2nd November 2012 13:48:03 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, array given /Users/crivion/Desktop/localwp/system/database/DB_active_rec.php 331
ERROR - 2nd November 2012 13:48:03 --> Query error: Unknown column 'Array' in 'on clause'
ERROR - 2nd November 2012 13:48:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 2nd November 2012 14:22:18 --> Severity: Notice  --> Undefined variable: tos /Users/crivion/Desktop/localwp/application/views/tos.php 8
ERROR - 2nd November 2012 14:22:30 --> Severity: Notice  --> Undefined variable: tos /Users/crivion/Desktop/localwp/application/views/tos.php 8
ERROR - 2nd November 2012 14:53:02 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/Admin.php 36
ERROR - 2nd November 2012 14:54:47 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/Admin.php 38
ERROR - 2nd November 2012 14:56:38 --> Severity: Notice  --> Undefined property: Admin::$loggedIn /Users/crivion/Desktop/localwp/application/controllers/Admin.php 22
ERROR - 2nd November 2012 14:56:38 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/Admin.php 44
ERROR - 2nd November 2012 14:57:00 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/Admin.php 44
ERROR - 2nd November 2012 14:57:24 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/Admin.php 44
ERROR - 2nd November 2012 14:57:28 --> Severity: Notice  --> Undefined variable: config /Users/crivion/Desktop/localwp/application/controllers/Admin.php 33
ERROR - 2nd November 2012 14:57:35 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/Admin.php 44
ERROR - 2nd November 2012 14:57:49 --> Severity: Notice  --> Undefined variable: config /Users/crivion/Desktop/localwp/application/controllers/Admin.php 35
ERROR - 2nd November 2012 15:46:15 --> Unable to load the requested class: crv_imdbscraper
ERROR - 2nd November 2012 15:47:14 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 15:47:34 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 15:47:58 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 15:47:59 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 15:48:02 --> Severity: Warning  --> Wrong parameter count for strstr() /Users/crivion/Desktop/localwp/application/controllers/Admin.php 94
ERROR - 2nd November 2012 15:48:02 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 15:48:31 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 16:31:36 --> Severity: Notice  --> Array to string conversion /Users/crivion/Desktop/localwp/application/controllers/Admin.php 104
ERROR - 2nd November 2012 16:31:37 --> Severity: Notice  --> Array to string conversion /Users/crivion/Desktop/localwp/application/controllers/Admin.php 104
ERROR - 2nd November 2012 16:34:41 --> Severity: Notice  --> Array to string conversion /Users/crivion/Desktop/localwp/application/controllers/Admin.php 105
ERROR - 2nd November 2012 16:35:10 --> Severity: Notice  --> Array to string conversion /Users/crivion/Desktop/localwp/application/controllers/Admin.php 109
ERROR - 2nd November 2012 16:36:04 --> Severity: Notice  --> Array to string conversion /Users/crivion/Desktop/localwp/application/controllers/Admin.php 106
ERROR - 2nd November 2012 16:59:22 --> Non-existent class: CRV_IMDbScraper
ERROR - 2nd November 2012 16:59:49 --> Non-existent class: CRV_IMDbScraper
ERROR - 2nd November 2012 17:34:04 --> Severity: Notice  --> Undefined variable: url /Users/crivion/Desktop/localwp/application/controllers/Admin.php 156
ERROR - 2nd November 2012 17:34:04 --> Severity: Warning  --> file_put_contents(/Users/crivion/Desktop/localwp/uploads/) [<a href='function.file-put-contents'>function.file-put-contents</a>]: failed to open stream: Is a directory /Users/crivion/Desktop/localwp/application/controllers/Admin.php 160
ERROR - 2nd November 2012 17:34:34 --> Severity: Warning  --> file_put_contents(/Users/crivion/Desktop/localwp/uploads/) [<a href='function.file-put-contents'>function.file-put-contents</a>]: failed to open stream: Is a directory /Users/crivion/Desktop/localwp/application/controllers/Admin.php 160
ERROR - 2nd November 2012 18:03:33 --> Severity: Notice  --> Undefined index:  genres /Users/crivion/Desktop/localwp/application/controllers/Admin.php 187
ERROR - 2nd November 2012 18:03:33 --> Severity: Warning  --> implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed /Users/crivion/Desktop/localwp/application/controllers/Admin.php 187
ERROR - 2nd November 2012 18:42:40 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/admin.php 12
ERROR - 2nd November 2012 18:43:03 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/admin.php 12
ERROR - 2nd November 2012 19:00:19 --> Query error: Unknown column 'id' in 'where clause'
ERROR - 2nd November 2012 19:25:11 --> Severity: Notice  --> Undefined variable: link /Users/crivion/Desktop/localwp/application/views/admin-links.php 8
ERROR - 2nd November 2012 19:25:11 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/admin-links.php 8
