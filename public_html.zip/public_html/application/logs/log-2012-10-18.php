<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 18th October 2012 17:05:44 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
