<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 8th July 2019 09:09:46 --> Severity: Warning  --> mysqli_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/aperozco/public_html/system/database/drivers/mysqli/mysqli_driver.php 77
ERROR - 8th July 2019 09:09:46 --> Unable to connect to the database
ERROR - 8th July 2019 09:11:53 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 09:11:56 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 10:48:39 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 15:45:47 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 15:45:47 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 15:45:47 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 15:45:47 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 16:28:55 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 8th July 2019 19:07:35 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
