<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2nd November 2014 15:49:38 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 2nd November 2014 15:49:38 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 2nd November 2014 15:49:50 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 2nd November 2014 15:49:50 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 2nd November 2014 15:50:22 --> Severity: Notice  --> Undefined property: stdClass::$starting /Users/crivion/Sites/local.flippa/application/controllers/listings.php 142
ERROR - 2nd November 2014 15:50:22 --> Severity: Notice  --> Undefined property: stdClass::$starting /Users/crivion/Sites/local.flippa/application/controllers/listings.php 143
ERROR - 2nd November 2014 15:50:22 --> Severity: Notice  --> Undefined property: stdClass::$unique /Users/crivion/Sites/local.flippa/application/views/sidebar-single.php 46
ERROR - 2nd November 2014 15:53:42 --> Severity: Notice  --> Undefined property: stdClass::$unique /Users/crivion/Sites/local.flippa/application/views/sidebar-single.php 46
ERROR - 2nd November 2014 15:59:50 --> Query error: Unknown column 'starting' in 'field list'
ERROR - 2nd November 2014 16:00:19 --> Severity: Notice  --> Undefined property: stdClass::$starting /Users/crivion/Sites/local.flippa/application/controllers/listings.php 43
