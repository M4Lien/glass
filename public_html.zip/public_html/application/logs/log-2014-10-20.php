<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 20th October 2014 21:31:25 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'flippa' /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 20th October 2014 21:31:25 --> Unable to connect to the database
ERROR - 20th October 2014 21:38:38 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 20th October 2014 21:38:38 --> Unable to connect to the database
ERROR - 20th October 2014 21:38:39 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 20th October 2014 21:38:39 --> Unable to connect to the database
ERROR - 20th October 2014 21:38:39 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 20th October 2014 21:38:39 --> Unable to connect to the database
ERROR - 20th October 2014 21:41:18 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 20th October 2014 21:41:18 --> Unable to connect to the database
ERROR - 20th October 2014 21:41:19 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 20th October 2014 21:41:19 --> Unable to connect to the database
