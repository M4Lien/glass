<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 8th September 2015 02:40:30 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 8th September 2015 02:40:30 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 8th September 2015 02:41:33 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 8th September 2015 02:41:33 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 8th September 2015 03:07:52 --> Severity: Notice  --> Undefined variable: message /Users/crivion/Sites/local.flippa/application/views/admin.php 15
ERROR - 8th September 2015 03:12:31 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /Users/crivion/Sites/local.flippa/application/views/single-listing.php 49
ERROR - 8th September 2015 03:17:44 --> Severity: Notice  --> Undefined property: stdClass::$stripe_private /Users/crivion/Sites/local.flippa/application/views/admin-settings.php 28
ERROR - 8th September 2015 03:17:44 --> Severity: Notice  --> Undefined property: stdClass::$stripe_public /Users/crivion/Sites/local.flippa/application/views/admin-settings.php 29
ERROR - 8th September 2015 03:24:29 --> Query error: Unknown column 'paypal_enable' in 'field list'
ERROR - 8th September 2015 03:55:31 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/Sites/local.flippa/application/views/newlisting.php 39
ERROR - 8th September 2015 03:55:49 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/Sites/local.flippa/application/views/newlisting.php 39
ERROR - 8th September 2015 03:56:17 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/Sites/local.flippa/application/views/newlisting.php 39
ERROR - 8th September 2015 03:56:31 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/Sites/local.flippa/application/views/newlisting.php 39
