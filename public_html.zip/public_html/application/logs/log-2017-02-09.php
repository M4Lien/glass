<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 9th February 2017 12:29:45 --> Severity: Notice  --> Undefined index: license_code /Users/crivion/Sites/local.flippa/application/controllers/home.php 234
ERROR - 9th February 2017 12:33:25 --> Query error: Duplicate column name 'isActive'
