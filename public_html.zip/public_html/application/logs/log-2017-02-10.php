<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 10th February 2017 12:15:35 --> Query error: Duplicate column name 'isActive'
