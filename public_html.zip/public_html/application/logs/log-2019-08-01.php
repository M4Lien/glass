<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 1st August 2019 04:37:36 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 1st August 2019 08:47:21 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 1st August 2019 10:40:06 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 1st August 2019 11:57:39 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 1st August 2019 14:51:20 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 1st August 2019 15:31:36 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 1st August 2019 16:43:30 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
