<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 3rd February 2017 04:45:27 --> Severity: Notice  --> Undefined variable: tos /Users/crivion/Sites/local.flippa/application/views/analytics-api.php 17
