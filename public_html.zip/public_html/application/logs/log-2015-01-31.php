<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 31st January 2015 21:12:31 --> Query error: Unknown column 'diff' in 'having clause'
ERROR - 31st January 2015 21:13:25 --> Query error: Unknown column 'diff' in 'having clause'
ERROR - 31st January 2015 22:18:47 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 31st January 2015 22:18:47 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
