<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2nd June 2015 06:47:01 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 2nd June 2015 06:47:01 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 2nd June 2015 06:47:35 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 2nd June 2015 06:47:35 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 2nd June 2015 07:10:28 --> Severity: Notice  --> Undefined property: Admin::$image_lib /Users/crivion/Sites/local.flippa/application/controllers/admin.php 116
ERROR - 2nd June 2015 07:34:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2nd June 2015 07:34:19 --> PNG images are not supported.
ERROR - 2nd June 2015 07:34:19 --> Your server does not support the GD function required to process this type of image.
ERROR - 2nd June 2015 07:34:19 --> PNG images are not supported.
ERROR - 2nd June 2015 07:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2nd June 2015 07:35:30 --> PNG images are not supported.
ERROR - 2nd June 2015 07:35:30 --> Your server does not support the GD function required to process this type of image.
ERROR - 2nd June 2015 07:35:30 --> PNG images are not supported.
