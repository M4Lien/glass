<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 26th July 2019 03:39:31 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 26th July 2019 07:59:21 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
