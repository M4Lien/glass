<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 16th September 2015 23:07:01 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /Users/crivion/Sites/local.flippa/application/views/single-listing.php 49
ERROR - 16th September 2015 23:55:02 --> Severity: Notice  --> Undefined variable: fields_string /Users/crivion/Sites/local.flippa/application/controllers/payments.php 83
