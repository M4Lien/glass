<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 12th February 2015 00:11:07 --> Severity: Notice  --> Undefined variable: listings_open /Users/crivion/Sites/local.flippa/application/views/footer.php 45
ERROR - 12th February 2015 00:11:07 --> Severity: Notice  --> Undefined variable: bids_count /Users/crivion/Sites/local.flippa/application/views/footer.php 46
ERROR - 12th February 2015 00:11:07 --> Severity: Notice  --> Undefined variable: sales_overall /Users/crivion/Sites/local.flippa/application/views/footer.php 47
ERROR - 12th February 2015 00:11:07 --> Severity: Notice  --> Undefined variable: members_count /Users/crivion/Sites/local.flippa/application/views/footer.php 48
ERROR - 12th February 2015 00:18:13 --> Severity: Notice  --> Undefined variable: listings_open /Users/crivion/Sites/local.flippa/application/views/footer.php 45
ERROR - 12th February 2015 00:18:13 --> Severity: Notice  --> Undefined variable: bids_count /Users/crivion/Sites/local.flippa/application/views/footer.php 46
ERROR - 12th February 2015 00:18:13 --> Severity: Notice  --> Undefined variable: sales_overall /Users/crivion/Sites/local.flippa/application/views/footer.php 47
ERROR - 12th February 2015 00:18:13 --> Severity: Notice  --> Undefined variable: members_count /Users/crivion/Sites/local.flippa/application/views/footer.php 48
ERROR - 12th February 2015 00:18:17 --> Severity: Notice  --> Undefined variable: listings_open /Users/crivion/Sites/local.flippa/application/views/footer.php 45
ERROR - 12th February 2015 00:18:17 --> Severity: Notice  --> Undefined variable: bids_count /Users/crivion/Sites/local.flippa/application/views/footer.php 46
ERROR - 12th February 2015 00:18:17 --> Severity: Notice  --> Undefined variable: sales_overall /Users/crivion/Sites/local.flippa/application/views/footer.php 47
ERROR - 12th February 2015 00:18:17 --> Severity: Notice  --> Undefined variable: members_count /Users/crivion/Sites/local.flippa/application/views/footer.php 48
