<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 25th January 2017 01:32:57 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 785
ERROR - 25th January 2017 01:32:57 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 786
ERROR - 25th January 2017 01:32:57 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/newlisting.php 44
ERROR - 25th January 2017 02:21:22 --> Severity: Notice  --> Undefined variable: file /Users/crivion/Sites/local.flippa/application/controllers/users.php 1572
ERROR - 25th January 2017 03:36:03 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$rawurl /Users/crivion/Sites/local.flippa/application/controllers/listings.php 211
ERROR - 25th January 2017 03:36:20 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$listing_url /Users/crivion/Sites/local.flippa/application/controllers/listings.php 211
ERROR - 25th January 2017 03:36:46 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$listing_url /Users/crivion/Sites/local.flippa/application/controllers/listings.php 211
