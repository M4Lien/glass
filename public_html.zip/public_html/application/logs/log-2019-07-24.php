<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 24th July 2019 02:17:59 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 02:18:22 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 02:19:15 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 02:32:38 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 04:19:03 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 05:40:39 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 10:12:16 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 11:48:32 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 14:39:09 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 24th July 2019 19:59:17 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
