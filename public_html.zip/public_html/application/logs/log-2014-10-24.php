<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 24th October 2014 21:43:55 --> Severity: Warning  --> mysqli_connect(): (HY000/1049): Unknown database 'flippa' /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 24th October 2014 21:43:55 --> Unable to connect to the database
