<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 31st October 2012 13:04:30 --> Severity: Warning  --> array_walk() [<a href='function.array-walk'>function.array-walk</a>]: Unable to call add_url_on_tag)() - function does not exist /Users/crivion/Desktop/localwp/application/views/watch-movies.php 54
ERROR - 31st October 2012 13:05:00 --> Severity: Warning  --> Missing argument 3 for add_url_on_tags() /Users/crivion/Desktop/localwp/application/views/watch-movies.php 47
ERROR - 31st October 2012 13:05:00 --> Severity: Notice  --> Undefined variable: path /Users/crivion/Desktop/localwp/application/views/watch-movies.php 49
ERROR - 31st October 2012 13:05:00 --> Severity: Warning  --> Missing argument 3 for add_url_on_tags() /Users/crivion/Desktop/localwp/application/views/watch-movies.php 47
ERROR - 31st October 2012 13:05:00 --> Severity: Notice  --> Undefined variable: path /Users/crivion/Desktop/localwp/application/views/watch-movies.php 49
ERROR - 31st October 2012 13:06:46 --> Severity: Warning  --> array_walk() [<a href='function.array-walk'>function.array-walk</a>]: Unable to call add_url_on_tags() - function does not exist /Users/crivion/Desktop/localwp/application/views/watch-movies.php 47
ERROR - 31st October 2012 13:07:43 --> Severity: Notice  --> Undefined variable: item /Users/crivion/Desktop/localwp/application/helpers/add_url_on_tags_helper.php 7
ERROR - 31st October 2012 13:07:43 --> Severity: Notice  --> Undefined variable: item /Users/crivion/Desktop/localwp/application/helpers/add_url_on_tags_helper.php 7
ERROR - 31st October 2012 13:16:49 --> Severity: Notice  --> Undefined offset:  0 /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 15
ERROR - 31st October 2012 13:16:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 15
ERROR - 31st October 2012 13:43:41 --> Severity: Notice  --> Array to string conversion /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 78
ERROR - 31st October 2012 13:48:20 --> Severity: Notice  --> Undefined property: CI_DB_mysql_result::$db /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 28
ERROR - 31st October 2012 13:48:49 --> Query error: Not unique table/alias: 'comments'
ERROR - 31st October 2012 13:49:52 --> Query error: Not unique table/alias: 'comments'
ERROR - 31st October 2012 13:50:02 --> Query error: Unknown column 'comments' in 'where clause'
ERROR - 31st October 2012 13:50:24 --> Query error: Unknown column 'comments' in 'where clause'
ERROR - 31st October 2012 13:51:16 --> Severity: 4096  --> Object of class CI_DB_mysql_result could not be converted to string /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 33
ERROR - 31st October 2012 13:51:42 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 33
ERROR - 31st October 2012 13:54:14 --> Query error: Table 'users.username' doesn't exist
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:06:54 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:07:34 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:09:57 --> Severity: Notice  --> Undefined property: stdClass::$comment_date /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:09:57 --> Severity: Notice  --> Undefined property: stdClass::$comment_date /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:09:57 --> Severity: Notice  --> Undefined property: stdClass::$comment_date /Users/crivion/Desktop/localwp/application/views/watch-movies.php 94
ERROR - 31st October 2012 14:26:17 --> Severity: Warning  --> Missing argument 1 for WatchMovies::ajax_last_comment() /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 117
ERROR - 31st October 2012 15:30:27 --> Query error: Unknown column 'film_title' in 'field list'
ERROR - 31st October 2012 16:12:50 --> Query error: Unknown column 'movID' in 'where clause'
ERROR - 31st October 2012 16:13:00 --> Query error: Unknown column 'movID' in 'where clause'
ERROR - 31st October 2012 16:18:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') WHERE `filmID` =  1' at line 1
ERROR - 31st October 2012 16:18:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:177) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 178
ERROR - 31st October 2012 16:18:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:177) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 178
ERROR - 31st October 2012 16:19:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:177) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 178
ERROR - 31st October 2012 16:21:04 --> Severity: Notice  --> Object of class stdClass could not be converted to int /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 182
ERROR - 31st October 2012 16:21:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 187
ERROR - 31st October 2012 16:21:48 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:186) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 187
ERROR - 31st October 2012 16:22:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:186) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 187
ERROR - 31st October 2012 16:23:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:186) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 187
ERROR - 31st October 2012 16:24:14 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:192) /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 193
ERROR - 31st October 2012 17:22:43 --> Severity: Notice  --> Undefined offset:  0 /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 26
ERROR - 31st October 2012 17:22:43 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 26
ERROR - 31st October 2012 17:28:28 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 68
ERROR - 31st October 2012 17:35:26 --> Severity: Notice  --> Undefined offset:  0 /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 26
ERROR - 31st October 2012 17:35:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 26
ERROR - 31st October 2012 17:53:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `movies` =  Array' at line 2
ERROR - 31st October 2012 17:53:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `movies` =  Array' at line 2
ERROR - 31st October 2012 17:53:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `film_type` =  'movie'' at line 2
ERROR - 31st October 2012 17:54:33 --> Severity: Notice  --> Undefined variable: pagination /Users/crivion/Desktop/localwp/application/views/all-movies.php 30
ERROR - 31st October 2012 17:54:42 --> Severity: 4096  --> Object of class CI_Pagination could not be converted to string /Users/crivion/Desktop/localwp/application/views/all-movies.php 30
ERROR - 31st October 2012 18:00:55 --> Severity: Notice  --> Undefined variable: pagination /Users/crivion/Desktop/localwp/application/views/all-movies.php 30
ERROR - 31st October 2012 18:19:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''16'' at line 1
ERROR - 31st October 2012 18:21:05 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 123
ERROR - 31st October 2012 18:21:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:21:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:21:22 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:21:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:21:22 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:120) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:21:27 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:21:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:21:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:120) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:21:42 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:21:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:21:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:21:45 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:21:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:21:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:21:53 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:21:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:21:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:22:00 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:22:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:22:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:24:07 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 125
ERROR - 31st October 2012 18:24:07 --> Severity: Notice  --> Undefined variable: genreID /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 130
ERROR - 31st October 2012 18:24:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:24:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:24:26 --> Query error: Unknown column 'Comedy' in 'where clause'
ERROR - 31st October 2012 18:25:15 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 124
ERROR - 31st October 2012 18:25:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:25:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:25:30 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 124
ERROR - 31st October 2012 18:25:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:25:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:25:38 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 124
ERROR - 31st October 2012 18:25:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:25:38 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:26:00 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 127
ERROR - 31st October 2012 18:26:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:26:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:26:13 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 127
ERROR - 31st October 2012 18:26:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:26:13 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:26:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 127
ERROR - 31st October 2012 18:26:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:26:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php:125) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:26:58 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/all-movies.php 7
ERROR - 31st October 2012 18:27:20 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/all-movies.php 9
ERROR - 31st October 2012 18:27:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/all-movies.php 9
ERROR - 31st October 2012 18:27:29 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 132
ERROR - 31st October 2012 18:27:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' genres)' at line 1
ERROR - 31st October 2012 18:27:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 31st October 2012 18:27:40 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/all-movies.php 9
ERROR - 31st October 2012 18:27:55 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/all-movies.php 9
ERROR - 31st October 2012 18:28:09 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/all-movies.php 9
