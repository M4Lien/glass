<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 1st February 2017 09:05:00 --> Severity: Notice  --> Undefined index: profileID /Users/crivion/Sites/local.flippa/application/libraries/GoogleAnalytics.php 26
ERROR - 1st February 2017 09:05:26 --> Severity: Notice  --> Undefined index: profileID /Users/crivion/Sites/local.flippa/application/libraries/GoogleAnalytics.php 26
ERROR - 1st February 2017 09:05:49 --> Severity: Notice  --> Undefined index: profileID /Users/crivion/Sites/local.flippa/application/libraries/GoogleAnalytics.php 26
ERROR - 1st February 2017 09:06:55 --> Severity: Notice  --> Undefined property: Home::$googleanalytics /Users/crivion/Sites/local.flippa/application/controllers/home.php 251
ERROR - 1st February 2017 09:11:50 --> Severity: Notice  --> Undefined property: Home::$googleAnalytics /Users/crivion/Sites/local.flippa/application/controllers/home.php 258
ERROR - 1st February 2017 09:23:58 --> Severity: Warning  --> Missing argument 1 for GoogleAnalytics::WebPropertiesList(), called in /Users/crivion/Sites/local.flippa/application/controllers/home.php on line 276 and defined /Users/crivion/Sites/local.flippa/application/libraries/GoogleAnalytics.php 78
ERROR - 1st February 2017 09:23:58 --> Severity: Notice  --> Undefined variable: accountId /Users/crivion/Sites/local.flippa/application/libraries/GoogleAnalytics.php 84
ERROR - 1st February 2017 09:29:43 --> Severity: Notice  --> Undefined variable: items /Users/crivion/Sites/local.flippa/application/controllers/home.php 289
ERROR - 1st February 2017 09:29:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/crivion/Sites/local.flippa/application/controllers/home.php 289
ERROR - 1st February 2017 09:30:01 --> Severity: Notice  --> Undefined variable: items /Users/crivion/Sites/local.flippa/application/controllers/home.php 289
ERROR - 1st February 2017 09:30:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/crivion/Sites/local.flippa/application/controllers/home.php 289
