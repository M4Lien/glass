<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 22nd July 2019 05:16:31 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 05:36:08 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 05:38:58 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 05:41:48 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 07:28:24 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 07:28:50 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 10:33:44 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 11:43:44 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 15:07:46 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 22nd July 2019 17:16:50 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 22nd July 2019 20:40:39 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
