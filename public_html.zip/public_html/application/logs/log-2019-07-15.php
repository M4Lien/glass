<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 15th July 2019 06:03:13 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 15th July 2019 06:11:23 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 06:12:08 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 07:49:50 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 07:56:04 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 08:37:29 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 10:40:12 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 12:33:20 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 12:34:09 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 12:54:02 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 13:12:31 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 13:48:04 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 14:20:00 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 15:05:00 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 15:27:35 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 16:15:15 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 16:31:28 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 17:45:18 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 18:25:06 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 15th July 2019 19:58:12 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 15th July 2019 20:33:27 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 20:53:49 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 15th July 2019 21:12:35 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
