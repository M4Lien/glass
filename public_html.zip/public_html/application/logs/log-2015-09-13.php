<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 13th September 2015 22:45:40 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /Users/crivion/Sites/local.flippa/application/views/single-listing.php 49
