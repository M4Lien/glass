<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 26th November 2012 14:13:37 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'db_user'@'localhost' (using password: YES) /Users/crivion/www/flippa/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 26th November 2012 14:13:37 --> Unable to connect to the database
ERROR - 26th November 2012 14:15:15 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 26th November 2012 14:15:15 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 26th November 2012 14:17:40 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 14:19:33 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 14:20:27 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 14:20:28 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 14:20:28 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 14:20:29 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 14:20:29 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 26th November 2012 17:30:12 --> Severity: Notice  --> unserialize() [<a href='function.unserialize'>function.unserialize</a>]: Error at offset 5 of 359 bytes /Users/crivion/www/flippa/application/views/home.php 11
ERROR - 26th November 2012 18:41:44 --> Query error: Table 'flippa.users' doesn't exist
