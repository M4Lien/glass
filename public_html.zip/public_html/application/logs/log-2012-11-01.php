<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 1st November 2012 14:35:52 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/sidebar.php 47
ERROR - 1st November 2012 14:35:52 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/sidebar.php 50
ERROR - 1st November 2012 14:41:06 --> Query error: Unknown column 'status' in 'where clause'
ERROR - 1st November 2012 15:16:58 --> Query error: Unknown column 'linkID' in 'where clause'
ERROR - 1st November 2012 15:17:00 --> Query error: Unknown column 'linkID' in 'where clause'
ERROR - 1st November 2012 15:47:42 --> Severity: Notice  --> Undefined variable: genre /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 184
ERROR - 1st November 2012 15:47:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' actors)' at line 1
ERROR - 1st November 2012 15:47:42 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 1st November 2012 15:47:55 --> Severity: Notice  --> Undefined variable: genre /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 184
ERROR - 1st November 2012 15:47:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' actors)' at line 1
ERROR - 1st November 2012 15:47:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 1st November 2012 15:47:57 --> Severity: Notice  --> Undefined variable: genre /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 184
ERROR - 1st November 2012 15:47:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' actors)' at line 1
ERROR - 1st November 2012 15:47:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/system/core/Exceptions.php:185) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 1st November 2012 15:48:43 --> Query error: Unknown column 'by_actor' in 'where clause'
ERROR - 1st November 2012 16:38:58 --> Severity: Notice  --> Undefined variable: genre_name /Users/crivion/Desktop/localwp/application/controllers/Home.php 30
ERROR - 1st November 2012 16:38:58 --> Severity: Notice  --> Undefined variable: genre_name /Users/crivion/Desktop/localwp/application/controllers/Home.php 37
ERROR - 1st November 2012 16:38:58 --> Severity: Notice  --> Undefined variable: genre_name /Users/crivion/Desktop/localwp/application/controllers/Home.php 37
ERROR - 1st November 2012 16:38:58 --> Severity: Notice  --> Undefined variable: genre_name /Users/crivion/Desktop/localwp/application/controllers/Home.php 47
ERROR - 1st November 2012 16:38:58 --> Severity: Notice  --> Undefined variable: genre_name /Users/crivion/Desktop/localwp/application/controllers/Home.php 47
ERROR - 1st November 2012 16:42:22 --> Severity: Notice  --> Undefined variable: vid_type /Users/crivion/Desktop/localwp/application/views/all-movies.php 5
ERROR - 1st November 2012 16:42:22 --> Severity: Notice  --> Undefined variable: vid_type /Users/crivion/Desktop/localwp/application/views/all-movies.php 10
ERROR - 1st November 2012 17:04:43 --> Query error: Unknown column 'destination' in 'field list'
