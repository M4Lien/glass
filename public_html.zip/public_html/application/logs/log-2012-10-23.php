<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 23rd October 2012 15:45:24 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:46:36 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:48:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:49:23 --> Severity: Warning  --> Missing argument 1 for CI_URI::segment(), called in /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php on line 8 and defined /Users/crivion/Desktop/localwp/system/core/URI.php 341
ERROR - 23rd October 2012 15:49:23 --> Severity: Notice  --> Undefined variable: n /Users/crivion/Desktop/localwp/system/core/URI.php 343
ERROR - 23rd October 2012 15:49:23 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:49:36 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:49:41 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:49:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:50:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:50:44 --> Severity: Notice  --> Undefined property: WatchMovies::$ruri /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 8
ERROR - 23rd October 2012 15:50:56 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:51:05 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:51:08 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:51:11 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:51:14 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:51:17 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:52:18 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:53:48 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:54:06 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:54:07 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:54:08 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:54:13 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:54:38 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:55:26 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:55:27 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:55:51 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:29 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:56:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 8
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:01 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:22 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:22 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:22 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 6
ERROR - 23rd October 2012 15:57:37 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:37 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:37 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:45 --> Severity: Notice  --> Undefined variable: moview_info /Users/crivion/Desktop/localwp/application/views/watch-movies.php 4
ERROR - 23rd October 2012 15:57:52 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:52 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:57:52 --> Severity: Notice  --> Undefined index:  film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 23rd October 2012 15:58:24 --> Severity: Notice  --> Undefined property: CI_DB_mysql_result::$film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 15:58:35 --> Severity: Notice  --> Undefined property: CI_DB_mysql_result::$film_title /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 15:58:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 16:00:11 --> Severity: Notice  --> Undefined offset:  0 /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 16:00:11 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 16:00:11 --> Severity: Notice  --> Undefined offset:  0 /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 16:00:11 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 5
ERROR - 23rd October 2012 16:19:34 --> Query error: Not unique table/alias: 'movies'
ERROR - 23rd October 2012 16:19:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`IN` movies.genres' at line 3
ERROR - 23rd October 2012 16:21:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`IN` movies.genres' at line 3
ERROR - 23rd October 2012 16:21:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`IN` movies.genres
WHERE `filmID` =  1' at line 3
