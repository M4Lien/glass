<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 3rd December 2012 15:07:12 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 3rd December 2012 15:41:58 --> Severity: Notice  --> Undefined property: stdClass::$listing_expires /Users/crivion/www/flippa/application/views/single-listing.php 12
ERROR - 3rd December 2012 15:49:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 25
ERROR - 3rd December 2012 15:50:23 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 26
ERROR - 3rd December 2012 15:50:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 27
ERROR - 3rd December 2012 15:51:14 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 27
ERROR - 3rd December 2012 15:51:57 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 25
ERROR - 3rd December 2012 15:53:13 --> Severity: Notice  --> Undefined variable: bids_count /Users/crivion/www/flippa/application/views/sidebar-single.php 10
ERROR - 3rd December 2012 15:54:08 --> Severity: Notice  --> Undefined property: CI_DB_mysql_result::$starting /Users/crivion/www/flippa/application/controllers/listings.php 28
ERROR - 3rd December 2012 16:01:10 --> Severity: Notice  --> Undefined property: CI_DB_mysql_result::$starting /Users/crivion/www/flippa/application/controllers/listings.php 30
ERROR - 3rd December 2012 16:01:10 --> Severity: Notice  --> Undefined variable: last_bid_plus /Users/crivion/www/flippa/application/views/sidebar-single.php 15
ERROR - 3rd December 2012 16:01:18 --> Severity: Notice  --> Undefined variable: last_bid_plus /Users/crivion/www/flippa/application/views/sidebar-single.php 15
ERROR - 3rd December 2012 16:47:34 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 3rd December 2012 16:47:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/crivion/www/flippa/application/views/sidebar-single.php 37
ERROR - 3rd December 2012 16:48:22 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 3rd December 2012 16:48:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 33
ERROR - 3rd December 2012 16:48:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 34
ERROR - 3rd December 2012 16:49:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 33
ERROR - 3rd December 2012 16:49:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 34
ERROR - 3rd December 2012 16:49:41 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 33
ERROR - 3rd December 2012 16:49:41 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/listings.php 34
ERROR - 3rd December 2012 16:55:20 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 3rd December 2012 17:03:38 --> Unable to load the requested class: forms
ERROR - 3rd December 2012 17:03:42 --> Unable to load the requested class: form
ERROR - 3rd December 2012 17:03:49 --> Severity: Notice  --> Undefined variable: movie_info /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:03:49 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:03:49 --> Severity: Notice  --> Undefined variable: movie_comments /Users/crivion/www/flippa/application/views/single-listing.php 37
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Undefined variable: movie_info /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:04:18 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:06:02 --> Severity: Notice  --> Undefined variable: movie_info /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:06:02 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:06:02 --> Severity: Notice  --> Undefined variable: comments /Users/crivion/www/flippa/application/views/single-listing.php 37
ERROR - 3rd December 2012 17:06:08 --> Severity: Notice  --> Undefined variable: movie_info /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:06:08 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 28
ERROR - 3rd December 2012 17:10:59 --> Query error: Unknown column 'movID' in 'field list'
ERROR - 3rd December 2012 17:12:08 --> Query error: Unknown column 'listingID' in 'field list'
ERROR - 3rd December 2012 17:12:10 --> Query error: Unknown column 'listingID' in 'field list'
ERROR - 3rd December 2012 17:12:40 --> Severity: Warning  --> _() expects exactly 1 parameter, 2 given /Users/crivion/www/flippa/application/controllers/listings.php 105
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:44 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:47 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 41
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:14:52 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 42
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 43
ERROR - 3rd December 2012 17:16:12 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/single-listing.php 44
ERROR - 3rd December 2012 17:19:35 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 3rd December 2012 18:20:21 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:21 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:21 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:21 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:42 --> Severity: Notice  --> Undefined property: stdClass::$cID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:42 --> Severity: Notice  --> Undefined property: stdClass::$cID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:42 --> Severity: Notice  --> Undefined property: stdClass::$cID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:20:42 --> Severity: Notice  --> Undefined property: stdClass::$cID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:21:05 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:21:05 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:21:05 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 18:21:05 --> Severity: Notice  --> Undefined property: stdClass::$commID /Users/crivion/www/flippa/application/views/single-listing.php 63
ERROR - 3rd December 2012 22:28:38 --> Query error: Table 'flippa.playlists' doesn't exist
