<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 7th February 2017 06:14:29 --> Severity: Notice  --> Undefined index: output /Users/crivion/Sites/local.flippa/application/controllers/home.php 279
ERROR - 7th February 2017 06:21:42 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Sites/local.flippa/application/controllers/home.php 256
ERROR - 7th February 2017 06:21:42 --> Severity: Notice  --> Undefined variable: output /Users/crivion/Sites/local.flippa/application/views/analytics-select-profile.php 10
