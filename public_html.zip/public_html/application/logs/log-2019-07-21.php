<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 21st July 2019 00:26:28 --> Query error: Table 'aperozco_BusWD.opts' doesn't exist
ERROR - 21st July 2019 02:08:07 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 21st July 2019 02:08:08 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 21st July 2019 05:21:23 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 21st July 2019 05:36:19 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 21st July 2019 18:28:47 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
