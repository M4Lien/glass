<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 15th October 2012 09:03:24 --> Severity: Notice  --> Undefined variable: tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:03:32 --> Severity: Notice  --> Undefined property: CI_Loader::$tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:05:48 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/welcome.php 23
ERROR - 15th October 2012 09:05:48 --> Severity: Notice  --> Undefined property: CI_Loader::$tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:05:56 --> Severity: Notice  --> Undefined property: CI_Loader::$tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:06:05 --> Severity: Notice  --> Undefined property: CI_Loader::$tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:06:10 --> Severity: Notice  --> Undefined property: CI_Loader::$tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:06:20 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:06:25 --> Severity: Notice  --> Undefined property: CI_Loader::$data /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:17:17 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Desktop/localwp/application/controllers/welcome.php 24
ERROR - 15th October 2012 09:17:17 --> Severity: Notice  --> Undefined variable: tables /Users/crivion/Desktop/localwp/application/views/welcome_message.php 3
ERROR - 15th October 2012 09:18:10 --> Severity: Notice  --> Undefined property: Welcome::$Tables /Users/crivion/Desktop/localwp/application/controllers/welcome.php 24
ERROR - 15th October 2012 09:43:25 --> Severity: Warning  --> require_once(header.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory /Users/crivion/Desktop/localwp/application/controllers/Home.php 1
ERROR - 15th October 2012 09:43:34 --> Severity: Warning  --> require_once(header.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory /Users/crivion/Desktop/localwp/application/controllers/Home.php 1
ERROR - 15th October 2012 15:29:34 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 15:29:38 --> Severity: Notice  --> Undefined variable: movies_query /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 19
ERROR - 15th October 2012 15:30:07 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 15:44:19 --> Severity: Notice  --> Undefined variable: featured_movies /Users/crivion/Desktop/localwp/application/views/home.php 6
ERROR - 15th October 2012 15:44:29 --> Severity: Notice  --> Undefined variable: featured_movies /Users/crivion/Desktop/localwp/application/views/home.php 6
ERROR - 15th October 2012 15:45:24 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/Desktop/localwp/application/controllers/Home.php 13
ERROR - 15th October 2012 15:45:29 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$query /Users/crivion/Desktop/localwp/application/controllers/Home.php 13
ERROR - 15th October 2012 15:47:48 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 10
ERROR - 15th October 2012 15:47:48 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:47:48 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:47:55 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 10
ERROR - 15th October 2012 15:47:55 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:47:55 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:47:59 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 10
ERROR - 15th October 2012 15:47:59 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:47:59 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:48:05 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 10
ERROR - 15th October 2012 15:48:05 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:48:05 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:48:10 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 10
ERROR - 15th October 2012 15:48:10 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:48:10 --> Severity: Notice  --> Undefined variable: i /Users/crivion/Desktop/localwp/application/views/home.php 13
ERROR - 15th October 2012 15:50:56 --> Severity: Notice  --> Undefined property: stdClass::$thumnail /Users/crivion/Desktop/localwp/application/views/home.php 9
ERROR - 15th October 2012 15:52:19 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 15:52:37 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 15:54:52 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 15:57:40 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 16:22:19 --> Severity: Notice  --> Use of undefined constant SITE - assumed 'SITE' /Users/crivion/Desktop/localwp/application/views/join-now.php 8
ERROR - 15th October 2012 17:51:08 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/Desktop/localwp/application/views/watch-movies.php 7
ERROR - 15th October 2012 20:13:49 --> Query error: Unknown column 'users' in 'where clause'
ERROR - 15th October 2012 20:13:49 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/Users.php:17) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 15th October 2012 20:14:56 --> Query error: Unknown column 'users' in 'where clause'
ERROR - 15th October 2012 20:14:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/Users.php:17) /Users/crivion/Desktop/localwp/system/core/Common.php 442
ERROR - 15th October 2012 21:06:58 --> Severity: Notice  --> Undefined property: Users::$set /Users/crivion/Desktop/localwp/application/controllers/Users.php 45
ERROR - 15th October 2012 21:08:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/Users.php:17) /Users/crivion/Desktop/localwp/system/libraries/Session.php 675
ERROR - 15th October 2012 21:12:08 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/Users.php:17) /Users/crivion/Desktop/localwp/system/libraries/Session.php 675
ERROR - 15th October 2012 21:12:27 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/Desktop/localwp/application/controllers/Users.php:17) /Users/crivion/Desktop/localwp/system/libraries/Session.php 675
ERROR - 15th October 2012 21:25:34 --> Severity: Notice  --> Undefined property: Users::$session /Users/crivion/Desktop/localwp/application/controllers/Users.php 8
ERROR - 15th October 2012 21:27:14 --> Severity: Notice  --> Undefined property: Users::$session /Users/crivion/Desktop/localwp/application/controllers/Users.php 8
ERROR - 15th October 2012 21:28:58 --> Severity: Notice  --> Undefined property: Users::$load /Users/crivion/Desktop/localwp/application/controllers/Users.php 8
ERROR - 15th October 2012 21:30:16 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in /Users/crivion/Desktop/localwp/application/controllers/Users.php on line 14 and defined /Users/crivion/Desktop/localwp/system/libraries/Session.php 431
ERROR - 15th October 2012 21:30:16 --> Severity: Notice  --> Undefined variable: item /Users/crivion/Desktop/localwp/system/libraries/Session.php 433
ERROR - 15th October 2012 21:32:18 --> Severity: Notice  --> Undefined property: Users::$session /Users/crivion/Desktop/localwp/application/controllers/Users.php 11
ERROR - 15th October 2012 21:45:29 --> Severity: Notice  --> Undefined variable: login_message /Users/crivion/Desktop/localwp/application/views/sidebar.php 4
ERROR - 15th October 2012 21:52:02 --> Query error: Table 'sidereel.crivions' doesn't exist
ERROR - 15th October 2012 22:03:50 --> Severity: Notice  --> Undefined variable: CI /Users/crivion/Desktop/localwp/application/views/sidebar.php 5
ERROR - 15th October 2012 22:03:50 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/sidebar.php 5
