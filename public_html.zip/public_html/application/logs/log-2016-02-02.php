<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2nd February 2016 13:26:00 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 2nd February 2016 13:26:00 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 2nd February 2016 13:26:00 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/newlisting.php 41
ERROR - 2nd February 2016 13:27:14 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 2nd February 2016 13:27:14 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 2nd February 2016 13:27:14 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/newlisting.php 41
