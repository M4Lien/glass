<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 21st October 2014 14:39:26 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 14:39:26 --> Unable to connect to the database
ERROR - 21st October 2014 14:39:26 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 14:39:26 --> Unable to connect to the database
ERROR - 21st October 2014 14:39:26 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 14:39:26 --> Unable to connect to the database
ERROR - 21st October 2014 14:39:26 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 14:39:26 --> Unable to connect to the database
ERROR - 21st October 2014 19:37:59 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 19:37:59 --> Unable to connect to the database
ERROR - 21st October 2014 19:38:01 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No such file or directory /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 19:38:01 --> Unable to connect to the database
ERROR - 21st October 2014 19:40:46 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): Too many levels of symbolic links /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 19:40:46 --> Unable to connect to the database
ERROR - 21st October 2014 19:40:47 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): Too many levels of symbolic links /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 19:40:47 --> Unable to connect to the database
ERROR - 21st October 2014 20:59:31 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): Too many levels of symbolic links /Users/crivion/Sites/local.flippa/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 21st October 2014 20:59:31 --> Unable to connect to the database
