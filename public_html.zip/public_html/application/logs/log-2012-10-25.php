<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 25th October 2012 17:21:03 --> Severity: Notice  --> Undefined variable: FMovie /Users/crivion/Desktop/localwp/application/views/watch-movies.php 14
ERROR - 25th October 2012 17:21:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 14
ERROR - 25th October 2012 17:21:03 --> Severity: Notice  --> Undefined variable: FMovie /Users/crivion/Desktop/localwp/application/views/watch-movies.php 15
ERROR - 25th October 2012 17:21:03 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Desktop/localwp/application/views/watch-movies.php 15
ERROR - 25th October 2012 17:44:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN `genres` ON `genres`.`genreID` = `movies`.`genres`
WHERE `filmID` =  1' at line 2
ERROR - 25th October 2012 17:48:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`IN` movies.genres
WHERE `filmID` =  1' at line 3
ERROR - 25th October 2012 17:50:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM genres WHERE genreID = genres)
FROM (`movies`)
JOIN `genres` ON `genres`.`g' at line 1
ERROR - 25th October 2012 17:51:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM genres WHERE genreID = genres)
WHERE `filmID` =  1' at line 1
ERROR - 25th October 2012 17:51:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM genres WHERE genreID = genres)
FROM (`movies`)
WHERE `filmID` =  1' at line 1
ERROR - 25th October 2012 17:51:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM genres WHERE genreID = genres)
WHERE `filmID` =  1' at line 1
ERROR - 25th October 2012 17:51:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM genres WHERE genreID = genres)
FROM (`movies`)
WHERE `filmID` =  1' at line 1
ERROR - 25th October 2012 17:56:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM (`movies`)
WHERE `filmID` =  1' at line 2
ERROR - 25th October 2012 17:56:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'genres)
FROM (`movies`)
WHERE `filmID` =  1' at line 1
ERROR - 25th October 2012 18:16:13 --> Query error: No tables used
ERROR - 25th October 2012 18:17:11 --> Severity: Notice  --> Undefined property: CI_DB_mysql_driver::$last_query /Users/crivion/Desktop/localwp/application/controllers/WatchMovies.php 14
ERROR - 25th October 2012 18:24:00 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/application/views/watch-movies.php 28
ERROR - 25th October 2012 18:24:00 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/application/views/watch-movies.php 28
ERROR - 25th October 2012 18:24:10 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/application/views/watch-movies.php 28
ERROR - 25th October 2012 18:24:10 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Desktop/localwp/application/views/watch-movies.php 28
