<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 9th February 2013 20:29:09 --> Severity: Warning  --> curl_error(): 22 is not a valid cURL handle resource /Users/crivion/www/localwp/application/helpers/get_alexa_helper.php 15
