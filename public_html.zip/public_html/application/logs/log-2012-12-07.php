<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 7th December 2012 13:49:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' as ld)
FROM (`listings`)
WHERE `list_uID` = 14' at line 1
ERROR - 7th December 2012 13:52:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' as ld)
FROM (`listings`)
WHERE `list_uID` = 14' at line 1
ERROR - 7th December 2012 13:52:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '') as ld
FROM (`listings`)
WHERE `list_uID` = 14' at line 1
ERROR - 7th December 2012 13:59:10 --> Severity: Notice  --> Undefined variable: tuser /Users/crivion/www/flippa/application/views/user-profiles.php 16
ERROR - 7th December 2012 13:59:10 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/user-profiles.php 16
ERROR - 7th December 2012 13:59:14 --> Severity: Notice  --> Undefined property: stdClass::$tl /Users/crivion/www/flippa/application/views/user-profiles.php 16
ERROR - 7th December 2012 14:00:03 --> Severity: Notice  --> Undefined property: stdClass::$tl /Users/crivion/www/flippa/application/views/user-profiles.php 16
ERROR - 7th December 2012 14:03:25 --> Severity: Warning  --> Missing argument 2 for Listings::getByPrice(), called in /Users/crivion/www/flippa/application/controllers/websites.php on line 74 and defined /Users/crivion/www/flippa/application/models/Listings.php 140
ERROR - 7th December 2012 14:03:25 --> Severity: Notice  --> Undefined variable: filter /Users/crivion/www/flippa/application/models/Listings.php 143
ERROR - 7th December 2012 14:03:25 --> Severity: Notice  --> Undefined variable: filter /Users/crivion/www/flippa/application/models/Listings.php 145
ERROR - 7th December 2012 14:03:33 --> Severity: Warning  --> Missing argument 2 for Listings::getByPrice(), called in /Users/crivion/www/flippa/application/controllers/websites.php on line 74 and defined /Users/crivion/www/flippa/application/models/Listings.php 140
ERROR - 7th December 2012 14:03:33 --> Severity: Notice  --> Undefined variable: filter /Users/crivion/www/flippa/application/models/Listings.php 143
ERROR - 7th December 2012 14:03:33 --> Severity: Notice  --> Undefined variable: filter /Users/crivion/www/flippa/application/models/Listings.php 145
ERROR - 7th December 2012 15:03:53 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:03:57 --> Query error: Table 'flippa.genres' doesn't exist
ERROR - 7th December 2012 15:04:21 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 7th December 2012 15:05:16 --> Query error: Unknown column 'listings.listing_uri' in 'field list'
ERROR - 7th December 2012 15:05:21 --> Query error: Unknown column 'listings.filmID' in 'on clause'
ERROR - 7th December 2012 15:05:51 --> Severity: Notice  --> Undefined property: stdClass::$film_title /Users/crivion/www/flippa/application/views/admin-comments.php 29
ERROR - 7th December 2012 15:05:51 --> Severity: Notice  --> Undefined property: stdClass::$filmID /Users/crivion/www/flippa/application/views/admin-comments.php 29
ERROR - 7th December 2012 15:05:51 --> Severity: Notice  --> Undefined property: stdClass::$film_title /Users/crivion/www/flippa/application/views/admin-comments.php 29
ERROR - 7th December 2012 15:06:39 --> Severity: Notice  --> Undefined property: stdClass::$listing_title /Users/crivion/www/flippa/application/views/admin-comments.php 29
ERROR - 7th December 2012 15:06:39 --> Severity: Notice  --> Undefined property: stdClass::$listing_title /Users/crivion/www/flippa/application/views/admin-comments.php 29
ERROR - 7th December 2012 15:08:48 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:10:16 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:10:31 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:10:48 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:10:57 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:12:28 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 7th December 2012 15:15:11 --> Query error: No tables used
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 13
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:36 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 32
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:15:55 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 31
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Undefined variable: m /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:18:51 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:12 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/admin.php 33
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:16 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$status /Users/crivion/www/flippa/application/views/admin.php 34
ERROR - 7th December 2012 15:19:30 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:40 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:40 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:40 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:19:40 --> Severity: Notice  --> Undefined property: stdClass::$listing_date /Users/crivion/www/flippa/application/views/admin.php 35
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 607
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 608
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 612
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 613
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 620
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 621
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 629
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 642
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 643
ERROR - 7th December 2012 15:28:22 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 647
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 607
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 608
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 612
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 613
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 620
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 621
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 629
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 642
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 643
ERROR - 7th December 2012 15:37:26 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/www/flippa/application/controllers/users.php 647
ERROR - 7th December 2012 15:46:31 --> Query error: Unknown column 'listing_type' in 'field list'
ERROR - 7th December 2012 16:03:45 --> Severity: Notice  --> Undefined variable: data /Users/crivion/www/flippa/application/controllers/admin.php 38
ERROR - 7th December 2012 16:04:13 --> Severity: Notice  --> Undefined variable: data /Users/crivion/www/flippa/application/controllers/admin.php 38
ERROR - 7th December 2012 16:23:07 --> Severity: Notice  --> Undefined property: stdClass::$bin /Users/crivion/www/flippa/application/views/mylistings.php 32
ERROR - 7th December 2012 16:23:07 --> Severity: Notice  --> Undefined property: stdClass::$listing_expires /Users/crivion/www/flippa/application/views/mylistings.php 34
ERROR - 7th December 2012 16:23:07 --> Severity: Notice  --> Undefined property: stdClass::$relist /Users/crivion/www/flippa/application/views/mylistings.php 37
ERROR - 7th December 2012 16:23:23 --> Severity: Notice  --> Undefined property: stdClass::$bin /Users/crivion/www/flippa/application/views/mylistings.php 31
ERROR - 7th December 2012 16:23:23 --> Severity: Notice  --> Undefined property: stdClass::$listing_expires /Users/crivion/www/flippa/application/views/mylistings.php 33
ERROR - 7th December 2012 16:23:23 --> Severity: Notice  --> Undefined property: stdClass::$relist /Users/crivion/www/flippa/application/views/mylistings.php 36
ERROR - 7th December 2012 16:23:39 --> Severity: Notice  --> Undefined property: stdClass::$bin /Users/crivion/www/flippa/application/views/mylistings.php 31
ERROR - 7th December 2012 16:23:39 --> Severity: Notice  --> Undefined property: stdClass::$relist /Users/crivion/www/flippa/application/views/mylistings.php 36
ERROR - 7th December 2012 16:23:50 --> Severity: Notice  --> Undefined property: stdClass::$price /Users/crivion/www/flippa/application/views/mylistings.php 31
ERROR - 7th December 2012 16:23:50 --> Severity: Notice  --> Undefined property: stdClass::$relist /Users/crivion/www/flippa/application/views/mylistings.php 36
ERROR - 7th December 2012 16:24:02 --> Severity: Notice  --> Undefined property: stdClass::$relist /Users/crivion/www/flippa/application/views/mylistings.php 36
ERROR - 7th December 2012 16:24:43 --> Severity: Notice  --> Undefined property: stdClass::$paylink /Users/crivion/www/flippa/application/views/mylistings.php 36
ERROR - 7th December 2012 16:30:17 --> Severity: Notice  --> Undefined property: stdClass::$featured /Users/crivion/www/flippa/application/views/mylistings.php 30
ERROR - 7th December 2012 16:33:14 --> Severity: Notice  --> Undefined property: Payments::$script /Users/crivion/www/flippa/application/controllers/payments.php 158
ERROR - 7th December 2012 17:20:34 --> Severity: Warning  --> Wrong parameter count for explode() /Users/crivion/www/flippa/application/controllers/users.php 349
ERROR - 7th December 2012 17:20:34 --> Severity: Warning  --> end() [<a href='function.end'>function.end</a>]: Passed variable is not an array or object /Users/crivion/www/flippa/application/controllers/users.php 350
ERROR - 7th December 2012 17:20:34 --> Severity: Warning  --> imagejpeg() [<a href='function.imagejpeg'>function.imagejpeg</a>]: Unable to open '/Users/crivion/www/flippa/uploads/6fe50f0f183eb90f30ca487bfdf9c44c./phpqQYwd6' for writing: No such file or directory /Users/crivion/www/flippa/system/libraries/Image_lib.php 1209
ERROR - 7th December 2012 17:20:34 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 7th December 2012 17:20:34 --> Severity: Warning  --> imagejpeg() [<a href='function.imagejpeg'>function.imagejpeg</a>]: Unable to open '/Users/crivion/www/flippa/uploads/6fe50f0f183eb90f30ca487bfdf9c44c./phpqQYwd6' for writing: No such file or directory /Users/crivion/www/flippa/system/libraries/Image_lib.php 1209
ERROR - 7th December 2012 17:20:34 --> Unable to save the image.  Please make sure the image and file directory are writable.
ERROR - 7th December 2012 15:51:54 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: YES) /home/domainas/public_html/system/database/drivers/mysql/mysql_driver.php 91
ERROR - 7th December 2012 15:51:54 --> Unable to connect to the database
ERROR - 7th December 2012 16:13:05 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/domainas/public_html/application/views/sidebar-single.php 50
ERROR - 7th December 2012 16:13:05 --> Severity: Warning  --> number_format() expects parameter 1 to be double, string given /home/domainas/public_html/application/views/sidebar-single.php 51
