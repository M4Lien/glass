<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 27th November 2012 13:53:12 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 27th November 2012 13:53:18 --> Query error: Table 'flippa.movies' doesn't exist
ERROR - 27th November 2012 13:54:57 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 27th November 2012 13:57:30 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 27th November 2012 13:57:33 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 27th November 2012 13:57:45 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 27th November 2012 13:57:55 --> Severity: Notice  --> Undefined variable: movies /Users/crivion/www/flippa/application/views/admin.php 12
ERROR - 27th November 2012 14:45:20 --> Severity: Notice  --> Undefined variable: handle /Users/crivion/www/flippa/application/models/ValidateURL.php 24
ERROR - 27th November 2012 14:45:20 --> Severity: Warning  --> curl_setopt(): supplied argument is not a valid cURL handle resource /Users/crivion/www/flippa/application/models/ValidateURL.php 24
ERROR - 27th November 2012 14:45:20 --> Severity: Notice  --> Undefined variable: handle /Users/crivion/www/flippa/application/models/ValidateURL.php 25
ERROR - 27th November 2012 14:45:20 --> Severity: Warning  --> curl_setopt(): supplied argument is not a valid cURL handle resource /Users/crivion/www/flippa/application/models/ValidateURL.php 25
ERROR - 27th November 2012 14:45:20 --> Severity: Notice  --> Undefined variable: handle /Users/crivion/www/flippa/application/models/ValidateURL.php 26
ERROR - 27th November 2012 14:45:20 --> Severity: Warning  --> curl_setopt(): supplied argument is not a valid cURL handle resource /Users/crivion/www/flippa/application/models/ValidateURL.php 26
ERROR - 27th November 2012 14:48:11 --> Severity: Notice  --> Undefined offset:  1 /Users/crivion/www/flippa/application/models/ValidateURL.php 34
ERROR - 27th November 2012 15:16:37 --> Severity: Notice  --> Undefined variable: basic_icon /Users/crivion/www/flippa/application/views/newlisting.php 34
ERROR - 27th November 2012 15:16:37 --> Severity: Notice  --> Undefined variable: desc_icon /Users/crivion/www/flippa/application/views/newlisting.php 35
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/newlisting.php 34
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/newlisting.php 35
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: siteage_icon /Users/crivion/www/flippa/application/views/newlisting.php 36
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/newlisting.php 36
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: revenue_icon /Users/crivion/www/flippa/application/views/newlisting.php 37
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/newlisting.php 37
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: pricing_icon /Users/crivion/www/flippa/application/views/newlisting.php 38
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/newlisting.php 38
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: traffic_icon /Users/crivion/www/flippa/application/views/newlisting.php 39
ERROR - 27th November 2012 15:33:22 --> Severity: Notice  --> Undefined variable: listingID /Users/crivion/www/flippa/application/views/newlisting.php 39
ERROR - 27th November 2012 15:41:26 --> Severity: Notice  --> Undefined variable: payments_icon /Users/crivion/www/flippa/application/views/newlisting.php 42
ERROR - 27th November 2012 21:20:57 --> Severity: Notice  --> Undefined variable: v /Users/crivion/www/flippa/application/controllers/users.php 327
ERROR - 27th November 2012 22:28:26 --> Query error: Unknown column 'sb' in 'field list'
ERROR - 27th November 2012 22:29:48 --> Query error: Unknown column 'sb' in 'field list'
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: basic_icon /Users/crivion/www/flippa/application/views/newlisting.php 45
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: desc_icon /Users/crivion/www/flippa/application/views/newlisting.php 46
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: siteage_icon /Users/crivion/www/flippa/application/views/newlisting.php 47
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: revenue_icon /Users/crivion/www/flippa/application/views/newlisting.php 48
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: pricing_icon /Users/crivion/www/flippa/application/views/newlisting.php 49
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: traffic_icon /Users/crivion/www/flippa/application/views/newlisting.php 50
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: monetization_icon /Users/crivion/www/flippa/application/views/newlisting.php 53
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: unique_icon /Users/crivion/www/flippa/application/views/newlisting.php 54
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: payments_icon /Users/crivion/www/flippa/application/views/newlisting.php 55
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: tags_icon /Users/crivion/www/flippa/application/views/newlisting.php 56
ERROR - 27th November 2012 22:54:17 --> Severity: Notice  --> Undefined variable: verify_icon /Users/crivion/www/flippa/application/views/newlisting.php 57
ERROR - 27th November 2012 23:04:43 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:04:52 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:05:24 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:05:25 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:05:25 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:05:32 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:06:18 --> Query error: Unknown column 'listing_uID' in 'where clause'
ERROR - 27th November 2012 23:22:19 --> Query error: Table 'flippa.listing' doesn't exist
ERROR - 27th November 2012 23:23:26 --> Severity: Notice  --> Undefined property: stdClass::$start /Users/crivion/www/flippa/application/controllers/users.php 286
ERROR - 27th November 2012 23:28:12 --> Severity: Notice  --> Undefined variable: pricing /Users/crivion/www/flippa/application/controllers/users.php 288
