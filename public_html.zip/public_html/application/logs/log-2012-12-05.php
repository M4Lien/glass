<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 5th December 2012 13:59:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'FROM listings WHERE list_uID = 14))
                        ORDER BY bidID DESC' at line 4
ERROR - 5th December 2012 14:02:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
                        ORDER BY bidID DESC' at line 4
ERROR - 5th December 2012 14:02:17 --> Query error: No tables used
ERROR - 5th December 2012 14:06:55 --> Severity: Notice  --> Undefined property: stdClass::$bid_amount /Users/crivion/www/flippa/application/views/user-offers.php 26
ERROR - 5th December 2012 14:06:55 --> Severity: Notice  --> Undefined property: stdClass::$bid_amount /Users/crivion/www/flippa/application/views/user-offers.php 26
ERROR - 5th December 2012 14:06:55 --> Severity: Notice  --> Undefined property: stdClass::$bid_amount /Users/crivion/www/flippa/application/views/user-offers.php 26
ERROR - 5th December 2012 14:07:14 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 5th December 2012 14:07:16 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 5th December 2012 14:17:19 --> Severity: Notice  --> Undefined property: stdClass::$bidID /Users/crivion/www/flippa/application/views/user-offers.php 36
ERROR - 5th December 2012 14:17:19 --> Severity: Notice  --> Undefined property: stdClass::$bidID /Users/crivion/www/flippa/application/views/user-offers.php 36
ERROR - 5th December 2012 14:17:19 --> Severity: Notice  --> Undefined property: stdClass::$bidID /Users/crivion/www/flippa/application/views/user-offers.php 36
ERROR - 5th December 2012 14:17:26 --> Query error: Unknown column 'biID' in 'field list'
ERROR - 5th December 2012 14:29:54 --> Query error: Unknown column 'bidderID' in 'where clause'
ERROR - 5th December 2012 14:32:35 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 5th December 2012 14:35:20 --> Query error: Unknown column 'bidID' in 'where clause'
ERROR - 5th December 2012 16:06:39 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 5th December 2012 16:21:52 --> Severity: Notice  --> Undefined property: stdClass::$username /Users/crivion/www/flippa/application/views/user-inbox.php 24
ERROR - 5th December 2012 16:21:52 --> Severity: Notice  --> Undefined property: stdClass::$username /Users/crivion/www/flippa/application/views/user-inbox.php 24
ERROR - 5th December 2012 16:21:52 --> Severity: Notice  --> Undefined property: stdClass::$userID /Users/crivion/www/flippa/application/views/user-inbox.php 26
ERROR - 5th December 2012 16:23:57 --> Severity: Warning  --> preg_match() expects parameter 2 to be string, array given /Users/crivion/www/flippa/system/database/DB_active_rec.php 331
ERROR - 5th December 2012 16:23:57 --> Query error: Unknown column 'Array' in 'on clause'
ERROR - 5th December 2012 16:23:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Users/crivion/www/flippa/system/core/Exceptions.php:185) /Users/crivion/www/flippa/system/core/Common.php 442
ERROR - 5th December 2012 16:24:33 --> Severity: Notice  --> Undefined property: stdClass::$userID /Users/crivion/www/flippa/application/views/user-inbox.php 26
ERROR - 5th December 2012 16:25:17 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 5th December 2012 16:25:53 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 5th December 2012 16:26:09 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 5th December 2012 16:28:52 --> Query error: Unknown column '0' in 'where clause'
ERROR - 5th December 2012 16:30:28 --> Query error: Unknown column '0' in 'where clause'
ERROR - 5th December 2012 16:57:14 --> Query error: Table 'flippa.playlists' doesn't exist
ERROR - 5th December 2012 16:57:58 --> Severity: Notice  --> Undefined variable: data /Users/crivion/www/flippa/application/controllers/users.php 112
ERROR - 5th December 2012 17:01:34 --> Severity: Notice  --> Undefined variable: uri_param /Users/crivion/www/flippa/application/controllers/websites.php 88
ERROR - 5th December 2012 17:59:07 --> The path to the image is not correct.
ERROR - 5th December 2012 17:59:07 --> Your server does not support the GD function required to process this type of image.
ERROR - 5th December 2012 18:01:59 --> The path to the image is not correct.
ERROR - 5th December 2012 18:01:59 --> Your server does not support the GD function required to process this type of image.
ERROR - 5th December 2012 18:11:21 --> Severity: Notice  --> Undefined variable: att /Users/crivion/www/flippa/application/views/sidebar-single.php 72
ERROR - 5th December 2012 18:12:49 --> Severity: Notice  --> Undefined property: CI_DB_mysql_result::$listingID /Users/crivion/www/flippa/application/controllers/listings.php 175
ERROR - 5th December 2012 18:24:19 --> Query error: No tables used
