<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 23rd July 2019 02:34:50 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 03:39:17 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 03:39:23 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 04:38:36 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 04:38:38 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 04:38:43 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 04:38:49 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 04:38:55 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 04:39:03 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 05:07:25 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 08:40:47 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 08:40:54 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 10:26:15 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 17:50:09 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 19:17:30 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 20:03:16 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
ERROR - 23rd July 2019 21:26:27 --> Query error: Table 'aperozco_BusWD.listings' doesn't exist
