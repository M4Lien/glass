<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 24th May 2015 00:00:30 --> Severity: Notice  --> Undefined variable: settings /Users/crivion/Sites/local.flippa/application/controllers/payments.php 63
ERROR - 24th May 2015 00:00:30 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/payments.php 63
ERROR - 24th May 2015 00:00:56 --> Severity: Notice  --> Undefined variable: settings /Users/crivion/Sites/local.flippa/application/controllers/payments.php 63
ERROR - 24th May 2015 00:00:56 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/controllers/payments.php 63
ERROR - 24th May 2015 00:33:01 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 708
ERROR - 24th May 2015 00:33:01 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 709
ERROR - 24th May 2015 00:50:08 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 727
ERROR - 24th May 2015 00:50:08 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 728
ERROR - 24th May 2015 01:12:04 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:12:04 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:12:16 --> Severity: Notice  --> Undefined property: stdClass::$tld /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:12:16 --> Severity: Notice  --> Undefined property: stdClass::$tld /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:12:17 --> Severity: Notice  --> Undefined property: stdClass::$tld /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:12:17 --> Severity: Notice  --> Undefined property: stdClass::$tld /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:12:27 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:12:27 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:13:44 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:13:44 --> Severity: Warning  --> strtoupper() expects parameter 1 to be string, object given /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:13:44 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:13:44 --> Severity: Warning  --> strtoupper() expects parameter 1 to be string, object given /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:13:44 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:13:44 --> Severity: Warning  --> strtoupper() expects parameter 1 to be string, object given /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 13
ERROR - 24th May 2015 01:13:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:13:53 --> Severity: Warning  --> strtoupper() expects parameter 1 to be string, object given /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:13:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:13:53 --> Severity: Warning  --> strtoupper() expects parameter 1 to be string, object given /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:13:53 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
ERROR - 24th May 2015 01:13:53 --> Severity: Warning  --> strtoupper() expects parameter 1 to be string, object given /Users/crivion/Sites/local.flippa/application/helpers/domain_extensions_helper.php 14
