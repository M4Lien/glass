<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 23rd January 2015 21:45:10 --> Query error: Table 'flippa.listings' doesn't exist
ERROR - 23rd January 2015 21:46:24 --> Severity: Warning  --> require_once(header.php): failed to open stream: No such file or directory /Users/crivion/Sites/local.flippa/system/core/Loader.php(829) : eval()'d code 1
ERROR - 23rd January 2015 21:46:25 --> Severity: Warning  --> require_once(header.php): failed to open stream: No such file or directory /Users/crivion/Sites/local.flippa/system/core/Loader.php(829) : eval()'d code 1
ERROR - 23rd January 2015 21:46:26 --> Severity: Warning  --> require_once(header.php): failed to open stream: No such file or directory /Users/crivion/Sites/local.flippa/system/core/Loader.php(829) : eval()'d code 1
ERROR - 23rd January 2015 21:46:27 --> Severity: Warning  --> require_once(header.php): failed to open stream: No such file or directory /Users/crivion/Sites/local.flippa/system/core/Loader.php(829) : eval()'d code 1
ERROR - 23rd January 2015 21:47:33 --> Query error: Unknown column 'starting_' in 'field list'
ERROR - 23rd January 2015 22:12:42 --> Query error: Field 'about' doesn't have a default value
ERROR - 23rd January 2015 22:13:58 --> Query error: Field 'about' doesn't have a default value
ERROR - 23rd January 2015 22:14:36 --> Query error: Field 'about' doesn't have a default value
ERROR - 23rd January 2015 22:14:57 --> Query error: Field 'about' doesn't have a default value
ERROR - 23rd January 2015 22:16:18 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 23rd January 2015 22:16:18 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 23rd January 2015 22:18:20 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 695
ERROR - 23rd January 2015 22:18:20 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 696
ERROR - 23rd January 2015 22:18:28 --> Query error: Field 'listing_title' doesn't have a default value
ERROR - 23rd January 2015 22:20:38 --> Query error: Field 'bin' doesn't have a default value
ERROR - 23rd January 2015 23:18:40 --> Severity: Warning  --> file_get_contents(http://crivion.com/verify_21.txt): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 /Users/crivion/Sites/local.flippa/application/controllers/users.php 1225
ERROR - 23rd January 2015 23:18:40 --> Query error: Unknown column 'verify_file' in 'field list'
ERROR - 23rd January 2015 23:21:02 --> Severity: Warning  --> file_get_contents(http://crivion.com/verify_21.txt): failed to open stream: HTTP request failed! HTTP/1.1 404 Not Found
 /Users/crivion/Sites/local.flippa/application/controllers/users.php 1225
ERROR - 23rd January 2015 23:21:02 --> Query error: Unknown column 'verify_file' in 'field list'
ERROR - 23rd January 2015 23:28:42 --> Query error: Unknown column 'verify_file' in 'field list'
ERROR - 23rd January 2015 23:28:49 --> Query error: Unknown column 'verify_file' in 'field list'
