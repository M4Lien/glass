<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 28th January 2015 19:17:40 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 697
ERROR - 28th January 2015 19:17:40 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 698
ERROR - 28th January 2015 19:18:07 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 697
ERROR - 28th January 2015 19:18:07 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 698
ERROR - 28th January 2015 19:18:34 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 697
ERROR - 28th January 2015 19:18:34 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 698
ERROR - 28th January 2015 19:18:46 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 697
ERROR - 28th January 2015 19:18:46 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 698
ERROR - 28th January 2015 19:18:51 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 697
ERROR - 28th January 2015 19:18:51 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 698
ERROR - 28th January 2015 19:19:45 --> Severity: Notice  --> Undefined variable: user /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:19:45 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:20:33 --> Severity: Notice  --> Undefined variable: user /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:20:33 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:20:33 --> Severity: Notice  --> Undefined variable: _SESSION /Users/crivion/Sites/local.flippa/application/views/sidebar.php 28
ERROR - 28th January 2015 19:21:07 --> Severity: Notice  --> Undefined variable: user /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:21:07 --> Severity: Notice  --> Trying to get property of non-object /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:30:23 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/views/sidebar.php 25
ERROR - 28th January 2015 19:30:46 --> Severity: 4096  --> Object of class stdClass could not be converted to string /Users/crivion/Sites/local.flippa/application/views/sidebar.php 26
ERROR - 28th January 2015 19:35:28 --> Severity: Notice  --> Undefined variable: id /Users/crivion/Sites/local.flippa/application/controllers/users.php 699
ERROR - 28th January 2015 19:35:28 --> Severity: Notice  --> Undefined variable: l /Users/crivion/Sites/local.flippa/application/controllers/users.php 700
ERROR - 28th January 2015 19:42:46 --> Severity: Notice  --> Undefined property: stdClass::$list_expires /Users/crivion/Sites/local.flippa/application/views/websites.php 21
ERROR - 28th January 2015 19:42:46 --> Severity: Notice  --> Undefined property: stdClass::$list_expires /Users/crivion/Sites/local.flippa/application/views/websites.php 21
ERROR - 28th January 2015 19:42:46 --> Severity: Notice  --> Undefined property: stdClass::$list_expires /Users/crivion/Sites/local.flippa/application/views/websites.php 21
ERROR - 28th January 2015 19:49:07 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$listing_status /Users/crivion/Sites/local.flippa/application/controllers/listings.php 133
ERROR - 28th January 2015 19:49:09 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$listing_status /Users/crivion/Sites/local.flippa/application/controllers/listings.php 133
ERROR - 28th January 2015 19:49:15 --> Severity: Notice  --> Undefined variable: li /Users/crivion/Sites/local.flippa/application/controllers/listings.php 133
ERROR - 28th January 2015 19:49:15 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$listing_status /Users/crivion/Sites/local.flippa/application/controllers/listings.php 134
ERROR - 28th January 2015 19:49:21 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$listing_status /Users/crivion/Sites/local.flippa/application/controllers/listings.php 134
ERROR - 28th January 2015 19:50:06 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Sites/local.flippa/application/controllers/listings.php 134
ERROR - 28th January 2015 19:50:16 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Sites/local.flippa/application/controllers/listings.php 134
ERROR - 28th January 2015 19:50:21 --> Severity: Notice  --> Undefined variable: data /Users/crivion/Sites/local.flippa/application/controllers/listings.php 134
ERROR - 28th January 2015 20:28:13 --> Query error: Unknown column 'list-type' in 'where clause'
ERROR - 28th January 2015 20:32:48 --> Severity: Notice  --> Undefined property: stdClass::$list_type /Users/crivion/Sites/local.flippa/application/views/websites.php 63
ERROR - 28th January 2015 20:32:56 --> Severity: Notice  --> Undefined variable: list_type /Users/crivion/Sites/local.flippa/application/views/websites.php 63
ERROR - 28th January 2015 20:33:17 --> Severity: Notice  --> Undefined variable: list_type /Users/crivion/Sites/local.flippa/application/views/websites.php 63
ERROR - 28th January 2015 20:41:27 --> Severity: Notice  --> Undefined variable: monetization /Users/crivion/Sites/local.flippa/application/controllers/websites.php 51
ERROR - 28th January 2015 20:41:27 --> Severity: Notice  --> Undefined variable: count /Users/crivion/Sites/local.flippa/application/models/listings.php 137
ERROR - 28th January 2015 20:41:27 --> Severity: Notice  --> Undefined variable: start /Users/crivion/Sites/local.flippa/application/models/listings.php 137
ERROR - 28th January 2015 20:42:05 --> Severity: Notice  --> Undefined variable: count /Users/crivion/Sites/local.flippa/application/models/listings.php 137
ERROR - 28th January 2015 20:42:05 --> Severity: Notice  --> Undefined variable: start /Users/crivion/Sites/local.flippa/application/models/listings.php 137
ERROR - 28th January 2015 20:42:29 --> Severity: Warning  --> Missing argument 2 for Listings::setMonetizationFilter(), called in /Users/crivion/Sites/local.flippa/application/controllers/websites.php on line 51 and defined /Users/crivion/Sites/local.flippa/application/models/listings.php 131
ERROR - 28th January 2015 20:42:29 --> Severity: Notice  --> Undefined variable: start /Users/crivion/Sites/local.flippa/application/models/listings.php 137
ERROR - 28th January 2015 20:43:07 --> Severity: Warning  --> Missing argument 2 for Listings::setMonetizationFilter(), called in /Users/crivion/Sites/local.flippa/application/controllers/websites.php on line 51 and defined /Users/crivion/Sites/local.flippa/application/models/listings.php 131
ERROR - 28th January 2015 20:43:07 --> Query error: Not unique table/alias: 'listings'
ERROR - 28th January 2015 20:43:12 --> Query error: Not unique table/alias: 'listings'
ERROR - 28th January 2015 20:43:14 --> Query error: Not unique table/alias: 'listings'
ERROR - 28th January 2015 20:43:30 --> Query error: Not unique table/alias: 'listings'
ERROR - 28th January 2015 20:43:30 --> Query error: Not unique table/alias: 'listings'
ERROR - 28th January 2015 20:43:30 --> Query error: Not unique table/alias: 'listings'
ERROR - 28th January 2015 20:44:02 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_driver::$last_query /Users/crivion/Sites/local.flippa/application/controllers/websites.php 115
ERROR - 28th January 2015 20:46:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '% 'affiliate%'
ORDER BY `listingID` DESC' at line 6
ERROR - 28th January 2015 20:50:13 --> Severity: Notice  --> Undefined variable: key /Users/crivion/Sites/local.flippa/application/models/listings.php 153
ERROR - 28th January 2015 20:51:34 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_result::$db /Users/crivion/Sites/local.flippa/application/controllers/websites.php 117
ERROR - 28th January 2015 21:13:40 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_driver::$last_query /Users/crivion/Sites/local.flippa/application/controllers/websites.php 116
