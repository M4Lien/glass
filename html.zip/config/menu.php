<?php
return array(
	'home',
	'user',
	'attendance',
	'holiday',
	'leave',
	'payroll',
	'award',
	'daily_report',
	'announcement',
	'expense',
	'task',
	'ticket',
	'message',
	'job',
	);