<?php return array (
  'announcement' => 
  array (
    'limit' => '5',
    'extension' => 'pdf,rtf,txt,png,doc,docx,xls,xlsx,jpg,jpeg',
  ),
  'award' => 
  array (
    'limit' => '5',
    'extension' => 'pdf,rtf,txt,png,doc,docx,xls,xlsx,jpg,jpeg',
  ),
  'daily-report' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'expense' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'job' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'job-application' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'message' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'leave' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'ticket' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'ticket-reply' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'task' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'task-attachment' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'user-contract' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'user-document' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
  'user-qualification' => 
  array (
    'limit' => '5',
    'extension' => 'jpg,jpeg,pdf,rtf,txt,png,doc,docx,xls,xlsx',
  ),
);