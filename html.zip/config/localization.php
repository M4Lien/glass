<?php return array (
  'en' => 
  array (
    'localization' => 'English',
    'calendar' => 'en',
    'datatable' => 'English',
    'datepicker' => 'en',
    'datetimepicker' => 'en',
  ),
);