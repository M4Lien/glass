-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Nov 16, 2017 at 07:06 AM
-- Server version: 5.6.36-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ggafe4rwer6857`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `login_as_user_id` int(11) DEFAULT NULL,
  `user_agent` text COLLATE utf8_unicode_ci,
  `module` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `sub_module` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sub_module_id` int(11) DEFAULT NULL,
  `activity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `login_as_user_id` (`login_as_user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=562 ;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `user_id`, `login_as_user_id`, `user_agent`, `module`, `module_id`, `sub_module`, `sub_module_id`, `activity`, `ip`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'mail', NULL, 'updated', '103.255.6.97', '2017-06-12 19:13:33', '2017-06-12 19:13:33'),
(2, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'authentication', NULL, 'updated', '103.255.6.97', '2017-06-12 19:14:08', '2017-06-12 19:14:08'),
(3, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'currency', 1, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:14:27', '2017-06-12 19:14:27'),
(4, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'user', NULL, 'updated', '103.255.6.97', '2017-06-12 19:14:44', '2017-06-12 19:14:44'),
(5, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'leave_type', 1, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:42:13', '2017-06-12 19:42:13'),
(6, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'leave_type', 2, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:42:56', '2017-06-12 19:42:56'),
(7, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'leave_type', 3, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:45:22', '2017-06-12 19:45:22'),
(8, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'leave_type', 4, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:46:48', '2017-06-12 19:46:48'),
(9, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 19:47:44', '2017-06-12 19:47:44'),
(10, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 19:48:20', '2017-06-12 19:48:20'),
(11, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'shift', 1, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(12, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'menu', NULL, 'updated', '103.255.6.97', '2017-06-12 19:54:52', '2017-06-12 19:54:52'),
(13, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'role', 2, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:55:31', '2017-06-12 19:55:31'),
(14, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'role', 3, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 19:55:45', '2017-06-12 19:55:45'),
(15, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'permission', NULL, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 19:58:04', '2017-06-12 19:58:04'),
(16, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 11, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:07:11', '2017-06-12 20:07:11'),
(17, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 5, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:07:30', '2017-06-12 20:07:30'),
(18, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 6, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:07:44', '2017-06-12 20:07:44'),
(19, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 12, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:08:09', '2017-06-12 20:08:09'),
(20, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 8, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:08:36', '2017-06-12 20:08:36'),
(21, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 9, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:08:48', '2017-06-12 20:08:48'),
(22, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 10, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:09:01', '2017-06-12 20:09:01'),
(23, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 7, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:09:32', '2017-06-12 20:09:32'),
(24, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 2, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:09:42', '2017-06-12 20:09:42'),
(25, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 3, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:10:02', '2017-06-12 20:10:02'),
(26, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 4, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:10:21', '2017-06-12 20:10:21'),
(27, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 17, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 20:10:53', '2017-06-12 20:10:53'),
(28, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 18, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 20:11:10', '2017-06-12 20:11:10'),
(29, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 15, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:11:22', '2017-06-12 20:11:22'),
(30, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 16, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:11:32', '2017-06-12 20:11:32'),
(31, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 14, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:11:42', '2017-06-12 20:11:42'),
(32, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'designation', 13, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:12:05', '2017-06-12 20:12:05'),
(33, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'department', 3, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:12:44', '2017-06-12 20:12:44'),
(34, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'department', 2, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:12:52', '2017-06-12 20:12:52'),
(35, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'department', 6, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 20:13:02', '2017-06-12 20:13:02'),
(36, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'department', 9, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 20:14:38', '2017-06-12 20:14:38'),
(37, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'department', 9, NULL, NULL, 'deleted', '103.255.6.97', '2017-06-12 20:14:50', '2017-06-12 20:14:50'),
(38, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'location', 1, NULL, NULL, 'added', '103.255.6.97', '2017-06-12 20:16:48', '2017-06-12 20:16:48'),
(39, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'setup_guide', NULL, 'updated', '103.255.6.97', '2017-06-12 20:17:06', '2017-06-12 20:17:06'),
(40, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 1, 'location', 1, 'added', '103.255.6.97', '2017-06-12 20:52:05', '2017-06-12 20:52:05'),
(41, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'template', 1, NULL, NULL, 'updated', '103.255.6.97', '2017-06-12 21:41:42', '2017-06-12 21:41:42'),
(42, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.97', '2017-06-12 21:44:17', '2017-06-12 21:44:17'),
(45, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.97', '2017-06-12 21:48:16', '2017-06-12 21:48:16'),
(46, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.97', '2017-06-12 21:48:47', '2017-06-12 21:48:47'),
(49, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.97', '2017-06-12 21:50:30', '2017-06-12 21:50:30'),
(50, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 2, 'profile', NULL, 'updated', '103.255.6.97', '2017-06-12 21:54:36', '2017-06-12 21:54:36'),
(51, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 2, NULL, NULL, 'force_password_changed', '103.255.6.97', '2017-06-12 21:55:05', '2017-06-12 21:55:05'),
(54, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'system', NULL, 'updated', '103.255.6.97', '2017-06-12 21:56:01', '2017-06-12 21:56:01'),
(57, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.4', '2017-06-13 03:31:50', '2017-06-13 03:31:50'),
(58, 3, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.4', '2017-06-13 03:34:32', '2017-06-13 03:34:32'),
(59, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'profile', NULL, 'updated', '115.186.165.240', '2017-06-13 03:39:46', '2017-06-13 03:39:46'),
(60, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'contact', 3, 'added', '115.186.165.240', '2017-06-13 03:40:25', '2017-06-13 03:40:25'),
(61, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'location', 2, 'added', '115.186.165.240', '2017-06-13 03:40:57', '2017-06-13 03:40:57'),
(62, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'shift', 1, 'added', '115.186.165.240', '2017-06-13 03:41:30', '2017-06-13 03:41:30'),
(63, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'leave', 1, 'added', '115.186.165.240', '2017-06-13 03:41:59', '2017-06-13 03:41:59'),
(64, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'experience', 1, 'added', '115.186.165.240', '2017-06-13 03:45:10', '2017-06-13 03:45:10'),
(65, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'message', 1, NULL, NULL, 'sent', '115.186.165.240', '2017-06-13 03:47:27', '2017-06-13 03:47:27'),
(66, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'message', 2, NULL, NULL, 'forwarded', '115.186.165.240', '2017-06-13 03:48:41', '2017-06-13 03:48:41'),
(67, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'mail', NULL, 'updated', '115.186.165.240', '2017-06-13 03:49:24', '2017-06-13 03:49:24'),
(68, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'message', 3, NULL, NULL, 'replied', '115.186.165.240', '2017-06-13 03:50:18', '2017-06-13 03:50:18'),
(69, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'mail', NULL, 'updated', '115.186.165.240', '2017-06-13 03:59:22', '2017-06-13 03:59:22'),
(70, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'message', 4, NULL, NULL, 'sent', '115.186.165.240', '2017-06-13 04:00:20', '2017-06-13 04:00:20'),
(71, 3, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'leave', 1, NULL, NULL, 'requested', '115.186.165.240', '2017-06-13 04:02:46', '2017-06-13 04:02:46'),
(72, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'email', NULL, 'sent', '115.186.165.240', '2017-06-13 04:03:59', '2017-06-13 04:03:59'),
(73, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'mail', NULL, 'updated', '115.186.165.240', '2017-06-13 04:04:56', '2017-06-13 04:04:56'),
(74, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'user', 3, 'email', NULL, 'sent', '115.186.165.240', '2017-06-13 04:06:00', '2017-06-13 04:06:00'),
(81, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', NULL, 1, NULL, NULL, 'status_updated', '115.186.165.240', '2017-06-13 06:12:47', '2017-06-13 06:12:47'),
(82, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-13 06:14:51', '2017-06-13 06:14:51'),
(83, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'configuration', NULL, 'notification', NULL, 'updated', '115.186.165.240', '2017-06-13 06:21:10', '2017-06-13 06:21:10'),
(84, 4, NULL, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) CriOS/59.0.3071.84 Mobile/14F89 Safari/602.1', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-13 06:36:42', '2017-06-13 06:36:42'),
(85, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.165.240', '2017-06-13 06:41:01', '2017-06-13 06:41:01'),
(86, 1, 3, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-13 06:41:01', '2017-06-13 06:41:01'),
(87, 1, 3, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'leave', 2, NULL, NULL, 'requested', '115.186.165.240', '2017-06-13 06:42:08', '2017-06-13 06:42:08'),
(88, 4, NULL, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) CriOS/59.0.3071.84 Mobile/14F89 Safari/602.1', NULL, 2, NULL, NULL, 'status_updated', '115.186.165.240', '2017-06-13 06:43:19', '2017-06-13 06:43:19'),
(89, 3, NULL, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-13 06:45:02', '2017-06-13 06:45:02'),
(90, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-13 09:17:20', '2017-06-13 09:17:20'),
(91, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'template', 1, NULL, NULL, 'updated', '115.186.165.240', '2017-06-13 09:18:31', '2017-06-13 09:18:31'),
(92, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'payroll', NULL, NULL, NULL, 'deleted', '115.186.165.240', '2017-06-13 09:30:34', '2017-06-13 09:30:34'),
(93, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'salary_head', 1, NULL, NULL, 'added', '115.186.165.240', '2017-06-13 09:33:48', '2017-06-13 09:33:48'),
(94, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:37:51', '2017-06-13 17:37:51'),
(95, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:43:53', '2017-06-13 17:43:53'),
(96, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 1, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-13 17:45:04', '2017-06-13 17:45:04'),
(97, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 1, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-13 17:45:20', '2017-06-13 17:45:20'),
(98, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:47:18', '2017-06-13 17:47:18'),
(99, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 2, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-13 17:48:26', '2017-06-13 17:48:26'),
(100, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 2, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-13 17:48:28', '2017-06-13 17:48:28'),
(101, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:49:02', '2017-06-13 17:49:02'),
(102, 14, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:49:10', '2017-06-13 17:49:10'),
(103, 5, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:50:59', '2017-06-13 17:50:59'),
(104, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-13 17:51:57', '2017-06-13 17:51:57'),
(105, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:52:06', '2017-06-13 17:52:06'),
(106, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-13 17:53:31', '2017-06-13 17:53:31'),
(107, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'attendance', 3, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-13 17:53:52', '2017-06-13 17:53:52'),
(108, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'attendance', 3, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-13 18:03:04', '2017-06-13 18:03:04'),
(109, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 4, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-13 18:07:18', '2017-06-13 18:07:18'),
(110, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 4, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-13 18:07:48', '2017-06-13 18:07:48'),
(111, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 5, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-13 18:08:03', '2017-06-13 18:08:03'),
(114, 7, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.52', '2017-06-13 19:29:06', '2017-06-13 19:29:06'),
(115, 7, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.7.52', '2017-06-13 19:42:25', '2017-06-13 19:42:25'),
(168, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-14 09:25:35', '2017-06-14 09:25:35'),
(169, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-14 16:00:59', '2017-06-14 16:00:59'),
(170, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-14 22:50:21', '2017-06-14 22:50:21'),
(171, 14, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-14 23:12:21', '2017-06-14 23:12:21'),
(172, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.58', '2017-06-15 02:22:02', '2017-06-15 02:22:02'),
(173, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 10, 'designation', 9, 'updated', '103.255.7.58', '2017-06-15 02:24:25', '2017-06-15 02:24:25'),
(174, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.80', '2017-06-15 10:37:02', '2017-06-15 10:37:02'),
(175, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-15 15:22:27', '2017-06-15 15:22:27'),
(176, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'attendance', 6, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-15 15:22:41', '2017-06-15 15:22:41'),
(177, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-15 15:33:49', '2017-06-15 15:33:49'),
(181, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.90', '2017-06-15 22:16:53', '2017-06-15 22:16:53'),
(182, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-15 22:19:55', '2017-06-15 22:19:55'),
(183, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 7, 'leave', 2, 'added', '103.255.6.90', '2017-06-15 22:19:55', '2017-06-15 22:19:55'),
(184, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.90', '2017-06-15 22:20:33', '2017-06-15 22:20:33'),
(185, 1, 3, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.90', '2017-06-15 22:20:33', '2017-06-15 22:20:33'),
(194, 1, 3, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.7.43', '2017-06-16 00:18:13', '2017-06-16 00:18:13'),
(195, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.43', '2017-06-16 00:18:13', '2017-06-16 00:18:13'),
(196, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.43', '2017-06-16 00:18:20', '2017-06-16 00:18:20'),
(197, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'contract_type', 1, NULL, NULL, 'added', '103.255.7.43', '2017-06-16 00:23:03', '2017-06-16 00:23:03'),
(198, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'contract_type', 2, NULL, NULL, 'added', '103.255.7.43', '2017-06-16 00:24:25', '2017-06-16 00:24:25'),
(199, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 2, 'salary', 2, 'added', '103.255.7.43', '2017-06-16 00:44:33', '2017-06-16 00:44:33'),
(200, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.66', '2017-06-16 19:47:36', '2017-06-16 19:47:36'),
(201, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.165.240', '2017-06-19 09:35:40', '2017-06-19 09:35:40'),
(202, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'template', 1, NULL, NULL, 'updated', '115.186.165.240', '2017-06-19 09:47:47', '2017-06-19 09:47:47'),
(203, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 3, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:48:42', '2017-06-19 09:48:42'),
(204, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 3, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:49:02', '2017-06-19 09:49:02'),
(205, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 7, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:49:52', '2017-06-19 09:49:52'),
(206, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 7, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:49:58', '2017-06-19 09:49:58'),
(207, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 8, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:50:23', '2017-06-19 09:50:23'),
(208, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 8, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:50:29', '2017-06-19 09:50:29'),
(209, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 13, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:50:54', '2017-06-19 09:50:54'),
(210, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 13, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:51:05', '2017-06-19 09:51:05'),
(211, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 19, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:51:28', '2017-06-19 09:51:28'),
(212, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 19, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:51:35', '2017-06-19 09:51:35'),
(213, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 6, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:51:59', '2017-06-19 09:51:59'),
(214, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 6, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:52:04', '2017-06-19 09:52:04'),
(215, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 11, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:52:29', '2017-06-19 09:52:29'),
(216, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 11, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:52:35', '2017-06-19 09:52:35'),
(217, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 18, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:52:58', '2017-06-19 09:52:58'),
(218, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 18, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:53:03', '2017-06-19 09:53:03'),
(219, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 9, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:53:23', '2017-06-19 09:53:23'),
(220, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 9, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:53:29', '2017-06-19 09:53:29'),
(221, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 20, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:53:52', '2017-06-19 09:53:52'),
(222, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 20, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:53:58', '2017-06-19 09:53:58'),
(223, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 12, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:54:22', '2017-06-19 09:54:22'),
(224, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 12, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:54:29', '2017-06-19 09:54:29'),
(225, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 17, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:54:47', '2017-06-19 09:54:47'),
(226, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 17, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:54:52', '2017-06-19 09:54:52'),
(227, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 21, 'email', NULL, 'sent', '115.186.165.240', '2017-06-19 09:55:14', '2017-06-19 09:55:14'),
(228, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 21, NULL, NULL, 'force_password_changed', '115.186.165.240', '2017-06-19 09:55:20', '2017-06-19 09:55:20'),
(229, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 9, 'leave', 6, 'added', '115.186.165.240', '2017-06-19 09:56:33', '2017-06-19 09:56:33'),
(230, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 20, 'leave', 7, 'added', '115.186.165.240', '2017-06-19 09:56:53', '2017-06-19 09:56:53'),
(231, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 18, 'leave', 8, 'added', '115.186.165.240', '2017-06-19 09:58:12', '2017-06-19 09:58:12'),
(232, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 11, 'leave', 9, 'added', '115.186.165.240', '2017-06-19 09:58:34', '2017-06-19 09:58:34'),
(233, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 6, 'leave', 10, 'added', '115.186.165.240', '2017-06-19 09:58:50', '2017-06-19 09:58:50'),
(234, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 19, 'leave', 11, 'added', '115.186.165.240', '2017-06-19 09:59:07', '2017-06-19 09:59:07'),
(235, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 13, 'leave', 12, 'added', '115.186.165.240', '2017-06-19 09:59:30', '2017-06-19 09:59:30'),
(236, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'backup', 1, NULL, NULL, 'generated', '115.186.165.240', '2017-06-19 10:04:36', '2017-06-19 10:04:36'),
(237, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 15:15:18', '2017-06-19 15:15:18'),
(238, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 7, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-19 15:15:31', '2017-06-19 15:15:31'),
(239, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 7, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-19 15:15:42', '2017-06-19 15:15:42'),
(240, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 15:32:30', '2017-06-19 15:32:30'),
(241, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'attendance', 8, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-19 15:32:46', '2017-06-19 15:32:46'),
(242, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 15:37:52', '2017-06-19 15:37:52'),
(243, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 9, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-19 15:48:20', '2017-06-19 15:48:20'),
(244, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 9, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-19 15:48:37', '2017-06-19 15:48:37'),
(245, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 10, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-19 15:48:39', '2017-06-19 15:48:39'),
(246, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-19 15:49:10', '2017-06-19 15:49:10'),
(247, 14, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 17:32:42', '2017-06-19 17:32:42'),
(248, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 17:41:39', '2017-06-19 17:41:39'),
(249, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 18:41:38', '2017-06-19 18:41:38'),
(250, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 18:52:08', '2017-06-19 18:52:08'),
(251, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 18:56:57', '2017-06-19 18:56:57'),
(252, 9, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 18:57:30', '2017-06-19 18:57:30'),
(253, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-19 19:00:22', '2017-06-19 19:00:22'),
(256, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-19 19:21:21', '2017-06-19 19:21:21'),
(257, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-19 19:27:34', '2017-06-19 19:27:34'),
(258, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 11, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-19 19:38:25', '2017-06-19 19:38:25'),
(259, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 11, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-19 19:39:05', '2017-06-19 19:39:05'),
(260, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-06-19 21:18:29', '2017-06-19 21:18:29'),
(261, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 15:22:46', '2017-06-20 15:22:46'),
(262, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 15:27:20', '2017-06-20 15:27:20'),
(263, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'attendance', 12, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-20 15:27:53', '2017-06-20 15:27:53'),
(264, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 16:57:51', '2017-06-20 16:57:51'),
(265, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 13, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-20 16:57:58', '2017-06-20 16:57:58'),
(266, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 17:30:31', '2017-06-20 17:30:31'),
(269, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 20:23:10', '2017-06-20 20:23:10'),
(270, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-20 20:23:33', '2017-06-20 20:23:33'),
(271, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-06-20 21:27:54', '2017-06-20 21:27:54'),
(272, 9, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 21:47:47', '2017-06-20 21:47:47'),
(273, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 14, NULL, NULL, 'clocked_in', '124.109.48.90', '2017-06-20 21:47:51', '2017-06-20 21:47:51'),
(274, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 14, NULL, NULL, 'clocked_out', '124.109.48.90', '2017-06-20 21:48:02', '2017-06-20 21:48:02'),
(275, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 15, NULL, NULL, 'clocked_in', '124.109.48.90', '2017-06-20 21:48:05', '2017-06-20 21:48:05'),
(276, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 21:48:24', '2017-06-20 21:48:24'),
(277, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-20 21:49:47', '2017-06-20 21:49:47'),
(278, 12, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-20 22:15:02', '2017-06-20 22:15:02'),
(279, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-21 01:57:55', '2017-06-21 01:57:55'),
(280, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 13, NULL, NULL, 'clocked_out', '115.186.130.14', '2017-06-21 01:58:04', '2017-06-21 01:58:04'),
(281, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-21 16:45:28', '2017-06-21 16:45:28'),
(282, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-21 16:55:37', '2017-06-21 16:55:37'),
(283, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'attendance', 16, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-06-21 16:55:54', '2017-06-21 16:55:54'),
(284, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-21 16:56:18', '2017-06-21 16:56:18'),
(285, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-06-21 16:56:28', '2017-06-21 16:56:28'),
(289, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-06-23 19:06:32', '2017-06-23 19:06:32'),
(291, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.90', '2017-06-23 19:38:44', '2017-06-23 19:38:44'),
(292, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 2, 'profile', NULL, 'updated', '103.255.6.90', '2017-06-23 19:41:44', '2017-06-23 19:41:44'),
(293, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 2, 'profile', NULL, 'updated', '103.255.6.90', '2017-06-23 19:42:13', '2017-06-23 19:42:13'),
(294, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 3, 'profile', NULL, 'updated', '103.255.6.90', '2017-06-23 19:46:04', '2017-06-23 19:46:04'),
(295, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 3, NULL, NULL, 'force_password_changed', '103.255.6.90', '2017-06-23 19:46:24', '2017-06-23 19:46:24'),
(296, 3, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.90', '2017-06-23 19:47:15', '2017-06-23 19:47:15'),
(297, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 22, 'profile', NULL, 'updated', '103.255.6.90', '2017-06-23 19:52:33', '2017-06-23 19:52:33'),
(298, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 2, 'profile', NULL, 'updated', '103.255.6.90', '2017-06-23 19:55:24', '2017-06-23 19:55:24'),
(299, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 22, 'profile', NULL, 'updated', '103.255.6.90', '2017-06-23 19:56:32', '2017-06-23 19:56:32'),
(300, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 2, 'employment', 1, 'updated', '103.255.6.90', '2017-06-23 19:57:22', '2017-06-23 19:57:22'),
(301, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.90', '2017-06-23 19:58:25', '2017-06-23 19:58:25'),
(302, 1, 22, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.90', '2017-06-23 19:58:25', '2017-06-23 19:58:25'),
(303, 1, 22, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.90', '2017-06-23 19:59:09', '2017-06-23 19:59:09'),
(304, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.90', '2017-06-23 19:59:09', '2017-06-23 19:59:09'),
(305, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'user', 2, NULL, NULL, 'deleted', '103.255.6.90', '2017-06-23 19:59:56', '2017-06-23 19:59:56'),
(306, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.57', '2017-06-23 22:25:10', '2017-06-23 22:25:10'),
(307, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.3', '2017-06-25 01:59:07', '2017-06-25 01:59:07'),
(308, 1, NULL, 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) CriOS/59.0.3071.102 Mobile/14F89 Safari/602.1', 'login', NULL, NULL, NULL, 'logged_in', '43.245.8.148', '2017-06-28 14:44:36', '2017-06-28 14:44:36'),
(309, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-03 16:03:22', '2017-07-03 16:03:22'),
(310, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'attendance', 17, NULL, NULL, 'clocked_in', '115.186.130.14', '2017-07-03 16:03:43', '2017-07-03 16:03:43'),
(311, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-03 16:24:50', '2017-07-03 16:24:50'),
(312, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.68', '2017-07-04 00:00:55', '2017-07-04 00:00:55'),
(313, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-04 17:33:35', '2017-07-04 17:33:35'),
(314, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-05 16:26:15', '2017-07-05 16:26:15'),
(315, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-06 16:43:44', '2017-07-06 16:43:44'),
(316, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-06 21:10:28', '2017-07-06 21:10:28'),
(317, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-08 02:08:57', '2017-07-08 02:08:57'),
(318, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-08 16:12:20', '2017-07-08 16:12:20'),
(319, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-08 17:20:01', '2017-07-08 17:20:01'),
(320, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-10 16:15:14', '2017-07-10 16:15:14'),
(321, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-11 00:35:12', '2017-07-11 00:35:12'),
(322, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-11 20:51:36', '2017-07-11 20:51:36');
INSERT INTO `activities` (`id`, `user_id`, `login_as_user_id`, `user_agent`, `module`, `module_id`, `sub_module`, `sub_module_id`, `activity`, `ip`, `created_at`, `updated_at`) VALUES
(323, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-11 21:32:20', '2017-07-11 21:32:20'),
(324, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'attendance', 18, NULL, NULL, 'clocked_in', '124.109.48.90', '2017-07-11 21:32:32', '2017-07-11 21:32:32'),
(325, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'attendance', 18, NULL, NULL, 'clocked_out', '124.109.48.90', '2017-07-11 21:32:41', '2017-07-11 21:32:41'),
(326, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-11 21:43:25', '2017-07-11 21:43:25'),
(327, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 22, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-11 21:47:41', '2017-07-11 21:47:41'),
(328, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-11 22:21:41', '2017-07-11 22:21:41'),
(329, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-11 23:04:04', '2017-07-11 23:04:04'),
(330, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 11, 'leave', 9, 'deleted', '124.109.48.90', '2017-07-12 00:42:39', '2017-07-12 00:42:39'),
(331, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 11, 'leave', 13, 'added', '124.109.48.90', '2017-07-12 00:42:42', '2017-07-12 00:42:42'),
(332, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-12 00:46:18', '2017-07-12 00:46:18'),
(333, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'leave', 3, NULL, NULL, 'requested', '115.186.130.14', '2017-07-12 00:46:53', '2017-07-12 00:46:53'),
(334, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'leave', 4, NULL, NULL, 'requested', '115.186.130.14', '2017-07-12 00:48:15', '2017-07-12 00:48:15'),
(335, 6, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-12 03:35:00', '2017-07-12 03:35:00'),
(336, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-12 16:25:23', '2017-07-12 16:25:23'),
(337, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-12 16:28:03', '2017-07-12 16:28:03'),
(338, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-12 20:53:49', '2017-07-12 20:53:49'),
(339, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 10, 'employment', 9, 'updated', '115.186.130.14', '2017-07-12 20:59:38', '2017-07-12 20:59:38'),
(340, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 5, 'contract', 1, 'added', '115.186.130.14', '2017-07-12 21:03:59', '2017-07-12 21:03:59'),
(341, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-12 23:31:50', '2017-07-12 23:31:50'),
(342, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-13 18:20:58', '2017-07-13 18:20:58'),
(343, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-13 19:44:28', '2017-07-13 19:44:28'),
(344, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-13 22:30:06', '2017-07-13 22:30:06'),
(345, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.7.19', '2017-07-14 00:19:07', '2017-07-14 00:19:07'),
(346, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36', 'attendance', 19, NULL, NULL, 'clocked_in', '103.255.7.19', '2017-07-14 00:21:43', '2017-07-14 00:21:43'),
(347, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36', 'attendance', 19, NULL, NULL, 'clocked_out', '103.255.7.19', '2017-07-14 00:22:06', '2017-07-14 00:22:06'),
(348, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-14 16:19:16', '2017-07-14 16:19:16'),
(349, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-14 16:47:30', '2017-07-14 16:47:30'),
(350, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-14 17:56:56', '2017-07-14 17:56:56'),
(351, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-14 21:38:19', '2017-07-14 21:38:19'),
(352, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-18 18:21:05', '2017-07-18 18:21:05'),
(353, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-19 20:11:40', '2017-07-19 20:11:40'),
(354, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-20 21:57:40', '2017-07-20 21:57:40'),
(355, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-21 00:42:04', '2017-07-21 00:42:04'),
(356, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-21 16:22:17', '2017-07-21 16:22:17'),
(357, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-21 16:27:48', '2017-07-21 16:27:48'),
(358, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 19:27:27', '2017-07-24 19:27:27'),
(359, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-24 19:32:26', '2017-07-24 19:32:26'),
(360, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 23, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 19:34:19', '2017-07-24 19:34:19'),
(361, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 15, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 19:39:42', '2017-07-24 19:39:42'),
(362, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 20, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 19:45:31', '2017-07-24 19:45:31'),
(363, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 13, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 19:49:19', '2017-07-24 19:49:19'),
(364, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 24, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 19:50:44', '2017-07-24 19:50:44'),
(365, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 8, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 19:56:30', '2017-07-24 19:56:30'),
(366, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 9, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 20:00:49', '2017-07-24 20:00:49'),
(367, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 17, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 20:02:06', '2017-07-24 20:02:06'),
(368, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 18, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 20:04:18', '2017-07-24 20:04:18'),
(369, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 11, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 20:07:58', '2017-07-24 20:07:58'),
(370, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 12, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 20:09:19', '2017-07-24 20:09:19'),
(371, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 19, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 20:09:46', '2017-07-24 20:09:46'),
(372, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-07-24 21:22:02', '2017-07-24 21:22:02'),
(373, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 21:29:45', '2017-07-24 21:29:45'),
(374, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-07-24 21:33:34', '2017-07-24 21:33:34'),
(375, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 21:36:08', '2017-07-24 21:36:08'),
(376, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 21:41:11', '2017-07-24 21:41:11'),
(377, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 21:51:40', '2017-07-24 21:51:40'),
(378, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 21:55:45', '2017-07-24 21:55:45'),
(379, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 17, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-07-24 21:59:04', '2017-07-24 21:59:04'),
(380, 17, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 22:03:47', '2017-07-24 22:03:47'),
(381, 17, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-07-24 22:07:38', '2017-07-24 22:07:38'),
(382, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-24 22:36:51', '2017-07-24 22:36:51'),
(383, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 00:12:32', '2017-07-25 00:12:32'),
(384, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 00:13:11', '2017-07-25 00:13:11'),
(385, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-25 00:14:59', '2017-07-25 00:14:59'),
(386, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 00:24:28', '2017-07-25 00:24:28'),
(387, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 23, 'leave', 14, 'added', '115.186.130.14', '2017-07-25 00:37:27', '2017-07-25 00:37:27'),
(388, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 00:39:09', '2017-07-25 00:39:09'),
(389, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 23, 'leave', 14, 'deleted', '115.186.130.14', '2017-07-25 00:41:21', '2017-07-25 00:41:21'),
(390, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 23, 'leave', 15, 'added', '115.186.130.14', '2017-07-25 00:49:58', '2017-07-25 00:49:58'),
(391, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 16:13:01', '2017-07-25 16:13:01'),
(392, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-07-25 16:23:10', '2017-07-25 16:23:10'),
(393, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 16:38:15', '2017-07-25 16:38:15'),
(394, 9, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 17:03:32', '2017-07-25 17:03:32'),
(395, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 17:05:33', '2017-07-25 17:05:33'),
(396, 13, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-07-25 17:06:24', '2017-07-25 17:06:24'),
(397, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-25 19:51:59', '2017-07-25 19:51:59'),
(398, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 17, 'leave', 16, 'added', '115.186.130.14', '2017-07-25 19:59:22', '2017-07-25 19:59:22'),
(399, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-26 00:41:53', '2017-07-26 00:41:53'),
(400, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-26 18:48:04', '2017-07-26 18:48:04'),
(401, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-26 18:48:11', '2017-07-26 18:48:11'),
(402, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-26 21:07:08', '2017-07-26 21:07:08'),
(403, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-26 21:40:45', '2017-07-26 21:40:45'),
(404, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-27 16:02:04', '2017-07-27 16:02:04'),
(405, 8, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-27 23:16:27', '2017-07-27 23:16:27'),
(406, 7, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-28 17:06:07', '2017-07-28 17:06:07'),
(407, 17, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-07-28 17:52:56', '2017-07-28 17:52:56'),
(408, 17, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-07-28 17:55:57', '2017-07-28 17:55:57'),
(409, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.91', '2017-07-30 17:23:40', '2017-07-30 17:23:40'),
(410, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36', 'user', 14, 'employment', 13, 'updated', '103.255.6.91', '2017-07-30 17:27:11', '2017-07-30 17:27:11'),
(411, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36', 'user', 6, 'employment', 5, 'updated', '103.255.6.91', '2017-07-30 17:32:27', '2017-07-30 17:32:27'),
(412, 1, NULL, 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G930F Build/MMB29K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36', 'user', 5, 'employment', 4, 'updated', '103.255.6.91', '2017-07-30 17:35:06', '2017-07-30 17:35:06'),
(413, 22, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-07-31 17:37:15', '2017-07-31 17:37:15'),
(414, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '119.157.27.209', '2017-08-01 17:19:03', '2017-08-01 17:19:03'),
(415, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'leave', 5, NULL, NULL, 'requested', '119.157.27.209', '2017-08-01 17:25:22', '2017-08-01 17:25:22'),
(416, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-08-01 17:46:04', '2017-08-01 17:46:04'),
(417, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-08-01 22:35:48', '2017-08-01 22:35:48'),
(418, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-03 16:27:23', '2017-08-03 16:27:23'),
(419, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-04 16:41:35', '2017-08-04 16:41:35'),
(420, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-04 17:35:42', '2017-08-04 17:35:42'),
(421, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'daily_report', 1, NULL, NULL, 'added', '115.186.130.14', '2017-08-04 17:39:56', '2017-08-04 17:39:56'),
(422, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 25, 'profile', NULL, 'updated', '115.186.130.14', '2017-08-04 17:42:07', '2017-08-04 17:42:07'),
(423, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 25, 'leave', 17, 'added', '115.186.130.14', '2017-08-04 17:43:56', '2017-08-04 17:43:56'),
(424, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 15, 'profile', NULL, 'updated', '115.186.130.14', '2017-08-04 17:48:03', '2017-08-04 17:48:03'),
(425, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 24, 'leave', 18, 'added', '115.186.130.14', '2017-08-04 18:18:45', '2017-08-04 18:18:45'),
(426, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 12, 'leave', 19, 'added', '115.186.130.14', '2017-08-04 18:30:24', '2017-08-04 18:30:24'),
(427, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 17, 'leave', 16, 'updated', '115.186.130.14', '2017-08-04 18:30:57', '2017-08-04 18:30:57'),
(428, 11, NULL, 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-04 22:44:52', '2017-08-04 22:44:52'),
(429, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-07 15:55:27', '2017-08-07 15:55:27'),
(430, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-08 16:12:11', '2017-08-08 16:12:11'),
(431, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-08 21:32:29', '2017-08-08 21:32:29'),
(432, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-08 22:39:12', '2017-08-08 22:39:12'),
(433, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'leave', 6, NULL, NULL, 'requested', '115.186.130.14', '2017-08-08 22:42:19', '2017-08-08 22:42:19'),
(434, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 4, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-08-08 23:17:26', '2017-08-08 23:17:26'),
(435, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-08 23:17:41', '2017-08-08 23:17:41'),
(436, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-08 23:18:02', '2017-08-08 23:18:02'),
(437, 4, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.87', '2017-08-08 23:21:37', '2017-08-08 23:21:37'),
(438, 4, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.87', '2017-08-08 23:38:16', '2017-08-08 23:38:16'),
(439, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-08-09 22:58:30', '2017-08-09 22:58:30'),
(440, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-08-10 21:54:15', '2017-08-10 21:54:15'),
(441, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'user', 26, 'profile', NULL, 'updated', '124.109.48.90', '2017-08-10 22:34:32', '2017-08-10 22:34:32'),
(442, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-11 00:44:51', '2017-08-11 00:44:51'),
(443, 4, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.255', '2017-08-11 02:29:28', '2017-08-11 02:29:28'),
(444, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '58.65.149.206', '2017-08-11 08:27:56', '2017-08-11 08:27:56'),
(445, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-11 17:23:42', '2017-08-11 17:23:42'),
(446, 4, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.76', '2017-08-11 21:21:00', '2017-08-11 21:21:00'),
(447, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-15 18:00:39', '2017-08-15 18:00:39'),
(448, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0', 'login', NULL, NULL, NULL, 'logged_in', '115.186.169.243', '2017-08-16 02:34:40', '2017-08-16 02:34:40'),
(449, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-16 19:11:00', '2017-08-16 19:11:00'),
(450, 7, NULL, 'Mozilla/5.0 (Linux; Android 4.4.2; LG-LS980 Build/KOT49I.LS980ZVD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-08-16 19:16:14', '2017-08-16 19:16:14'),
(451, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-08-16 23:01:12', '2017-08-16 23:01:12'),
(452, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'user', 7, 'leave', 4, 'deleted', '124.109.48.90', '2017-08-16 23:03:14', '2017-08-16 23:03:14'),
(453, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'user', 7, 'leave', 20, 'added', '124.109.48.90', '2017-08-16 23:03:16', '2017-08-16 23:03:16'),
(454, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-17 16:16:06', '2017-08-17 16:16:06'),
(455, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'leave', 7, NULL, NULL, 'requested', '115.186.130.14', '2017-08-17 16:17:53', '2017-08-17 16:17:53'),
(456, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'leave', 8, NULL, NULL, 'requested', '115.186.130.14', '2017-08-17 16:18:31', '2017-08-17 16:18:31'),
(457, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-17 18:33:59', '2017-08-17 18:33:59'),
(458, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-17 18:36:10', '2017-08-17 18:36:10'),
(459, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-17 18:36:49', '2017-08-17 18:36:49'),
(460, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-17 20:23:50', '2017-08-17 20:23:50'),
(461, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-17 22:12:12', '2017-08-17 22:12:12'),
(462, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36', NULL, 8, NULL, NULL, 'status_updated', '115.186.130.14', '2017-08-17 22:14:12', '2017-08-17 22:14:12'),
(463, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-22 17:37:21', '2017-08-22 17:37:21'),
(464, 18, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-22 17:42:39', '2017-08-22 17:42:39'),
(465, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-22 17:50:14', '2017-08-22 17:50:14'),
(466, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-22 20:57:03', '2017-08-22 20:57:03'),
(467, 11, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-22 21:01:54', '2017-08-22 21:01:54'),
(468, 11, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-22 21:02:53', '2017-08-22 21:02:53'),
(469, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '119.159.147.177', '2017-08-23 16:39:22', '2017-08-23 16:39:22'),
(470, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-23 16:39:40', '2017-08-23 16:39:40'),
(471, 23, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-23 16:58:46', '2017-08-23 16:58:46'),
(472, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-23 16:58:53', '2017-08-23 16:58:53'),
(473, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-23 19:59:25', '2017-08-23 19:59:25'),
(474, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-23 20:01:26', '2017-08-23 20:01:26'),
(475, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-24 02:38:30', '2017-08-24 02:38:30'),
(476, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-24 16:40:34', '2017-08-24 16:40:34'),
(477, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-24 22:32:09', '2017-08-24 22:32:09'),
(478, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-24 22:43:59', '2017-08-24 22:43:59'),
(479, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.99', '2017-08-24 23:32:52', '2017-08-24 23:32:52'),
(480, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 20, NULL, NULL, 'clocked_in', '103.255.6.99', '2017-08-24 23:42:56', '2017-08-24 23:42:56'),
(481, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 20, NULL, NULL, 'clocked_out', '103.255.6.99', '2017-08-24 23:43:23', '2017-08-24 23:43:23'),
(482, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 21, NULL, NULL, 'clocked_in', '103.255.6.99', '2017-08-24 23:43:53', '2017-08-24 23:43:53'),
(483, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 21, NULL, NULL, 'clocked_out', '103.255.6.99', '2017-08-24 23:44:04', '2017-08-24 23:44:04'),
(484, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 22, NULL, NULL, 'clocked_in', '103.255.6.99', '2017-08-24 23:44:32', '2017-08-24 23:44:32'),
(485, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 22, NULL, NULL, 'clocked_out', '103.255.6.99', '2017-08-24 23:44:43', '2017-08-24 23:44:43'),
(486, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.99', '2017-08-24 23:54:59', '2017-08-24 23:54:59'),
(487, 1, 3, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.99', '2017-08-24 23:54:59', '2017-08-24 23:54:59'),
(488, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.99', '2017-08-24 23:55:58', '2017-08-24 23:55:58'),
(489, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '103.255.6.99', '2017-08-24 23:56:11', '2017-08-24 23:56:11'),
(490, 1, 3, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '103.255.6.99', '2017-08-24 23:56:11', '2017-08-24 23:56:11'),
(491, 1, 3, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'attendance', 23, NULL, NULL, 'clocked_in', '103.255.6.99', '2017-08-24 23:56:23', '2017-08-24 23:56:23'),
(492, 19, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-25 00:28:30', '2017-08-25 00:28:30'),
(493, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-28 16:25:02', '2017-08-28 16:25:02'),
(494, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-28 17:22:39', '2017-08-28 17:22:39'),
(495, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-08-28 17:24:48', '2017-08-28 17:24:48'),
(496, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-28 21:03:11', '2017-08-28 21:03:11'),
(497, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-29 22:13:53', '2017-08-29 22:13:53'),
(498, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-30 18:27:37', '2017-08-30 18:27:37'),
(499, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-08-31 16:36:27', '2017-08-31 16:36:27'),
(500, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-05 16:47:38', '2017-09-05 16:47:38'),
(501, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-05 23:01:10', '2017-09-05 23:01:10'),
(502, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-11 19:26:52', '2017-09-11 19:26:52'),
(503, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-12 16:20:39', '2017-09-12 16:20:39'),
(504, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-12 23:44:48', '2017-09-12 23:44:48'),
(505, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-12 23:53:58', '2017-09-12 23:53:58'),
(506, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-13 18:00:29', '2017-09-13 18:00:29'),
(507, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-14 16:24:44', '2017-09-14 16:24:44'),
(508, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-15 16:25:45', '2017-09-15 16:25:45'),
(509, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0', 'login', NULL, NULL, NULL, 'logged_in', '119.159.147.177', '2017-09-15 21:02:37', '2017-09-15 21:02:37'),
(510, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-15 22:54:55', '2017-09-15 22:54:55'),
(511, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0', 'login', NULL, NULL, NULL, 'logged_in', '119.159.147.177', '2017-09-16 02:02:59', '2017-09-16 02:02:59'),
(512, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '119.159.147.177', '2017-09-19 02:51:26', '2017-09-19 02:51:26'),
(513, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-19 17:03:00', '2017-09-19 17:03:00'),
(514, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-20 17:57:09', '2017-09-20 17:57:09'),
(515, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-20 23:30:33', '2017-09-20 23:30:33'),
(516, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-21 17:33:24', '2017-09-21 17:33:24'),
(517, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '119.159.147.177', '2017-09-22 01:56:55', '2017-09-22 01:56:55'),
(518, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-25 16:21:23', '2017-09-25 16:21:23'),
(519, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-26 18:00:38', '2017-09-26 18:00:38'),
(520, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-26 18:50:09', '2017-09-26 18:50:09'),
(521, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'user', 25, 'employment', 24, 'updated', '115.186.130.14', '2017-09-26 18:59:03', '2017-09-26 18:59:03'),
(522, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'user', 25, 'employment', 24, 'updated', '115.186.130.14', '2017-09-26 18:59:21', '2017-09-26 18:59:21'),
(523, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'user', 22, 'designation', 21, 'updated', '115.186.130.14', '2017-09-26 18:59:59', '2017-09-26 18:59:59'),
(524, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'user', 26, NULL, NULL, 'force_password_changed', '115.186.130.14', '2017-09-26 19:00:51', '2017-09-26 19:00:51'),
(525, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'user', 21, 'employment', 20, 'updated', '115.186.130.14', '2017-09-26 19:02:02', '2017-09-26 19:02:02'),
(526, 26, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-26 19:38:59', '2017-09-26 19:38:59'),
(527, 26, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-09-26 21:35:35', '2017-09-26 21:35:35'),
(528, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-26 23:47:11', '2017-09-26 23:47:11'),
(529, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '115.186.130.14', '2017-09-27 00:18:17', '2017-09-27 00:18:17'),
(530, 1, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-27 00:19:41', '2017-09-27 00:19:41'),
(531, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-27 21:18:00', '2017-09-27 21:18:00');
INSERT INTO `activities` (`id`, `user_id`, `login_as_user_id`, `user_agent`, `module`, `module_id`, `sub_module`, `sub_module_id`, `activity`, `ip`, `created_at`, `updated_at`) VALUES
(532, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-09-28 21:14:18', '2017-09-28 21:14:18'),
(533, 1, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-09-29 19:37:29', '2017-09-29 19:37:29'),
(534, 1, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-10-02 18:13:28', '2017-10-02 18:13:28'),
(535, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-04 21:36:15', '2017-10-04 21:36:15'),
(536, 1, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-05 17:49:59', '2017-10-05 17:49:59'),
(537, 1, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '124.109.48.90', '2017-10-10 18:21:57', '2017-10-10 18:21:57'),
(538, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-11 16:22:01', '2017-10-11 16:22:01'),
(539, 20, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-12 00:27:13', '2017-10-12 00:27:13'),
(540, 15, NULL, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-12 00:42:49', '2017-10-12 00:42:49'),
(541, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '119.154.176.41', '2017-10-12 04:22:35', '2017-10-12 04:22:35'),
(542, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-13 16:34:24', '2017-10-13 16:34:24'),
(543, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-16 16:23:02', '2017-10-16 16:23:02'),
(544, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-18 21:02:35', '2017-10-18 21:02:35'),
(545, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-24 16:03:20', '2017-10-24 16:03:20'),
(546, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-25 16:09:04', '2017-10-25 16:09:04'),
(547, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-10-27 16:40:06', '2017-10-27 16:40:06'),
(548, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-02 18:43:27', '2017-11-02 18:43:27'),
(549, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-02 21:16:29', '2017-11-02 21:16:29'),
(550, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'leave', 9, NULL, NULL, 'requested', '115.186.130.14', '2017-11-02 21:32:45', '2017-11-02 21:32:45'),
(551, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'leave', 10, NULL, NULL, 'requested', '115.186.130.14', '2017-11-02 21:33:04', '2017-11-02 21:33:04'),
(552, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'leave', 11, NULL, NULL, 'requested', '115.186.130.14', '2017-11-02 21:33:27', '2017-11-02 21:33:27'),
(553, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'leave', 12, NULL, NULL, 'requested', '115.186.130.14', '2017-11-02 21:33:38', '2017-11-02 21:33:38'),
(554, 1, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-02 21:35:50', '2017-11-02 21:35:50'),
(555, 7, NULL, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-03 16:18:21', '2017-11-03 16:18:21'),
(556, 4, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.75 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '101.50.111.251', '2017-11-05 06:08:01', '2017-11-05 06:08:01'),
(557, 4, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.75 Safari/537.36', 'logout', NULL, NULL, NULL, 'logged_out', '101.50.111.251', '2017-11-05 06:10:00', '2017-11-05 06:10:00'),
(558, 1, NULL, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.75 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '101.50.111.251', '2017-11-05 06:10:35', '2017-11-05 06:10:35'),
(559, 9, NULL, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-15 03:10:29', '2017-11-15 03:10:29'),
(560, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-16 21:21:43', '2017-11-16 21:21:43'),
(561, 1, NULL, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36', 'login', NULL, NULL, NULL, 'logged_in', '115.186.130.14', '2017-11-17 01:34:38', '2017-11-17 01:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `audience` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `announcement_designation`
--

CREATE TABLE IF NOT EXISTS `announcement_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `announcement_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcement_id` (`announcement_id`),
  KEY `designation_id` (`designation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `announcement_user`
--

CREATE TABLE IF NOT EXISTS `announcement_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `announcement_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcement_id` (`announcement_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `awards`
--

CREATE TABLE IF NOT EXISTS `awards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `award_category_id` int(11) DEFAULT NULL,
  `date_of_award` date DEFAULT NULL,
  `duration` enum('monthly','yearly','period') COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `month` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `award_category_id` (`award_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `award_categories`
--

CREATE TABLE IF NOT EXISTS `award_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `award_user`
--

CREATE TABLE IF NOT EXISTS `award_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `award_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `award_id` (`award_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `backups`
--

CREATE TABLE IF NOT EXISTS `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `backups`
--

INSERT INTO `backups` (`id`, `file`, `created_at`, `updated_at`) VALUES
(1, 'backup_2017_06_19_03_04_36.sql.gz', '2017-06-19 10:04:36', '2017-06-19 10:04:36');

-- --------------------------------------------------------

--
-- Table structure for table `bulk_uploads`
--

CREATE TABLE IF NOT EXISTS `bulk_uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `module` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `uploaded` int(11) NOT NULL DEFAULT '0',
  `rejected` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `user_id`, `message`, `created_at`, `updated_at`) VALUES
(1, 3, 'Hi', '2017-06-13 06:45:43', '2017-06-13 06:45:43');

-- --------------------------------------------------------

--
-- Table structure for table `clocks`
--

CREATE TABLE IF NOT EXISTS `clocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `clock_in` timestamp NULL DEFAULT NULL,
  `clock_out` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `clocks`
--

INSERT INTO `clocks` (`id`, `user_id`, `date`, `clock_in`, `clock_out`, `created_at`, `updated_at`) VALUES
(1, 12, '2017-06-13', '2017-06-13 17:45:04', '2017-06-13 17:45:20', '2017-06-13 17:45:04', '2017-06-13 17:45:20'),
(2, 11, '2017-06-13', '2017-06-13 17:48:26', '2017-06-13 17:48:28', '2017-06-13 17:48:26', '2017-06-13 17:48:28'),
(3, 15, '2017-06-13', '2017-06-13 17:53:52', '2017-06-13 18:03:04', '2017-06-13 17:53:52', '2017-06-13 18:03:04'),
(4, 20, '2017-06-13', '2017-06-13 18:07:18', '2017-06-13 18:07:48', '2017-06-13 18:07:18', '2017-06-13 18:07:48'),
(5, 20, '2017-06-13', '2017-06-13 18:08:03', NULL, '2017-06-13 18:08:03', '2017-06-13 18:08:03'),
(6, 7, '2017-06-15', '2017-06-15 15:22:41', NULL, '2017-06-15 15:22:41', '2017-06-15 15:22:41'),
(7, 8, '2017-06-19', '2017-06-19 15:15:31', '2017-06-19 15:15:42', '2017-06-19 15:15:31', '2017-06-19 15:15:42'),
(8, 7, '2017-06-19', '2017-06-19 15:32:46', NULL, '2017-06-19 15:32:46', '2017-06-19 15:32:46'),
(9, 19, '2017-06-19', '2017-06-19 15:48:20', '2017-06-19 15:48:37', '2017-06-19 15:48:20', '2017-06-19 15:48:37'),
(10, 19, '2017-06-19', '2017-06-19 15:48:39', NULL, '2017-06-19 15:48:39', '2017-06-19 15:48:39'),
(11, 18, '2017-06-19', '2017-06-19 19:38:25', '2017-06-19 19:39:05', '2017-06-19 19:38:25', '2017-06-19 19:39:05'),
(12, 7, '2017-06-20', '2017-06-20 15:27:53', NULL, '2017-06-20 15:27:53', '2017-06-20 15:27:53'),
(13, 13, '2017-06-20', '2017-06-20 16:57:58', '2017-06-21 01:58:04', '2017-06-20 16:57:58', '2017-06-21 01:58:04'),
(14, 6, '2017-06-20', '2017-06-20 21:47:51', '2017-06-20 21:48:02', '2017-06-20 21:47:51', '2017-06-20 21:48:02'),
(15, 6, '2017-06-20', '2017-06-20 21:48:05', NULL, '2017-06-20 21:48:05', '2017-06-20 21:48:05'),
(16, 13, '2017-06-21', '2017-06-21 16:55:54', NULL, '2017-06-21 16:55:54', '2017-06-21 16:55:54'),
(17, 7, '2017-07-03', '2017-07-03 16:03:43', NULL, '2017-07-03 16:03:43', '2017-07-03 16:03:43'),
(18, 6, '2017-07-11', '2017-07-11 21:32:32', '2017-07-11 21:32:41', '2017-07-11 21:32:32', '2017-07-11 21:32:41'),
(19, 1, '2017-07-13', '2017-07-14 00:21:43', '2017-07-14 00:22:06', '2017-07-14 00:21:43', '2017-07-14 00:22:06'),
(20, 1, '2017-08-24', '2017-08-24 23:42:56', '2017-08-24 23:43:23', '2017-08-24 23:42:56', '2017-08-24 23:43:23'),
(21, 1, '2017-08-24', '2017-08-24 23:43:53', '2017-08-24 23:44:04', '2017-08-24 23:43:53', '2017-08-24 23:44:04'),
(22, 1, '2017-08-24', '2017-08-24 23:44:32', '2017-08-24 23:44:43', '2017-08-24 23:44:32', '2017-08-24 23:44:43'),
(23, 3, '2017-08-24', '2017-08-24 23:56:23', NULL, '2017-08-24 23:56:23', '2017-08-24 23:56:23');

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=98 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `name`, `value`) VALUES
(1, 'company_name', 'Mobinspire PVT Ltd'),
(2, 'contact_person', 'Ali Tariq'),
(3, 'company_email', 'hr@mobinspire.com'),
(4, 'company_phone', '03165413670'),
(5, 'company_website', 'https://www.mobinspire.com'),
(6, 'company_address_line_1', 'Office NO 1-B, First Floor Umer Plaza, 76-West, Blue Area Jinnah Avenue, Near to Fresco Sweets'),
(7, 'company_address_line_2', ''),
(8, 'company_city', 'Islamabad'),
(9, 'company_state', 'federal'),
(10, 'company_zipcode', '44000'),
(11, 'company_country_id', '178'),
(12, 'company_logo', '593e3ded06eb8.png'),
(13, 'application_name', 'Mobinspire HRM'),
(14, 'timezone_id', '262'),
(15, 'default_localization', 'en'),
(16, 'date_format', 'd-M-Y'),
(17, 'time_format', '1'),
(18, 'credit', 'Offical Mobinspire HRM'),
(19, 'notification_position', 'toast-bottom-right'),
(20, 'setup_guide', '0'),
(21, 'error_display', '1'),
(22, 'multilingual', '1'),
(23, 'enable_activity_log', '1'),
(24, 'enable_email_log', '1'),
(25, 'enable_email_template', '1'),
(26, 'enable_to_do', '1'),
(27, 'enable_message', '1'),
(28, 'enable_backup', '1'),
(29, 'enable_custom_field', '1'),
(30, 'enable_group_chat', '1'),
(31, 'chat_refresh_duration', '60'),
(32, 'maintenance_mode', '0'),
(33, 'under_maintenance_message', 'The system is under maitnenance.'),
(34, 'enable_ip_filter', '0'),
(35, 'enable_chat_refresh', '0'),
(36, 'driver', 'mailgun'),
(37, 'from_address', 'hr@mobinspire.com'),
(38, 'from_name', 'HRM Mobinspire'),
(39, 'host', ''),
(40, 'port', ''),
(41, 'username', ''),
(42, 'password', 'ggafe4rwer695'),
(43, 'encryption', 'tls'),
(44, 'mandrill_secret', ''),
(45, 'mailgun_domain', 'email.mobinspire.com'),
(46, 'mailgun_secret', 'key-aadf7e2c70a936490c977e8bd6726323'),
(47, 'mailgun_host', 'smtp.mailgun.org'),
(48, 'mailgun_port', '587'),
(49, 'mailgun_username', 'postmaster@email.mobinspire.com'),
(50, 'mailgun_password', '91f73cfe3a07907950cace67a3ac1617'),
(51, 'session_lifetime', ''),
(52, 'reset_token_lifetime', ''),
(53, 'lock_screen_timeout', '1'),
(54, 'throttle_attempt', '5'),
(55, 'throttle_lockout_period', '2'),
(56, 'enable_login_as_user', '1'),
(57, 'login_type', 'email'),
(58, 'enable_password_strength_meter', '1'),
(59, 'recaptcha_key', ''),
(60, 'recaptcha_secret', ''),
(61, 'enable_two_factor_auth', '0'),
(62, 'two_factor_auth_type', '0'),
(63, 'enable_lock_screen', '0'),
(64, 'enable_throttle', '0'),
(65, 'enable_user_registration', '0'),
(66, 'enable_email_verification', '0'),
(67, 'enable_account_approval', '0'),
(68, 'enable_tnc', '0'),
(69, 'enable_remember_me', '0'),
(70, 'enable_reset_password', '0'),
(71, 'session_expire_browser_close', '0'),
(72, 'enable_recaptcha', '0'),
(73, 'enable_recaptcha_login', '0'),
(74, 'enable_recaptcha_registration', '0'),
(75, 'enable_recaptcha_reset_password', '0'),
(76, 'designation_level', '1'),
(77, 'list_user_criteria', 'active,inactive,pending_approval,pending_activation,banned'),
(78, 'location_level', '0'),
(79, 'user_manage_own_contact', '0'),
(80, 'user_manage_own_bank_account', '0'),
(81, 'user_manage_own_document', '0'),
(82, 'user_manage_own_qualification', '0'),
(83, 'user_manage_own_experience', '0'),
(84, 'leave_approval_level', 'multiple'),
(85, 'leave_no_of_level', '2'),
(86, 'leave_approval_level_designation', ''),
(87, 'payroll_include_day_summary', '1'),
(88, 'payroll_include_hour_summary', '1'),
(89, 'payroll_include_leave_summary', '1'),
(90, 'enable_push_notification', '1'),
(91, 'pusher_app_id', '352003'),
(92, 'pusher_key', '04110861608856f5bdb4'),
(93, 'pusher_secret', 'b83f71e7661ea740a07f'),
(94, 'pusher_cluster', 'mt1'),
(95, 'pusher_encrypted', 'true'),
(96, 'push_notification_modules', 'award,announcement,message,ticket,task,daily-report,payroll,leave,expense'),
(97, 'default_notification_tone', 'capisci.mp3');

-- --------------------------------------------------------

--
-- Table structure for table `contract_types`
--

CREATE TABLE IF NOT EXISTS `contract_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contract_types`
--

INSERT INTO `contract_types` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Permanent Employment (1 year)', 'A person who is hired to work regularly for an unspecified period of time on\r\nfull time basis and who has satisfactorily completed the period of his / her\r\nprobation in the company will be treated as a regular employee. \r\nFOR COMPLETE PLEASE CHECK HANDBOOK ref#Employment Types:\r\na. Regular full-time emp', '2017-06-16 00:23:03', '2017-06-16 00:23:03'),
(2, 'Probationary', 'Unless otherwise specified, an employee who has been hired against a regular\r\nposition will undergo a probation period of three months (90 days). If the\r\nperformance of an employee who is on probation\r\nFOR COMPLETE PLEASE CHECK HANDBOOK ref#Employment Types: b. Probationary', '2017-06-16 00:24:25', '2017-06-16 00:24:25');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` enum('prefix','suffix') COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `name`, `symbol`, `position`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'PKR', 'Rs', 'suffix', 1, '2017-06-12 19:14:27', '2017-06-12 19:14:27');

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE IF NOT EXISTS `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` text COLLATE utf8_unicode_ci,
  `is_required` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_values`
--

CREATE TABLE IF NOT EXISTS `custom_field_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unique_id` int(11) DEFAULT NULL,
  `custom_field_id` int(11) DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_field_id` (`custom_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `daily_reports`
--

CREATE TABLE IF NOT EXISTS `daily_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `is_locked` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `daily_reports`
--

INSERT INTO `daily_reports` (`id`, `user_id`, `date`, `description`, `is_locked`, `created_at`, `updated_at`) VALUES
(1, 1, '2017-08-04', '<p>Zakir, Raheel, Sohail and Ahmed are late today</p>', 0, '2017-08-04 17:39:56', '2017-08-04 17:39:56');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `is_hidden` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `description`, `is_hidden`, `created_at`, `updated_at`) VALUES
(1, 'System Administration', NULL, 1, '2017-06-12 07:03:36', NULL),
(2, 'Ios', '', 0, '2016-09-22 12:36:00', '2016-09-22 12:36:00'),
(3, 'Android', '', 0, '2016-09-22 12:36:14', '2016-09-22 12:36:14'),
(4, 'Web', '', 0, '2016-09-22 12:36:28', '2016-09-22 12:36:28'),
(5, 'QA', '', 0, '2016-09-22 12:36:35', '2016-09-22 12:36:35'),
(6, 'Management', '', 0, '2016-09-22 12:43:59', '2016-09-22 12:44:28'),
(7, 'UI/UX', '', 0, '2016-09-22 12:44:40', '2016-09-22 12:44:50'),
(8, 'Sales', '', 0, '2016-09-22 12:45:02', '2016-09-22 12:45:02');

-- --------------------------------------------------------

--
-- Table structure for table `designations`
--

CREATE TABLE IF NOT EXISTS `designations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `top_designation_id` int(11) DEFAULT NULL,
  `is_hidden` int(11) NOT NULL DEFAULT '0',
  `is_default` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `department_id` (`department_id`),
  KEY `top_designation_id` (`top_designation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `designations`
--

INSERT INTO `designations` (`id`, `department_id`, `name`, `description`, `top_designation_id`, `is_hidden`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 1, 'System Administrator', NULL, NULL, 1, 0, '2017-06-12 07:03:36', NULL),
(2, 2, 'Sr Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:39:41', '2017-06-12 20:09:42'),
(3, 3, 'Sr Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:40:11', '2017-06-12 20:10:02'),
(4, 4, 'Sr Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:40:25', '2017-06-12 20:10:21'),
(5, 2, 'Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:40:56', '2017-06-12 20:07:30'),
(6, 3, 'Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:41:04', '2017-06-12 20:07:44'),
(7, 4, 'Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:41:26', '2017-06-12 20:09:32'),
(8, 2, 'Jr Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:41:53', '2017-06-12 20:08:36'),
(9, 3, 'Jr Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:42:05', '2017-06-12 20:08:48'),
(10, 4, 'Jr Software Engineer', NULL, 15, 0, 0, '2016-09-22 12:42:14', '2017-06-12 20:09:01'),
(11, 5, 'Quality Engineer', NULL, 15, 0, 0, '2016-09-22 12:42:58', '2017-06-12 20:07:11'),
(12, 5, 'Jr Quality Engineer', NULL, 15, 0, 0, '2016-09-22 12:43:11', '2017-06-12 20:08:09'),
(13, 7, 'UI Desginer', NULL, 18, 0, 0, '2016-09-22 12:45:50', '2017-06-12 20:12:05'),
(14, 6, 'HR Manager', NULL, 18, 0, 0, '2016-09-22 12:46:02', '2017-06-12 20:11:42'),
(15, 6, 'PM', NULL, 18, 0, 0, '2016-09-22 12:46:11', '2017-06-12 20:11:22'),
(16, 8, 'Sales Analyst', NULL, 18, 0, 0, '2016-09-22 12:46:32', '2017-06-12 20:11:32'),
(17, 6, 'CEO', NULL, 1, 0, 0, '2017-06-12 20:10:53', '2017-06-12 20:10:53'),
(18, 6, 'COO', NULL, 17, 0, 0, '2017-06-12 20:11:10', '2017-06-12 20:11:10');

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

CREATE TABLE IF NOT EXISTS `document_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Contract', NULL, '2016-09-22 13:00:33', '2016-09-22 13:00:33'),
(2, 'Last Certificates', NULL, '2016-09-22 13:01:12', '2016-09-22 13:01:12'),
(3, 'Post Graduation', NULL, '2016-09-22 13:01:30', '2016-09-22 13:01:30'),
(4, 'Graduation', NULL, '2016-09-22 13:01:32', '2016-09-22 13:01:32'),
(5, 'NDA', NULL, '2016-09-22 13:01:38', '2016-09-22 13:01:38'),
(6, 'Last Salary Slip', NULL, '2016-09-22 13:02:00', '2016-09-22 13:02:00'),
(7, 'Experience Letter', NULL, '2016-09-22 13:02:14', '2016-09-22 13:02:14'),
(8, 'Company Policy - Employee Handbook', NULL, '2016-09-28 01:28:15', '2016-09-28 01:28:15'),
(9, 'Bykea NDA', NULL, '2017-01-11 02:30:08', '2017-01-11 02:30:08'),
(10, 'CNIC Copy', NULL, '2017-01-11 02:30:18', '2017-01-11 02:30:18'),
(11, 'Initial Interview Form', NULL, '2017-01-11 02:51:18', '2017-01-11 02:51:18');

-- --------------------------------------------------------

--
-- Table structure for table `education_levels`
--

CREATE TABLE IF NOT EXISTS `education_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_address` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8_unicode_ci,
  `body` text COLLATE utf8_unicode_ci,
  `attachments` text COLLATE utf8_unicode_ci,
  `module` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `emails`
--

INSERT INTO `emails` (`id`, `to_address`, `from_address`, `subject`, `body`, `attachments`, `module`, `module_id`, `created_at`, `updated_at`) VALUES
(1, 'abdurrehman@mobinspire.com', 'admin@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" align="right" height="90">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								<p style="text-align:left;font-size:16px;"><b>Template Header</b></p>\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Abdur Rehman ,<br></p><p>Welcome To Mobinspire Employee Portal , </p><p>Here on this Portal you will have Bunch of Features </p><p>1- View your Profile</p><p>2- View Your Official Document </p><p>3- View your Active Contract </p><p>4- View your Personal Bank Account &amp; Company Bank Account</p><p>5- You can apply for leave &amp; check you pending quota <br></p>\r\n											</td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-13 04:03:59', '2017-06-13 04:03:59'),
(2, 'abdurrehman@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" align="right" height="90">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								<p style="text-align:left;font-size:16px;"><b>Template Header</b></p>\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Abdur Rehman ,<br></p><p>Welcome To Mobinspire Employee Portal , </p><p>Here on this Portal you will have Bunch of Features </p><p>1- View your Profile</p><p>2- View Your Official Document </p><p>3- View your Active Contract </p><p>4- View your Personal Bank Account &amp; Company Bank Account</p><p>5- You can apply for leave &amp; check you pending quota <br></p>\r\n											</td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-13 04:06:00', '2017-06-13 04:06:00'),
(3, 'abdullah@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td valign="top">			\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td width="600" align="right" height="90">\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\n								<p style="text-align:left;font-size:16px;"><b>Template Header</b></p>\n							</td>\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\n								<table align="center"><tr><td width="560" height="10"> </td>\n										</tr><tr><td width="560">\n												<p>Hello Ahmed Abdullah ,<br /></p><p>Welcome To Mobinspire Employee Portal , </p><p>Here on this Portal you will have Bunch of Features </p><p>1- View your Profile</p><p>2- View Your Official Document </p><p>3- View your Active Contract </p><p>4- View your Personal Bank Account &amp; Company Bank Account</p><p>5- You can apply for leave &amp; check you pending quota <br /></p>\n											</td>\n										</tr><tr><td width="560" height="10"></td>\n										</tr></table></td>\n						</tr><tr><td width="600" height="10"> </td></tr><tr><td align="right">\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br />\n								hr@mobinspire.com <br />\n								03165413670 <br />\n								https://www.mobinspire.com <br /></span>\n							</td>\n						</tr></table></td>\n		</tr></table>', NULL, NULL, NULL, '2017-06-13 04:08:32', '2017-06-13 04:08:32'),
(4, 'abdurrehman@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Abdur Rehman ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : abdurrehman@mobinspire.com</p><p>Login Password : abdurrehman123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:48:42', '2017-06-19 09:48:42'),
(5, 'bilal@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello M Bilal ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : bilal@mobinspire.com</p><p>Login Password : bilal.123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:49:52', '2017-06-19 09:49:52'),
(6, 'asim@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello M Asim ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : asim@mobinspire.com</p><p>Login Password : m.asim123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:50:23', '2017-06-19 09:50:23'),
(7, 'zakir@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello M Zakir ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : zakir@mobinspire.com</p><p>Login Password : m.zakir123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:50:54', '2017-06-19 09:50:54'),
(8, 'faisal@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello M Faisal ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : faisal@mobinspire.com</p><p>Login Password : faisal123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:51:28', '2017-06-19 09:51:28'),
(9, 'arslan@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello M.Arslan Hassan ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : arslan@mobinspire.com</p><p>Login Password : arslan.h123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:51:59', '2017-06-19 09:51:59'),
(10, 'maryam@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Maryam Sohail ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : maryam@mobinspire.com</p><p>Login Password : maryam123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:52:29', '2017-06-19 09:52:29'),
(11, 'ovais@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Ovais ilyas ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : ovais@mobinspire.com</p><p>Login Password : ovais123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:52:58', '2017-06-19 09:52:58'),
(12, 'raheel@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Raheel Altaf ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : raheel@mobinspire.com</p><p>Login Password : raheel123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:53:23', '2017-06-19 09:53:23'),
(13, 'saqib@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Saqib Naveed ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : saqib@mobinspire.com</p><p>Login Password : saqib123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:53:52', '2017-06-19 09:53:52'),
(14, 'sohail@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Sohail Afzal ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : sohail@mobinspire.com</p><p>Login Password : sohail123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:54:22', '2017-06-19 09:54:22'),
(15, 'umar@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Umer Bilal ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : umar@mobinspire.com</p><p>Login Password : umer123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:54:47', '2017-06-19 09:54:47'),
(16, 'm.usman@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td valign="top">			\r\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tbody><tr><td width="600" height="90" align="right">\r\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\r\n								\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\r\n								<table align="center"><tbody><tr><td width="560" height="10">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Hello Usman Aslam ,<br></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br><br>Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : m.usman@mobinspire.com</p><p>Login Password : usman123!@#<br></p><p><br></p></td>\r\n										</tr><tr><td width="560" height="10"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td width="600" height="10">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br>\r\n								hr@mobinspire.com <br>\r\n								03165413670 <br>\r\n								https://www.mobinspire.com <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', NULL, NULL, NULL, '2017-06-19 09:55:14', '2017-06-19 09:55:14'),
(17, 'hashir@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td valign="top">			\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td width="600" height="90" align="right">\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\n								\n							</td>\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\n								<table align="center"><tr><td width="560" height="10"> </td>\n										</tr><tr><td width="560">\n												<p>Hello hashir javed ,<br /></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br /><br />Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br /></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : hashir@mobinspire.com</p><p>Login Password : <br /></p><p><br /></p></td>\n										</tr><tr><td width="560" height="10"></td>\n										</tr></table></td>\n						</tr><tr><td width="600" height="10"> </td></tr><tr><td align="right">\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br />\n								hr@mobinspire.com <br />\n								03165413670 <br />\n								https://www.mobinspire.com <br /></span>\n							</td>\n						</tr></table></td>\n		</tr></table>', NULL, NULL, NULL, '2017-07-11 23:02:42', '2017-07-11 23:02:42'),
(18, 'azam@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td valign="top">			\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td width="600" height="90" align="right">\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\n								\n							</td>\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\n								<table align="center"><tr><td width="560" height="10"> </td>\n										</tr><tr><td width="560">\n												<p>Hello Muhammad Azam ,<br /></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br /><br />Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br /></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : azam@mobinspire.com</p><p>Login Password : <br /></p><p><br /></p></td>\n										</tr><tr><td width="560" height="10"></td>\n										</tr></table></td>\n						</tr><tr><td width="600" height="10"> </td></tr><tr><td align="right">\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br />\n								hr@mobinspire.com <br />\n								03165413670 <br />\n								https://www.mobinspire.com <br /></span>\n							</td>\n						</tr></table></td>\n		</tr></table>', NULL, NULL, NULL, '2017-07-12 21:55:38', '2017-07-12 21:55:38'),
(19, 'ahmed@mobinspire.com', 'hr@mobinspire.com', 'Welcome Email | Mobinspire PVT Ltd', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td valign="top">			\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td width="600" height="90" align="right">\n								<p><img src="http://hrm.mobinspire.com/uploads/company_logo/593e3ded06eb8.png"></p>\n								\n							</td>\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\n								<table align="center"><tr><td width="560" height="10"> </td>\n										</tr><tr><td width="560">\n												<p>Hello ahmed hassan ,<br /></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br /><br />Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br /></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : ahmed@mobinspire.com</p><p>Login Password : <br /></p><p><br /></p></td>\n										</tr><tr><td width="560" height="10"></td>\n										</tr></table></td>\n						</tr><tr><td width="600" height="10"> </td></tr><tr><td align="right">\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">Mobinspire PVT Ltd <br />\n								hr@mobinspire.com <br />\n								03165413670 <br />\n								https://www.mobinspire.com <br /></span>\n							</td>\n						</tr></table></td>\n		</tr></table>', NULL, NULL, NULL, '2017-08-01 23:39:20', '2017-08-01 23:39:20');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expense_head_id` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `amount` decimal(25,0) NOT NULL DEFAULT '0',
  `date_of_expense` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `expense_head_id` (`expense_head_id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `expense_heads`
--

CREATE TABLE IF NOT EXISTS `expense_heads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `expense_status_details`
--

CREATE TABLE IF NOT EXISTS `expense_status_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_id` (`expense_id`),
  KEY `designation_id` (`designation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE IF NOT EXISTS `holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`id`, `date`, `description`, `created_at`, `updated_at`) VALUES
(1, '2017-02-05', 'Kashmir Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(2, '2017-03-23', 'Pakistan Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(3, '2017-04-17', 'Easter Monday ', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(4, '2017-05-01', 'Labour Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(5, '2017-06-26', 'Eid ul-Fitr', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(6, '2017-06-27', 'Eid ul-Fitr Holiday', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(7, '2017-06-28', 'Eid ul-Fitr Holiday', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(8, '2017-08-14', 'Independence Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(9, '2017-09-01', 'Eid ul-Azha Holiday', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(10, '2017-09-02', 'Eid ul-Azha', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(11, '2017-09-03', 'Eid ul-Azha Holiday', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(12, '2017-09-30', 'Ashura', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(13, '2017-10-01', 'Ashura', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(14, '2017-11-09', 'Iqbal Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(15, '2017-12-01', 'Milad un-Nabi', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(16, '2017-12-25', 'Christmas Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47'),
(17, '2017-12-25', 'Quiad-e-Azam Day', '2017-06-12 15:18:47', '2017-06-12 15:18:47');

-- --------------------------------------------------------

--
-- Table structure for table `ip_filters`
--

CREATE TABLE IF NOT EXISTS `ip_filters` (
  `ip` int(11) NOT NULL AUTO_INCREMENT,
  `start` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contract_type_id` int(11) DEFAULT NULL,
  `date_of_closing` date DEFAULT NULL,
  `no_of_post` int(11) NOT NULL DEFAULT '0',
  `publish_portal` int(11) NOT NULL DEFAULT '0',
  `location_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `age_info` int(11) NOT NULL DEFAULT '0',
  `start_age` int(11) NOT NULL DEFAULT '0',
  `end_age` int(11) NOT NULL DEFAULT '0',
  `salary_info` int(11) NOT NULL DEFAULT '0',
  `currency_id` int(11) DEFAULT NULL,
  `start_salary` int(11) NOT NULL DEFAULT '0',
  `end_salary` int(11) NOT NULL DEFAULT '0',
  `qualification` text COLLATE utf8_unicode_ci,
  `experience` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_type_id` (`contract_type_id`),
  KEY `location_id` (`location_id`),
  KEY `designation_id` (`designation_id`),
  KEY `currency_id` (`currency_id`),
  KEY `user_Id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE IF NOT EXISTS `job_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `primary_contact_number` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `secondary_contact_number` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `additional_information` text COLLATE utf8_unicode_ci,
  `status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_application` date DEFAULT NULL,
  `applicant_user_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_id` (`job_id`),
  KEY `applicant_user_id` (`applicant_user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `job_application_status_details`
--

CREATE TABLE IF NOT EXISTS `job_application_status_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_application_id` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_application_id` (`job_application_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE IF NOT EXISTS `leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `leave_type_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `date_approved` text COLLATE utf8_unicode_ci,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `leave_type_id` (`leave_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`, `uuid`, `user_id`, `leave_type_id`, `from_date`, `to_date`, `description`, `date_approved`, `status`, `is_archived`, `created_at`, `updated_at`) VALUES
(1, '93220410-4f88-11e7-8658-71abd835255c', 3, 4, '2017-06-14', '2017-06-14', '', '2017-06-14', 'approved', 0, '2017-06-13 04:02:46', '2017-06-13 06:12:47'),
(2, 'd5f3ab20-4f9e-11e7-9cbf-ad6377d11e2c', 3, 4, '2017-06-12', '2017-06-12', '', NULL, 'rejected', 0, '2017-06-13 06:42:07', '2017-06-13 06:43:18'),
(3, '03798500-6637-11e7-af9d-33bf6a07b159', 11, 2, '2017-07-17', '2017-07-17', '', NULL, 'pending', 0, '2017-07-12 00:46:52', '2017-07-12 00:46:52'),
(4, '349f1290-6637-11e7-9c50-bf48e572062b', 11, 4, '2017-07-14', '2017-07-14', '', NULL, 'pending', 0, '2017-07-12 00:48:15', '2017-07-12 00:48:15'),
(5, 'ceca87e0-7679-11e7-b7ec-6f4d75c795b5', 7, 2, '2017-08-01', '2017-08-01', 'I have guests at home. Family needs to visit a few relatives and markets so I have to take them there. Thanks!', NULL, 'pending', 0, '2017-08-01 17:25:19', '2017-08-01 17:25:19'),
(6, '3f86a910-7c26-11e7-971b-45712831eb55', 23, 2, '2017-08-09', '2017-08-09', 'I have some tasks at home, please grant me leave. I shall be very thankful to you. \r\nkindly adjust my leave with floating holiday.', NULL, 'pending', 0, '2017-08-08 22:42:17', '2017-08-08 22:42:17'),
(7, '085de090-8303-11e7-9cd3-2f6eaed8c35c', 7, 4, '2017-08-17', '2017-08-17', 'Have a cousin''s wedding at my home, so I''ll have to leave after the first half in order to make some arrangements at home. I''ll be needing a half day leave on the 17th and 18th of August. Thanks!', NULL, 'pending', 0, '2017-08-17 16:17:50', '2017-08-17 16:17:50'),
(8, '201f9b80-8303-11e7-8980-13f999edf47f', 7, 4, '2017-08-18', '2017-08-18', 'Have a cousin''s wedding at my home, so I''ll have to leave after the first half in order to make some arrangements at home. I''ll be needing a half day leave on the 17th and 18th of August. Thanks!', NULL, 'pending', 0, '2017-08-17 16:18:30', '2017-08-17 16:18:30'),
(9, 'c61a7c20-bfb0-11e7-9b3f-499e0ebd0ae0', 7, 2, '2017-11-16', '2017-11-16', 'I have to go to Lahore with Family', NULL, 'pending', 0, '2017-11-02 21:32:41', '2017-11-02 21:32:41'),
(10, 'd308b8d0-bfb0-11e7-9a2c-9db9da137617', 7, 2, '2017-11-17', '2017-11-17', 'I have to go to Lahore with Family', NULL, 'pending', 0, '2017-11-02 21:33:03', '2017-11-02 21:33:03'),
(11, 'e0ab2d70-bfb0-11e7-b2b9-6968ba456d91', 7, 2, '2017-11-20', '2017-11-20', 'I have to go to Lahore with Family', NULL, 'pending', 0, '2017-11-02 21:33:26', '2017-11-02 21:33:26'),
(12, 'e7680e10-bfb0-11e7-8349-653cc4c7c668', 7, 2, '2017-11-21', '2017-11-21', 'I have to go to Lahore with Family', NULL, 'pending', 0, '2017-11-02 21:33:37', '2017-11-02 21:33:37');

-- --------------------------------------------------------

--
-- Table structure for table `leave_status_details`
--

CREATE TABLE IF NOT EXISTS `leave_status_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `date_approved` text COLLATE utf8_unicode_ci,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_id` (`leave_id`),
  KEY `designation_id` (`designation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Dumping data for table `leave_status_details`
--

INSERT INTO `leave_status_details` (`id`, `leave_id`, `designation_id`, `date_approved`, `status`, `remarks`, `created_at`, `updated_at`) VALUES
(1, 1, 17, '2017-06-14', 'approved', 'ok', '2017-06-12 16:02:46', '2017-06-13 06:11:24'),
(2, 1, 1, '2017-06-14', 'approved', '', '2017-06-12 16:02:46', '2017-06-13 06:12:47'),
(3, 2, 17, NULL, 'rejected', 'You have some work', '2017-06-12 18:42:07', '2017-06-13 06:43:18'),
(4, 2, 1, NULL, NULL, NULL, '2017-06-12 18:42:07', '2017-06-13 06:43:18'),
(5, 3, 15, NULL, 'pending', NULL, '2017-07-11 12:46:52', NULL),
(6, 3, 18, NULL, NULL, NULL, '2017-07-11 12:46:52', NULL),
(7, 4, 15, NULL, 'pending', NULL, '2017-07-11 12:48:15', NULL),
(8, 4, 18, NULL, NULL, NULL, '2017-07-11 12:48:15', NULL),
(9, 5, 18, NULL, 'pending', NULL, '2017-08-01 05:25:19', NULL),
(10, 5, 17, NULL, NULL, NULL, '2017-08-01 05:25:19', NULL),
(11, 6, 17, NULL, 'pending', NULL, '2017-08-08 10:42:17', NULL),
(12, 6, 1, NULL, NULL, NULL, '2017-08-08 10:42:17', NULL),
(13, 7, 18, NULL, 'pending', NULL, '2017-08-17 04:17:50', NULL),
(14, 7, 17, NULL, NULL, NULL, '2017-08-17 04:17:50', NULL),
(15, 8, 18, '2017-08-18', 'approved', '', '2017-08-17 04:18:30', '2017-08-17 22:14:09'),
(16, 8, 17, NULL, 'pending', NULL, '2017-08-17 04:18:30', '2017-08-17 22:14:09'),
(17, 9, 18, NULL, 'pending', NULL, '2017-11-02 09:32:41', NULL),
(18, 9, 17, NULL, NULL, NULL, '2017-11-02 09:32:41', NULL),
(19, 10, 18, NULL, 'pending', NULL, '2017-11-02 09:33:03', NULL),
(20, 10, 17, NULL, NULL, NULL, '2017-11-02 09:33:03', NULL),
(21, 11, 18, NULL, 'pending', NULL, '2017-11-02 09:33:26', NULL),
(22, 11, 17, NULL, NULL, NULL, '2017-11-02 09:33:26', NULL),
(23, 12, 18, NULL, 'pending', NULL, '2017-11-02 09:33:37', NULL),
(24, 12, 17, NULL, NULL, NULL, '2017-11-02 09:33:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE IF NOT EXISTS `leave_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_half_day` int(11) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`id`, `name`, `is_half_day`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Sick Leaves', 0, 'Certification of illness by a certified physician is required\r\nafter the employee takes more than 2 sick leaves. If you are going to\r\navail sick leave you must notify your People''s Manager and HR 60\r\nminutes before the beginning of your workday i.e. 9:00 AM.', '2017-06-12 19:42:13', '2017-06-12 19:46:48'),
(2, 'Casual Leaves', 0, 'No more than 3 consecutive days can be availed for\r\ncasual leaves. Causal leaves can be en-cashed at the end of the year, if you have completed one year of employment with MOB INSPIRE\r\n(PVT) LTD. Causal leave must be notified at least one day in advance\r\nwith proper process followed.', '2017-06-12 19:42:56', '2017-06-12 19:46:48'),
(3, 'Annual Leaves', 0, 'These leaves must be\r\nplanned at least 1 month beforehand with the manager and HR and\r\nare available after 6 months of continuous regular service with the company. leaves should be taken all together. However, \r\nleaves cannot be availed once an employee has served notice period to leave the company.', '2017-06-12 19:45:22', '2017-06-12 19:46:48'),
(4, 'Half Day Leave', 1, 'leave can be availed for maximum 4 hours.\r\nIt is advised that half day should be taken either in morning (from\r\noffice starting time till 4 hours) or in evening just 4 hours before office end time. Half day should be informed in advance to the People''s Manager and HR.', '2017-06-12 19:46:48', '2017-06-12 19:46:48');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `top_location_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `top_location_id` (`top_location_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `top_location_id`, `name`, `address_line_1`, `address_line_2`, `city`, `state`, `zipcode`, `country_id`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Pakistan Office', 'Office NO 1-B, First Floor Umer Plaza, 76-West, Blue Area Jinnah Avenue, Near to Fresco Sweets', '', 'Islamabad', 'Federal', '44000', 178, '2017-06-12 20:16:48', '2017-06-12 20:16:48');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `visible` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `order`, `visible`) VALUES
(1, 'home', 1, 1),
(2, 'user', 2, 1),
(3, 'attendance', 3, 1),
(4, 'holiday', 4, 1),
(5, 'leave', 5, 1),
(6, 'payroll', 6, 1),
(7, 'award', 7, 1),
(8, 'daily_report', 8, 1),
(9, 'announcement', 9, 1),
(10, 'expense', 10, 1),
(11, 'task', 11, 1),
(12, 'ticket', 12, 1),
(13, 'message', 13, 1),
(14, 'job', 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_draft` int(11) NOT NULL DEFAULT '0',
  `from_user_id` int(11) DEFAULT NULL,
  `to_user_id` int(11) DEFAULT NULL,
  `subject` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `is_starred_sender` int(11) NOT NULL DEFAULT '0',
  `is_starred_receiver` int(11) NOT NULL DEFAULT '0',
  `is_read` int(11) NOT NULL DEFAULT '0',
  `delete_sender` int(11) NOT NULL DEFAULT '0',
  `delete_receiver` int(11) NOT NULL DEFAULT '0',
  `reply_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`uuid`),
  KEY `from_user_id` (`from_user_id`),
  KEY `to_user_id` (`to_user_id`),
  KEY `reply_id` (`reply_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `uuid`, `is_draft`, `from_user_id`, `to_user_id`, `subject`, `body`, `is_starred_sender`, `is_starred_receiver`, `is_read`, `delete_sender`, `delete_receiver`, `reply_id`, `created_at`, `updated_at`) VALUES
(1, '6f245a20-4f86-11e7-bac9-cfa18f9cb274', 0, 1, 3, 'hi', '<p>vvf<br /></p>', 0, 0, 0, 0, 0, NULL, '2017-06-13 03:47:27', '2017-06-13 03:47:27'),
(2, '9b77de30-4f86-11e7-a055-7343dd18e69d', 0, 1, 3, 'Fw: hi', '<p>vvf<br /></p>', 0, 0, 0, 0, 0, NULL, '2017-06-13 03:48:41', '2017-06-13 03:48:41'),
(3, 'd5b6db50-4f86-11e7-86a3-2defadbe4d7a', 0, 1, 3, 'Re: Fw: hi', '<p>xsxsx<br /></p>', 0, 0, 0, 0, 0, 2, '2017-06-13 03:50:18', '2017-06-13 03:50:18'),
(4, '3c688050-4f88-11e7-90f1-9f896e428e79', 0, 1, 3, 'cxcxc', '<p>xzcxzczxcxczxc<br /></p>', 0, 0, 0, 0, 0, NULL, '2017-06-13 04:00:20', '2017-06-13 04:00:20');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user` text COLLATE utf8_unicode_ci,
  `user_read` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `uuid`, `module`, `module_id`, `user_id`, `description`, `url`, `user`, `user_read`, `created_at`, `updated_at`) VALUES
(1, 'eaf567f0-4f9b-11e7-9122-69895a3d9bde', 'demo', 1, 1, 'admin hrm sent you a demo Real Time Notification.', '/demo-real-time-notification', '3,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21', '1,2,7,4', '2017-06-13 06:21:13', '2017-08-11 02:31:24'),
(2, 'fd97e260-4f9b-11e7-971c-392222863f5c', 'demo', 1, 1, 'admin hrm sent you a demo Real Time Notification.', '/demo-real-time-notification', '3,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21', '1,2,7,4', '2017-06-13 06:21:45', '2017-08-11 02:31:23'),
(3, '42e0bdc0-4f9c-11e7-ae08-c5307fd50f59', 'demo', 1, 1, 'admin hrm sent you a demo Real Time Notification.', '/demo-real-time-notification', '3,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21', '1,2,7,4', '2017-06-13 06:23:41', '2017-08-11 02:31:22'),
(4, '4d274ea0-4f9c-11e7-b0b9-8f6f0d25a6e1', 'demo', 1, 1, 'admin hrm sent you a demo Real Time Notification.', '/demo-real-time-notification', '3,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21', '1,2,7,4', '2017-06-13 06:23:58', '2017-08-11 02:31:27'),
(5, 'd5f4a6a0-4f9e-11e7-a57b-9b11b0ec7573', 'leave', 2, 3, 'Abdur Rehman requested a leave which needs your approval.', '/leave/d5f3ab20-4f9e-11e7-9cbf-ad6377d11e2c', '', '4', '2017-06-13 06:42:07', '2017-06-13 06:42:51'),
(6, '00bc3020-4f9f-11e7-8105-57223cb12b40', 'leave', 2, 4, 'Ahmed Abdullah rejected a leave requested by you.', '/leave/d5f3ab20-4f9e-11e7-9cbf-ad6377d11e2c', '', '3', '2017-06-13 06:43:18', '2017-06-13 06:43:28'),
(7, '037ac7d0-6637-11e7-800d-d340c292b50c', 'leave', 3, 11, 'Maryam Sohail requested a leave which needs your approval.', '/leave/03798500-6637-11e7-af9d-33bf6a07b159', '6', '', '2017-07-12 00:46:52', '2017-07-12 00:46:52'),
(8, '34a00500-6637-11e7-9543-0bd4ce19b123', 'leave', 4, 11, 'Maryam Sohail requested a leave which needs your approval.', '/leave/349f1290-6637-11e7-9c50-bf48e572062b', '6', '', '2017-07-12 00:48:15', '2017-07-12 00:48:15'),
(9, 'cecbaca0-7679-11e7-a807-b1c140a39719', 'leave', 5, 7, 'M Bilal requested a leave which needs your approval.', '/leave/ceca87e0-7679-11e7-b7ec-6f4d75c795b5', '3,23', '', '2017-08-01 17:25:19', '2017-08-01 17:25:19'),
(10, '3f87c180-7c26-11e7-b91c-c5d3eb2c791b', 'leave', 6, 23, 'hashir javed requested a leave which needs your approval.', '/leave/3f86a910-7c26-11e7-971b-45712831eb55', '', '4', '2017-08-08 22:42:17', '2017-08-11 02:29:43'),
(11, '085f5260-8303-11e7-ab9f-0114e28396b0', 'leave', 7, 7, 'M Bilal requested a leave which needs your approval.', '/leave/085de090-8303-11e7-9cd3-2f6eaed8c35c', '3', '23', '2017-08-17 16:17:50', '2017-08-17 18:37:24'),
(12, '2020d8a0-8303-11e7-9101-f921f0c72983', 'leave', 8, 7, 'M Bilal requested a leave which needs your approval.', '/leave/201f9b80-8303-11e7-8980-13f999edf47f', '', '23,3', '2017-08-17 16:18:30', '2017-08-25 00:02:14'),
(13, 'cf1239a0-8334-11e7-b000-8f75b9eb2c00', 'leave', 8, 23, 'hashir javed approved your leave and it is sent for further approval.', '/leave/201f9b80-8303-11e7-8980-13f999edf47f', '', '7', '2017-08-17 22:14:09', '2017-08-24 02:39:01'),
(14, 'd0963560-8334-11e7-8b05-637ddc02a45d', 'leave', 8, 23, 'hashir javed requested a leave which needs your approval.', '/leave/201f9b80-8303-11e7-8980-13f999edf47f', '4', '', '2017-08-17 22:14:11', '2017-08-17 22:14:11'),
(15, 'c61ba3a0-bfb0-11e7-92e4-fd2026962480', 'leave', 9, 7, 'M Bilal requested a leave which needs your approval.', '/leave/c61a7c20-bfb0-11e7-9b3f-499e0ebd0ae0', '3,23', '', '2017-11-02 21:32:41', '2017-11-02 21:32:41'),
(16, 'd309a5e0-bfb0-11e7-9b72-3bd3141f4d4d', 'leave', 10, 7, 'M Bilal requested a leave which needs your approval.', '/leave/d308b8d0-bfb0-11e7-9a2c-9db9da137617', '3,23', '', '2017-11-02 21:33:03', '2017-11-02 21:33:03'),
(17, 'e0ac04f0-bfb0-11e7-a5ce-f3e4b8f65d69', 'leave', 11, 7, 'M Bilal requested a leave which needs your approval.', '/leave/e0ab2d70-bfb0-11e7-b2b9-6968ba456d91', '3,23', '', '2017-11-02 21:33:26', '2017-11-02 21:33:26'),
(18, 'e768fa60-bfb0-11e7-860a-bf8335c00e48', 'leave', 12, 7, 'M Bilal requested a leave which needs your approval.', '/leave/e7680e10-bfb0-11e7-8349-653cc4c7c668', '3,23', '', '2017-11-02 21:33:37', '2017-11-02 21:33:37');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payrolls`
--

CREATE TABLE IF NOT EXISTS `payrolls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `date_of_payroll` date DEFAULT NULL,
  `is_hourly` int(11) NOT NULL DEFAULT '0',
  `hourly` decimal(25,5) NOT NULL DEFAULT '0.00000',
  `late` decimal(25,5) NOT NULL DEFAULT '0.00000',
  `early_leaving` decimal(25,5) NOT NULL DEFAULT '0.00000',
  `overtime` decimal(25,5) NOT NULL DEFAULT '0.00000',
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payroll_details`
--

CREATE TABLE IF NOT EXISTS `payroll_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payroll_id` int(11) DEFAULT NULL,
  `salary_head_id` int(11) DEFAULT NULL,
  `amount` decimal(25,5) NOT NULL DEFAULT '0.00000',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_id` (`payroll_id`),
  KEY `salary_head_id` (`salary_head_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=74 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `category`, `description`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'enable-login', 'login', NULL, 1, '2017-06-12 07:03:39', NULL),
(2, 'manage-configuration', 'configuration', NULL, 1, '2017-06-12 07:03:39', NULL),
(3, 'manage-localization', 'localization', NULL, 1, '2017-06-12 07:03:39', NULL),
(4, 'change-localization', 'localization', NULL, 1, '2017-06-12 07:03:39', NULL),
(5, 'manage-backup', 'backup', NULL, 1, '2017-06-12 07:03:39', NULL),
(6, 'manage-template', 'template', NULL, 1, '2017-06-12 07:03:39', NULL),
(7, 'manage-ip-filter', 'ip-filter', NULL, 1, '2017-06-12 07:03:39', NULL),
(8, 'manage-custom-field', 'custom-field', NULL, 1, '2017-06-12 07:03:39', NULL),
(9, 'manage-permission', 'permission', NULL, 1, '2017-06-12 07:03:39', NULL),
(10, 'list-designation', 'designation', NULL, 1, '2017-06-12 07:03:39', NULL),
(11, 'create-designation', 'designation', NULL, 1, '2017-06-12 07:03:39', NULL),
(12, 'edit-designation', 'designation', NULL, 1, '2017-06-12 07:03:39', NULL),
(13, 'delete-designation', 'designation', NULL, 1, '2017-06-12 07:03:39', NULL),
(14, 'manage-all-designation', 'designation', NULL, 1, '2017-06-12 07:03:39', NULL),
(15, 'manage-subordinate-designation', 'designation', NULL, 1, '2017-06-12 07:03:39', NULL),
(16, 'list-department', 'department', NULL, 1, '2017-06-12 07:03:39', NULL),
(17, 'create-department', 'department', NULL, 1, '2017-06-12 07:03:39', NULL),
(18, 'edit-department', 'department', NULL, 1, '2017-06-12 07:03:39', NULL),
(19, 'delete-department', 'department', NULL, 1, '2017-06-12 07:03:39', NULL),
(20, 'list-location', 'location', NULL, 1, '2017-06-12 07:03:39', NULL),
(21, 'create-location', 'location', NULL, 1, '2017-06-12 07:03:39', NULL),
(22, 'edit-location', 'location', NULL, 1, '2017-06-12 07:03:39', NULL),
(23, 'delete-location', 'location', NULL, 1, '2017-06-12 07:03:39', NULL),
(24, 'manage-all-location', 'location', NULL, 1, '2017-06-12 07:03:39', NULL),
(25, 'manage-subordinate-location', 'location', NULL, 1, '2017-06-12 07:03:39', NULL),
(26, 'manage-todo', 'to_do', NULL, 1, '2017-06-12 07:03:39', NULL),
(27, 'manage-role', 'role', NULL, 1, '2017-06-12 07:03:39', NULL),
(28, 'list-user', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(29, 'create-user', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(30, 'edit-user', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(31, 'delete-user', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(32, 'reset-user-password', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(33, 'email-user', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(34, 'change-user-status', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(35, 'login-as-user', 'user', NULL, 1, '2017-06-12 07:03:39', NULL),
(36, 'manage-email-log', 'template', NULL, 1, '2017-06-12 07:03:39', NULL),
(37, 'manage-message', 'message', NULL, 1, '2017-06-12 07:03:39', NULL),
(38, 'list-announcement', 'announcement', NULL, 1, '2017-06-12 07:03:39', NULL),
(39, 'create-announcement', 'announcement', NULL, 1, '2017-06-12 07:03:39', NULL),
(40, 'edit-announcement', 'announcement', NULL, 1, '2017-06-12 07:03:39', NULL),
(41, 'delete-announcement', 'announcement', NULL, 1, '2017-06-12 07:03:39', NULL),
(42, 'manage-shift', 'shift', NULL, 1, '2017-06-12 07:03:39', NULL),
(43, 'list-task', 'task', NULL, 1, '2017-06-12 07:03:39', NULL),
(44, 'create-task', 'task', NULL, 1, '2017-06-12 07:03:39', NULL),
(45, 'edit-task', 'task', NULL, 1, '2017-06-12 07:03:39', NULL),
(46, 'delete-task', 'task', NULL, 1, '2017-06-12 07:03:39', NULL),
(47, 'list-daily-report', 'daily_report', NULL, 1, '2017-06-12 07:03:39', NULL),
(48, 'create-daily-report', 'daily_report', NULL, 1, '2017-06-12 07:03:39', NULL),
(49, 'edit-daily-report', 'daily_report', NULL, 1, '2017-06-12 07:03:39', NULL),
(50, 'delete-daily-report', 'daily_report', NULL, 1, '2017-06-12 07:03:39', NULL),
(51, 'manage-holiday', 'holiday', NULL, 1, '2017-06-12 07:03:39', NULL),
(52, 'list-expense', 'expense', NULL, 1, '2017-06-12 07:03:39', NULL),
(53, 'create-expense', 'expense', NULL, 1, '2017-06-12 07:03:39', NULL),
(54, 'edit-expense', 'expense', NULL, 1, '2017-06-12 07:03:39', NULL),
(55, 'delete-expense', 'expense', NULL, 1, '2017-06-12 07:03:39', NULL),
(56, 'list-leave', 'leave', NULL, 1, '2017-06-12 07:03:39', NULL),
(57, 'request-leave', 'leave', NULL, 1, '2017-06-12 07:03:39', NULL),
(58, 'edit-leave', 'leave', NULL, 1, '2017-06-12 07:03:39', NULL),
(59, 'delete-leave', 'leave', NULL, 1, '2017-06-12 07:03:39', NULL),
(60, 'manage-job', 'job', NULL, 1, '2017-06-12 07:03:39', NULL),
(61, 'list-ticket', 'ticket', NULL, 1, '2017-06-12 07:03:39', NULL),
(62, 'create-ticket', 'ticket', NULL, 1, '2017-06-12 07:03:39', NULL),
(63, 'delete-ticket', 'ticket', NULL, 1, '2017-06-12 07:03:39', NULL),
(64, 'list-award', 'award', NULL, 1, '2017-06-12 07:03:39', NULL),
(65, 'create-award', 'award', NULL, 1, '2017-06-12 07:03:39', NULL),
(66, 'edit-award', 'award', NULL, 1, '2017-06-12 07:03:39', NULL),
(67, 'delete-award', 'award', NULL, 1, '2017-06-12 07:03:39', NULL),
(68, 'edit-attendance', 'attendance', NULL, 1, '2017-06-12 07:03:39', NULL),
(69, 'upload-attendance', 'attendance', NULL, 1, '2017-06-12 07:03:39', NULL),
(70, 'create-payroll', 'payroll', NULL, 1, '2017-06-12 07:03:39', NULL),
(71, 'create-multiple-payroll', 'payroll', NULL, 1, '2017-06-12 07:03:39', NULL),
(72, 'edit-payroll', 'payroll', NULL, 1, '2017-06-12 07:03:39', NULL),
(73, 'delete-payroll', 'payroll', NULL, 1, '2017-06-12 07:03:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE IF NOT EXISTS `permission_role` (
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(73, 1),
(1, 2),
(10, 2),
(26, 2),
(28, 2),
(37, 2),
(38, 2),
(43, 2),
(47, 2),
(52, 2),
(56, 2),
(57, 2),
(64, 2),
(1, 3),
(6, 3),
(10, 3),
(11, 3),
(12, 3),
(13, 3),
(14, 3),
(15, 3),
(16, 3),
(17, 3),
(18, 3),
(19, 3),
(26, 3),
(27, 3),
(28, 3),
(29, 3),
(30, 3),
(31, 3),
(32, 3),
(33, 3),
(34, 3),
(35, 3),
(36, 3),
(37, 3),
(38, 3),
(39, 3),
(40, 3),
(41, 3),
(47, 3),
(48, 3),
(49, 3),
(50, 3),
(51, 3),
(52, 3),
(53, 3),
(54, 3),
(55, 3),
(56, 3),
(57, 3),
(58, 3),
(59, 3),
(60, 3),
(64, 3),
(65, 3),
(66, 3),
(67, 3),
(68, 3),
(69, 3),
(70, 3),
(71, 3),
(72, 3),
(73, 3);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employee_code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `avatar` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `date_of_anniversary` date DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unique_identification_number` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_phone` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_phone_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `home_phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `google_plus` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `github` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `designation_id` (`designation_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `first_name`, `last_name`, `employee_code`, `user_id`, `avatar`, `mobile`, `date_of_birth`, `date_of_anniversary`, `designation_id`, `location_id`, `gender`, `nationality`, `marital_status`, `unique_identification_number`, `phone`, `work_phone`, `work_phone_extension`, `home_phone`, `work_email`, `address_line_1`, `address_line_2`, `city`, `state`, `zipcode`, `country_id`, `facebook`, `twitter`, `google_plus`, `github`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'hrm', NULL, 1, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-06-12 07:03:36', '2017-06-12 20:52:05'),
(3, 'Abdur', 'Rehman', '1001', 3, NULL, NULL, '1990-06-26', '2016-08-01', 18, 1, 'male', 'pakistani', 'single', '61101-37818756', '', '', '', '', 'abdurrehman@mobinspire.com', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '2017-06-13 03:33:11', '2017-06-13 03:40:57'),
(4, 'Ahmed', 'Abdullah', '1000', 4, NULL, NULL, NULL, NULL, 17, NULL, NULL, NULL, 'single', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-06-13 04:08:31', '2017-06-13 04:08:31'),
(5, 'Zaheer', 'Abbas', '1002', 5, NULL, NULL, '1987-06-05', '2017-08-08', 2, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0321-4035396', 'zaheer_fastian@yahoo.com', 'KOHSAR TOWN, BARA KAHO, ISLAMABAD', '', 'Islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:09:53', '2017-06-13 23:47:15'),
(6, 'M.Arslan', 'Hassan', '1003', 6, NULL, NULL, '1990-02-11', '2017-09-22', 15, NULL, 'male', 'Pakistani', '', '', '', '', '', '0300-0525326', 'marsalan.hassan@gmail.com', 'HOUSE # 107, SAIDPUR SCHEME NUMBER 2, SATELLITE TOWN. RWP', '', 'Rawalpindi', '', '051', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:11:33', '2017-06-13 23:05:21'),
(7, 'M', 'Bilal', '1004', 7, NULL, NULL, '1991-03-11', '2017-08-01', 16, NULL, 'male', '', '', '', '', '', '', '03145290455', 'm_bilal_91@yahoo.com', 'HOUSE # 78, STREET # 3, SECTOR - G-10/2, ISLAMABAD, PAKISTAN', '', 'Islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:12:34', '2017-06-13 22:46:25'),
(8, 'M', 'Asim', '1005', 8, NULL, NULL, '1993-05-03', '2017-08-01', 5, NULL, 'male', 'Pakistani', '', '', '', '', '', '0334-5104278', 'mail4m.asim@gmail.com', '21-E-71 POF WAH CANTT', '', 'Rawalpindi, Wah', '', '', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:13:44', '2017-06-13 22:53:13'),
(9, 'Raheel', 'Altaf', '1006', 9, NULL, NULL, '1991-07-08', '2017-10-30', 3, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0313-5744774', 'raheel4774@gmail.com', 'HOUSE  #638G, MAIN DOUBLE ROAD, NEAR POLICE FOUNDATION, E 11/3, ISLAMABAD', '', 'islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:14:45', '2017-06-13 23:34:00'),
(10, 'Abdul', 'Wakeel', '1007', 10, NULL, NULL, '1992-11-12', NULL, NULL, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0341-0093024', '', 'STADIUM ROAD RAWAPINDI', '', 'Rawalpindi', '', '051', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:16:06', '2017-06-15 02:24:25'),
(11, 'Maryam', 'Sohail', '1008', 11, NULL, NULL, '1993-08-03', '2017-09-09', 11, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0343-5494953', 'maryamsohail76@yahoo.com', '387 WIRELESS COLONY NEAR RAILWAY HOSPITAL WESTRIDGE III,RWP', '', 'Rawalpindi', '', '051', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:17:06', '2017-06-13 23:13:14'),
(12, 'Sohail', 'Afzal', '1009', 12, NULL, NULL, '1986-01-16', '2017-12-21', 4, NULL, 'male', 'Pakistani', 'married', '', '', '', '', '0333-5754141', 'sohail1050@gmail.com', 'RAWAT ISLAMABAD', '', 'Rawat', '', '44000', '', NULL, NULL, NULL, NULL, '2017-06-13 04:18:24', '2017-06-13 23:39:26'),
(13, 'M', 'Zakir', '1010', 13, NULL, NULL, '1993-03-13', '2018-01-03', 11, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0336-6260297', 'mzakir11@hotmail.com', 'HOUSE#18, ST#73, MAIN DOUBLE ROAD, G-11/2, ISLAMABAD', '', 'Islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:19:58', '2017-06-13 22:59:30'),
(14, 'Aamir', 'Khan', '1012', 14, NULL, NULL, '1991-04-10', '2018-01-02', 7, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '03455918646', 'aamir.fastnu@gmail.com', 'House # 149 St 73 G-9/3 Islamabad', '', 'Islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:23:27', '2017-06-13 21:35:23'),
(15, 'Husnan', 'Ali', '1013', 15, NULL, NULL, '1992-09-21', '2018-02-08', 9, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '34603-7929483-1', '', 'NAZIM ABAD,SAIDPUR ROAD,RAWALPINDI', '', 'Rawalpindi', '', '051', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:24:56', '2017-08-04 17:48:03'),
(16, 'Usman', 'Saeed', '1014', 16, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-06-13 04:25:54', '2017-06-13 04:25:54'),
(17, 'Umer', 'Bilal', '1015', 17, NULL, NULL, '1992-08-06', '2017-11-17', 12, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0303-4498846', 'umerbilal736@gmail.com', 'HOUSE NO. 814 STREET NO.2 I/10-2 ISLAMABAD', '', 'Islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:26:58', '2017-06-13 23:42:58'),
(18, 'Ovais', 'ilyas', '1017', 18, NULL, NULL, '2018-02-08', '2018-02-08', 4, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '0300-4549531', 'awaisilyas01@gmail.com', 'HOUSE # 20, STREET 5, SECTOR B, SOHAN ISLAMABAD', '', 'Islamabad', '', '44000', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:30:11', '2017-06-13 23:19:23'),
(19, 'M', 'Faisal', '1018', 19, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-06-13 04:31:47', '2017-06-13 04:31:47'),
(20, 'Saqib', 'Naveed', '1019', 20, NULL, NULL, '1994-04-27', NULL, 10, NULL, 'male', 'Pakistani', '', '', '', '', '', '0344-5726269', 'saqibnaveed27@gmail.com', 'HOUSE NO. 107, STREET NO. 10, CHAKLALA SCHEME-3, RAWALPINDI', '', 'Rawalpindi', '', '051', '178', NULL, NULL, NULL, NULL, '2017-06-13 04:33:17', '2017-06-13 23:37:13'),
(21, 'Usman', 'Aslam', '1022', 21, NULL, NULL, NULL, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-06-13 04:34:42', '2017-06-13 04:34:42'),
(22, 'Ali', 'Tariq', '1020', 22, NULL, NULL, '1989-02-28', '2017-05-08', NULL, NULL, 'male', 'Pakistani', 'single', '37406-3767733-9', '', '', '', '051-5730504', 'hr@mobinspire.com', 'HOUSE 874, STREET 41, PHASE 2, BAHRIA TOWN. RAWALPINDI', '', '', '', '', '', NULL, NULL, NULL, NULL, '2017-06-23 19:50:28', '2017-09-26 18:59:59'),
(23, 'hashir', 'javed', '1016', 23, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-11 23:02:40', '2017-07-11 23:02:40'),
(24, 'Muhammad', 'Azam', '1028', 24, NULL, NULL, NULL, NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-07-12 21:55:37', '2017-07-12 21:55:37'),
(25, 'ahmed', 'hassan', '1030', 25, NULL, NULL, NULL, NULL, 13, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '2017-08-01 23:39:18', '2017-08-04 17:42:07'),
(26, 'Syed Anees Hassan', 'Shah', '1031', 26, NULL, NULL, NULL, NULL, 14, NULL, 'male', 'Pakistani', 'single', '', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '2017-08-10 22:15:08', '2017-08-10 22:34:32'),
(27, 'Waqas', 'Aziz', '1032', 27, NULL, NULL, NULL, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-09-11 19:36:50', '2017-09-11 19:36:50'),
(28, 'hamid', 'raza', '1033', 28, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-09-11 21:06:52', '2017-09-11 21:06:52'),
(29, 'mohsin', 'bashir', '1034', 29, NULL, NULL, NULL, NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-09-11 21:07:52', '2017-09-11 21:07:52'),
(30, 'Waqar', 'Saleem', '1035', 30, NULL, NULL, NULL, NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-09-26 19:04:38', '2017-09-26 19:04:38'),
(31, 'Faisal', 'Siraj', '1036', 31, NULL, NULL, NULL, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-10-04 21:40:35', '2017-10-04 21:40:35'),
(32, 'Sartaj', 'Hussian', '1037', 32, NULL, NULL, NULL, NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2017-10-04 21:41:56', '2017-10-04 21:41:56');

-- --------------------------------------------------------

--
-- Table structure for table `qualification_languages`
--

CREATE TABLE IF NOT EXISTS `qualification_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qualification_skills`
--

CREATE TABLE IF NOT EXISTS `qualification_skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `q_failed_jobs`
--

CREATE TABLE IF NOT EXISTS `q_failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `q_jobs`
--

CREATE TABLE IF NOT EXISTS `q_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_reserved_at_index` (`queue`,`reserved`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_hidden` int(11) NOT NULL DEFAULT '0',
  `is_default` int(11) NOT NULL DEFAULT '0',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_hidden`, `is_default`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 1, 0, NULL, NULL, NULL),
(2, 'user', 0, 1, '', '2017-06-12 19:55:31', '2017-06-12 19:55:31'),
(3, 'hr manager', 0, 0, '', '2017-06-12 19:55:45', '2017-06-12 19:55:45');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE IF NOT EXISTS `role_user` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 2),
(8, 2),
(9, 2),
(10, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(15, 2),
(16, 2),
(17, 2),
(18, 2),
(19, 2),
(20, 2),
(21, 2),
(24, 2),
(25, 2),
(26, 2),
(27, 2),
(28, 2),
(29, 2),
(30, 2),
(31, 2),
(32, 2),
(3, 3),
(22, 3),
(23, 3);

-- --------------------------------------------------------

--
-- Table structure for table `salary_heads`
--

CREATE TABLE IF NOT EXISTS `salary_heads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `type` enum('earning','deduction') COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_fixed` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `salary_heads`
--

INSERT INTO `salary_heads` (`id`, `name`, `description`, `type`, `is_fixed`, `created_at`, `updated_at`) VALUES
(1, 'Basic Salary', '', 'earning', 1, '2017-06-13 09:33:48', '2017-06-13 09:33:48');

-- --------------------------------------------------------

--
-- Table structure for table `setup`
--

CREATE TABLE IF NOT EXISTS `setup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `completed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `setup`
--

INSERT INTO `setup` (`id`, `module`, `completed`) VALUES
(1, 'installation', 1),
(2, 'general_configuration', 1),
(3, 'system_configuration', 1),
(4, 'mail', 1),
(5, 'menu', 1),
(6, 'role', 1),
(7, 'permission', 1),
(8, 'department', 1),
(9, 'designation', 1),
(10, 'location', 1),
(11, 'shift', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE IF NOT EXISTS `shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `is_default` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `shifts`
--

INSERT INTO `shifts` (`id`, `name`, `description`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'Day Shift', '', 1, '2017-06-12 19:54:19', '2017-06-12 19:54:19');

-- --------------------------------------------------------

--
-- Table structure for table `shift_details`
--

CREATE TABLE IF NOT EXISTS `shift_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shift_id` int(11) DEFAULT NULL,
  `day` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `overnight` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shift_id` (`shift_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `shift_details`
--

INSERT INTO `shift_details` (`id`, `shift_id`, `day`, `in_time`, `out_time`, `overnight`, `created_at`, `updated_at`) VALUES
(1, 1, 'monday', '09:00:00', '18:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(2, 1, 'tuesday', '09:00:00', '18:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(3, 1, 'wednesday', '09:00:00', '18:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(4, 1, 'thursday', '09:01:00', '18:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(5, 1, 'friday', '09:00:00', '18:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(6, 1, 'saturday', '00:00:00', '00:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20'),
(7, 1, 'sunday', '00:00:00', '00:00:00', 0, '2017-06-12 19:54:20', '2017-06-12 19:54:20');

-- --------------------------------------------------------

--
-- Table structure for table `starred_tasks`
--

CREATE TABLE IF NOT EXISTS `starred_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sub_tasks`
--

CREATE TABLE IF NOT EXISTS `sub_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sub_task_ratings`
--

CREATE TABLE IF NOT EXISTS `sub_task_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_task_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `rating` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_task_id` (`sub_task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_category_id` int(11) DEFAULT NULL,
  `task_priority_id` int(11) DEFAULT NULL,
  `title` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `complete_date` timestamp NULL DEFAULT NULL,
  `progress` int(11) DEFAULT '0',
  `tags` text COLLATE utf8_unicode_ci,
  `sub_task_rating` int(11) NOT NULL DEFAULT '0',
  `sign_off_status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_category_id` (`task_category_id`),
  KEY `user_id` (`user_id`),
  KEY `task_priority_id` (`task_priority_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_attachments`
--

CREATE TABLE IF NOT EXISTS `task_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `task_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `attachments` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_categories`
--

CREATE TABLE IF NOT EXISTS `task_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_comments`
--

CREATE TABLE IF NOT EXISTS `task_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_notes`
--

CREATE TABLE IF NOT EXISTS `task_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_priorities`
--

CREATE TABLE IF NOT EXISTS `task_priorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_signoff_requests`
--

CREATE TABLE IF NOT EXISTS `task_signoff_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `task_user`
--

CREATE TABLE IF NOT EXISTS `task_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_default` int(11) NOT NULL DEFAULT '0',
  `name` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8_unicode_ci,
  `body` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `is_default`, `name`, `slug`, `category`, `subject`, `body`, `created_at`, `updated_at`) VALUES
(1, 1, 'Welcome Email', 'welcome-email', 'user', 'Welcome Email | [COMPANY_NAME]', '<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td valign="top">			\n				<table cellspacing="0" cellpadding="0" border="0" align="center"><tr><td width="600" height="90" align="right">\n								<p>[COMPANY_LOGO]</p>\n								\n							</td>\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" width="600" valign="top">						\n								<table align="center"><tr><td width="560" height="10"> </td>\n										</tr><tr><td width="560">\n												<p>Hello [NAME] ,<br /></p><p>We''re pleased to announce the launch of Mob Inspire''s Employee portal. As part of our process improvement initiative - This portal is aiming towards a central place where employees can</p><p>- view company announcements</p><p>- go through their time sheets, </p><p>- Apply &amp; view leave record, </p><p>- view their official documents and hopefully in future </p><p>- a place where employees can use this tool for training, learning and development.<br /><br />Please note that all Time off Requested should be submitted through This Tool, any request that comes in through a different mean will not be entertained.<br /></p><p>URL : <a href="http://www.hrm.mobinspire.com">www.hrm.mobinspire.com</a></p><p>Login user : [EMAIL]</p><p>Login Password : <br /></p><p><br /></p></td>\n										</tr><tr><td width="560" height="10"></td>\n										</tr></table></td>\n						</tr><tr><td width="600" height="10"> </td></tr><tr><td align="right">\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">[COMPANY_NAME] <br />\n								[COMPANY_EMAIL] <br />\n								[COMPANY_PHONE] <br />\n								[COMPANY_WEBSITE] <br /></span>\n							</td>\n						</tr></table></td>\n		</tr></table>', '2017-06-12 07:03:39', '2017-06-19 09:47:47'),
(2, 1, 'Birthday Email', 'birthday-email', 'user', 'Happy Birthday [NAME] | [COMPANY_NAME]', '<table align="center" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td valign="top">			\r\n				<table align="center" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td height="90" width="600" align="right">\r\n								<p>[COMPANY_LOGO]</p>\r\n								<p style="text-align:left;font-size:16px;"><b>Happy Birthday</b></p>\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" valign="top" width="600">						\r\n								<table align="center"><tbody><tr><td height="10" width="560">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Dear [NAME],</p><p>We wish you a Very Happy Birthday.</p><p>Have a Good Day!!</p>\r\n											</td>\r\n										</tr><tr><td height="10" width="560"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td height="10" width="600">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">[COMPANY_NAME] <br>\r\n								[COMPANY_EMAIL] <br>\r\n								[COMPANY_PHONE] <br>\r\n								[COMPANY_WEBSITE] <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', '2017-06-12 07:03:39', NULL),
(3, 1, 'Anniversary Email', 'anniversary-email', 'user', 'Wish You a Very Happy Anniversary [NAME] | [COMPANY_NAME]', '<table align="center" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td valign="top">			\r\n				<table align="center" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td height="90" width="600" align="right">\r\n								<p>[COMPANY_LOGO]</p>\r\n								<p style="text-align:left;font-size:16px;"><b>Happy Anniversary</b></p>\r\n							</td>\r\n						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" valign="top" width="600">						\r\n								<table align="center"><tbody><tr><td height="10" width="560">&nbsp;</td>\r\n										</tr><tr><td width="560">\r\n												<p>Dear [NAME],</p><p>We wish you a Very Happy Anniversary.</p><p>Have a Good Day!!</p>\r\n											</td>\r\n										</tr><tr><td height="10" width="560"></td>\r\n										</tr></tbody></table></td>\r\n						</tr><tr><td height="10" width="600">&nbsp;</td></tr><tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">[COMPANY_NAME] <br>\r\n								[COMPANY_EMAIL] <br>\r\n								[COMPANY_PHONE] <br>\r\n								[COMPANY_WEBSITE] <br></span>\r\n							</td>\r\n						</tr></tbody></table></td>\r\n		</tr></tbody></table>', '2017-06-12 07:03:39', NULL),
(4, 1, 'Payroll', 'payroll', 'payroll', 'Payroll Generated | [COMPANY_NAME]', '<table align="center" border="0" cellpadding="0" cellspacing="0">\r\n	<tbody>\r\n		<tr>\r\n			<td valign="top">			\r\n				<table align="center" border="0" cellpadding="0" cellspacing="0">\r\n					<tbody>\r\n						<tr>\r\n							<td height="90" width="600" align="right">\r\n								<p>[COMPANY_LOGO]</p>\r\n								<p style="text-align:left;font-size:16px;"><b>Payroll Generated</b></p>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" valign="top" width="600">						\r\n								<table align="center">\r\n									<tbody>\r\n										<tr>\r\n											<td height="10" width="560">&nbsp;</td>\r\n										</tr>\r\n										<tr>\r\n											<td width="560">\r\n												<p>Dear [NAME],\r\n\r\n												<br> Payroll from [PAYROLL_FROM_DATE] to [PAYROLL_TO_DATE] is generated on [DATE_OF_PAYROLL]. Please find the Payroll in the attachment.\r\n\r\n												<br><p>Have a Good Day!!</p>\r\n											</td>\r\n										</tr>\r\n										<tr>\r\n											<td height="10" width="560"></td>\r\n										</tr>\r\n									</tbody>\r\n								</table>\r\n							</td>\r\n						</tr>\r\n						<tr><td height="10" width="600">&nbsp;</td></tr>\r\n						<tr><td align="right">\r\n								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">[COMPANY_NAME] <br>\r\n								[COMPANY_EMAIL] <br>\r\n								[COMPANY_PHONE] <br>\r\n								[COMPANY_WEBSITE] <br></span>\r\n							</td>\r\n						</tr>\r\n					</tbody>\r\n				</table>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', '2017-06-12 07:03:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `ticket_priority_id` int(11) DEFAULT NULL,
  `ticket_category_id` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_archived` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ticket_priority_id` (`ticket_priority_id`),
  KEY `ticket_category_id` (`ticket_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_categories`
--

CREATE TABLE IF NOT EXISTS `ticket_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_priorities`
--

CREATE TABLE IF NOT EXISTS `ticket_priorities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_replies`
--

CREATE TABLE IF NOT EXISTS `ticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE IF NOT EXISTS `todos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `visibility` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `module` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module_id` int(11) DEFAULT NULL,
  `upload_key` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attachments` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_temp_delete` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `uuid`, `user_id`, `module`, `module_id`, `upload_key`, `user_filename`, `attachments`, `is_temp_delete`, `status`, `created_at`, `updated_at`) VALUES
(6, NULL, 6, 'leave', NULL, 'nCKYrRmuSDsEgc5RIKx2pzfjBhRgyXxtegzWV4rQ', 'AAEAAQAAAAAAAAcwAAAAJDkyNzMzM2E2LWNiMGQtNDA5Ny1iMGM2LTJiMmNiOTlhYzZkOQ.png', 'WSQxnebcEb9CAGnbYVcL8dU9fNAAgtdKhOTijJFbRcQaACSn1q.png', 0, 0, '2017-06-20 21:52:26', '2017-06-20 21:52:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider_unique_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_hidden` int(11) NOT NULL DEFAULT '0',
  `is_default` int(11) NOT NULL DEFAULT '0',
  `disable_login` int(11) NOT NULL DEFAULT '0',
  `last_login` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login_now` timestamp NULL DEFAULT NULL,
  `last_login_ip_now` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `remember_token`, `activation_token`, `auth_token`, `status`, `provider`, `provider_unique_id`, `is_hidden`, `is_default`, `disable_login`, `last_login`, `last_login_ip`, `last_login_now`, `last_login_ip_now`, `created_at`, `updated_at`) VALUES
(1, 'adminhrm', 'admin@mobinspire.com', '$2y$10$/h9DvUHXd3ABtyGS6je3G.UC2L37a34DLE58JsPkVDlvL3gPcPdNW', 'PgEN3P7jPPXON7OV8LjczT3QCbuuaRhcE0JA62YsTT2IQw4mcQGEfRzRB9P7', NULL, NULL, 'active', NULL, NULL, 1, 0, 0, '2017-11-16 21:21:43', '115.186.130.14', '2017-11-17 01:34:38', '115.186.130.14', '2017-06-12 07:03:36', '2017-11-17 01:34:38'),
(3, 'm.abdurrehman', 'abdurrehman@mobinspire.com', '$2y$10$gWdMEMf7xJT.lZkjphbPTuBUmVbv9vffcoloodxLTPbvLgecqkxIy', 'PeG4sYE7v46DKdcESZZGNOHL643qw3K9ZvwAUnwXzP4cvYzLC3mktN9GDktz', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-06-13 06:45:02', '115.186.165.240', '2017-06-23 19:47:15', '103.255.6.90', '2017-06-13 03:33:11', '2017-06-23 19:47:15'),
(4, 'ahmed.abdullah', 'abdullah@mobinspire.com', '$2y$10$D62HtCAPb0/u8x3V9Y.5du3GnwEQbcj1LImIoJtV1g6f95xiLxzwy', '9FJebx5ItTmMM0IX42X3NWXYGyoxgjxYxUU5gSm6LZ47NkUaMdKdckWxjQDX', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-08-11 21:21:00', '103.255.6.76', '2017-11-05 06:08:01', '101.50.111.251', '2017-06-13 04:08:31', '2017-11-05 06:08:01'),
(5, 'zaheer.abbas', 'zaheer@mobinspire.com', '$2y$10$SNiTTUjp8G1o.dNvSUt3oO5okb39ZZTGuQ/KLPZPctORlvM4yNggC', NULL, NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, NULL, NULL, '2017-06-13 17:50:59', '115.186.130.14', '2017-06-13 04:09:53', '2017-07-30 17:35:06'),
(6, 'm.arslan', 'arslan@mobinspire.com', '$2y$10$bRzCtjGBlSIWEGzT/8VyVemsDoHjpJaX5AM.hEDtIwtYP1U1ud/WG', NULL, NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, '2017-07-11 21:32:20', '124.109.48.90', '2017-07-12 03:35:00', '124.109.48.90', '2017-06-13 04:11:33', '2017-07-30 17:32:27'),
(7, 'm.bilal', 'bilal@mobinspire.com', '$2y$10$2u8M2QBdjsxszZV8nA54BOGiR3eOiT6m8.oVgrT8RtkeaqbMvb7zC', 'oEttKzEz4UuaIr6n11fTa0yTeaAD1lnPyBAF942vbHSdzJQw6hNRxPMDUr1I', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-11-02 18:43:27', '115.186.130.14', '2017-11-03 16:18:21', '115.186.130.14', '2017-06-13 04:12:34', '2017-11-03 16:18:21'),
(8, 'm.asim', 'asim@mobinspire.com', '$2y$10$3HudEFmgHxN7zpPac.9uCO.WlRB8C1.2KBGTXwVjOcmXz8lGhiPTS', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-07-26 00:41:53', '115.186.130.14', '2017-07-27 23:16:27', '115.186.130.14', '2017-06-13 04:13:44', '2017-07-27 23:16:27'),
(9, 'raheel.altaf', 'raheel@mobinspire.com', '$2y$10$NAP9AdcWL2SL5u5Qix6n0OTF9Jr7I3DEbL2BinwT6aicNgn9niV9m', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-07-25 17:03:32', '115.186.130.14', '2017-11-15 03:10:29', '115.186.130.14', '2017-06-13 04:14:45', '2017-11-15 03:10:29'),
(10, 'abdul.wakeel', 'wakeel@mobinspire.com', '$2y$10$oOOg6BFsfiOPpVBSvmv0xOi.4GOTxaiqGAfJTBQZFyE1FZFlIZVIG', NULL, NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-06-13 04:16:06', '2017-07-12 20:59:38'),
(11, 'maryam.sohail', 'maryam@mobinspire.com', '$2y$10$VdwTCd.2QacOKT9cpdbVQu6drBP83viSlKx7fubVPLKYRKIWQvPdy', '9ENuKOjrIHNidsnoP5PSTrqcdqB2ojRn2UdfFlpHoV23EpDbFVJBxJl8pJf5', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-08-04 22:44:52', '115.186.130.14', '2017-08-22 21:01:54', '115.186.130.14', '2017-06-13 04:17:06', '2017-08-22 21:01:54'),
(12, 'sohail.afzal', 'sohail@mobinspire.com', '$2y$10$5HvJfEDyM7c9GKZbZtWv3uKsb4Nuinh0P8q9XWb2bh1cQdi/Bv8fi', '3RD3xCj0wlonWyRycmzR7KiewjT3AK7KDTFjgApk0kAIdAFGWHJMZu9h16ab', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-06-19 18:52:08', '115.186.130.14', '2017-06-20 21:49:47', '115.186.130.14', '2017-06-13 04:18:24', '2017-07-24 20:09:19'),
(13, 'm.zakir', 'zakir@mobinspire.com', '$2y$10$yf1iYu/YKVGw.WlHtDgg7.ZoGG0wzlD3PBooT4e/xPzrnO1o63W.W', 'ROMWga0CoxeVHEUOMXesvVZ4H9FmBJ9h9sXNRoR3SuFQq95BnrBodMXjYDna', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-07-24 21:29:45', '115.186.130.14', '2017-07-25 17:05:33', '115.186.130.14', '2017-06-13 04:19:58', '2017-07-25 17:05:33'),
(14, 'aamir.khan', 'aamir@mobinspire.com', '$2y$10$9SK7d2V3RvJx8brwhpkIM.cynTyJQ2t5MUflxs8di2WYXNEis2lLm', 'eUk5Il4nTGSlKIMDsarEzlyb3vaeC673J8CORg3PExUV7PlynQJitmcTrwwj', NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, '2017-06-14 23:12:21', '115.186.130.14', '2017-06-19 17:32:42', '115.186.130.14', '2017-06-13 04:23:27', '2017-07-30 17:27:11'),
(15, 'hunan.ali', 'husnan@mobinspire.com', '$2y$10$Cnaa2RQARZXouPxXi8RQOu.gHiEapy80YnEIi.8zDCtZdqqCTu5eK', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-08-24 22:32:09', '115.186.130.14', '2017-10-12 00:42:49', '115.186.130.14', '2017-06-13 04:24:56', '2017-10-12 00:42:49'),
(16, 'usman.saeed', 'usman@mobinspire.com', '$2y$10$DBM6ME1FcUL4gg7ZFDp2duqdHfZX8eJxqmjlrsCOXCGocUFlUpW4i', NULL, NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-06-13 04:25:54', '2017-06-19 19:15:45'),
(17, 'umar.bilal', 'umar@mobinspire.com', '$2y$10$vIGNVqHYvcIp.sl5.C668.1KdEOv23pgvv4/O57pSRcTKek3x0qrS', 'ZKJw5epys4O8c849tPSjtJ7naitlooxWiNoxEj66KWbrJwGKdON8vPsRgbLS', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-07-24 22:03:47', '115.186.130.14', '2017-07-28 17:52:56', '115.186.130.14', '2017-06-13 04:26:58', '2017-07-28 17:52:56'),
(18, 'ovais.ilyas', 'ovais@mobinspire.com', '$2y$10$ob.ZNAp1ZKwmJ7CZkAy91Oj4k.GQxrKslzsNZl9eJ6Xe1UcOe6DXG', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-07-25 00:12:32', '115.186.130.14', '2017-08-22 17:42:39', '115.186.130.14', '2017-06-13 04:30:11', '2017-08-22 17:42:39'),
(19, 'm.faisal', 'faisal@mobinspire.com', '$2y$10$M3XxCSogvN3SHdkyUFMY5.MiAkxes7I.2UdyeqzSE1atd38fCCrYu', 'wcmtCbal3i6dfOvqaCDkhMAjIbbX1O9PHM8G1LaRz68cX0zQ3qks8q66OFIG', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-07-25 16:13:01', '115.186.130.14', '2017-08-24 22:43:59', '115.186.130.14', '2017-06-13 04:31:47', '2017-08-24 22:43:59'),
(20, 'saqib.naveed', 'saqib@mobinspire.com', '$2y$10$iYsbWHJgxmc8Vu6vKqMP/u5a4ive08gmq1TSmcUS8uanj8cnhKJLW', 'oCZ65f7fI8aiRzWBdn9ZHHlEUroGn2nFcx3FrMx1d4FQlMUXfs4nmRzCu5Fm', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-08-28 17:22:39', '115.186.130.14', '2017-10-12 00:27:13', '115.186.130.14', '2017-06-13 04:33:17', '2017-10-12 00:27:13'),
(21, 'usman.aslam', 'm.usman@mobinspire.com', '$2y$10$9tVPI3pVL37DFzATzHHNJ.k1xwumF6Waj0C4n9d6JPwSx8w5zdjTi', NULL, NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-06-13 04:34:42', '2017-09-26 19:02:02'),
(22, 'alitariq', 'ali@mobinspire.com', '$2y$10$rSy5JKlVTg2OgVjTXJSVvuvDuVb/vhiK1WB5JFFursv1Tw6EO6Xaq', 'BmlGquP1N8Q9aicPH3AWtTWWnzFtpF6spogPYpYXb6um5SpQFPaCanSMjcWs', NULL, NULL, 'banned', NULL, NULL, 0, 0, 0, '2017-07-25 00:14:59', '124.109.48.90', '2017-07-31 17:37:15', '124.109.48.90', '2017-06-23 19:50:28', '2017-09-26 18:54:32'),
(23, 'hashir', 'hashir@mobinspire.com', '$2y$10$c6l.GLvKurqWqskYRGg2HeEJ9S5Lepb/5PBfjMmrJ2U5BKfzZzVWO', 'vNPxki5dEEU9uPwEkZX5DqjrxOz7OBHR3T48DBKojnKEZ1lQXykrZRGPLDJ1', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, '2017-08-22 20:57:03', '115.186.130.14', '2017-08-23 16:39:22', '119.159.147.177', '2017-07-11 23:02:40', '2017-08-23 16:39:22'),
(24, 'azam', 'azam@mobinspire.com', '$2y$10$SCgZ8sqFBD5g2jFwc/MSt.2xkOgMB73UszRmqYa3oNzj7eJ1KDCjq', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-07-12 21:55:37', '2017-07-24 19:50:44'),
(25, 'ahmed', 'ahmed@mobinspire.com', '$2y$10$c1szDaAO605xDSjmYzmFReoy9kFAMfWpjazM8Bi91sVkS/mBxsIWO', NULL, NULL, NULL, 'inactive', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-08-01 23:39:18', '2017-09-26 18:59:03'),
(26, 'Anees', 'syedanees@mobinspire.com', '$2y$10$n38CkuyyfHKU5V5xI3ekBOID1bWtHlmhHpMY5jFp5/3mShXTZmVNi', 'jkyzJCLRNH6pwRkDtK4EyYoxTEXUcvzJJQZt576djaIIJ0Si22RAuBr13EFO', NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, '2017-09-26 19:38:59', '115.186.130.14', '2017-08-10 22:15:08', '2017-09-26 19:38:59'),
(27, 'waqas', 'waqas@mobinspire.com', '$2y$10$TU3XDN97/YdpY9twATkiuOv7Rh.hwhBewyaMNjp//CS2SeIQmAABS', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-09-11 19:36:50', '2017-09-11 19:36:50'),
(28, 'hamid', 'hamid@mobinspire.com', '$2y$10$buKqZGhwZtIIRmoKnfnZhO2kzFd7iZiWP/Prwa5Z3ueaNf2imnhjq', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-09-11 21:06:52', '2017-09-11 21:06:52'),
(29, 'mohsin', 'mohsin@mobinspire.com', '$2y$10$9B6D7xSIVKpfevgwJZrZWO2FsIjAJGrXwZeU3HCLTOWw18ski8whC', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-09-11 21:07:52', '2017-09-11 21:07:52'),
(30, 'waqar', 'waqar@mobinspire.com', '$2y$10$21NFQAqyDiEIiUCNSZMuoeZvAiBuZv63k4xzSUqFfdJkzyWb5N5C6', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-09-26 19:04:38', '2017-09-26 19:04:38'),
(31, 'FaisalSiraj', 'faisalsiraj@mobinspire.com', '$2y$10$ljiGpP4eLIFHJvmtF5NLzuVTIzZBf5u58Na68/0EXDEtDRVo.ar5S', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-10-04 21:40:35', '2017-10-04 21:40:35'),
(32, 'Sartaj', 'sartaj@mobinspire.com', '$2y$10$AzzbeQJvniNi99sCmazw0uiaZYGv1.9U7i5TLeMes1ZR/42DHSKty', NULL, NULL, NULL, 'active', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, '2017-10-04 21:41:56', '2017-10-04 21:41:56');

-- --------------------------------------------------------

--
-- Table structure for table `user_bank_accounts`
--

CREATE TABLE IF NOT EXISTS `user_bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `is_primary` int(11) NOT NULL DEFAULT '0',
  `is_locked` int(11) NOT NULL DEFAULT '0',
  `bank_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_number` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_branch` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_contacts`
--

CREATE TABLE IF NOT EXISTS `user_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `is_primary` int(11) NOT NULL DEFAULT '0',
  `is_locked` int(11) NOT NULL DEFAULT '0',
  `is_dependent` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relation` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `work_phone_extension` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `home` varchar(29) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_contacts`
--

INSERT INTO `user_contacts` (`id`, `user_id`, `is_primary`, `is_locked`, `is_dependent`, `name`, `relation`, `work_email`, `personal_email`, `work_phone`, `work_phone_extension`, `mobile`, `home`, `address_line_1`, `address_line_2`, `city`, `state`, `zipcode`, `country_id`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 0, 0, 'self', 'self', 'abdurrehman@mobinspire.com', '', '', '', '03320595977', '', '', '', '', '', '', '', '2017-06-13 03:40:25', '2017-06-13 03:40:25');

-- --------------------------------------------------------

--
-- Table structure for table `user_contracts`
--

CREATE TABLE IF NOT EXISTS `user_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `contract_type_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `contract_type_id` (`contract_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_contracts`
--

INSERT INTO `user_contracts` (`id`, `user_id`, `contract_type_id`, `title`, `from_date`, `to_date`, `description`, `created_at`, `updated_at`) VALUES
(1, 5, 1, '', '2016-08-01', '2017-07-22', '', '2017-07-12 21:03:59', '2017-07-12 21:03:59');

-- --------------------------------------------------------

--
-- Table structure for table `user_designations`
--

CREATE TABLE IF NOT EXISTS `user_designations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `designation_id` (`designation_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Dumping data for table `user_designations`
--

INSERT INTO `user_designations` (`id`, `user_id`, `designation_id`, `from_date`, `to_date`, `description`, `created_at`, `updated_at`) VALUES
(2, 3, 18, '2016-08-01', NULL, NULL, '2017-06-13 03:33:11', '2017-06-13 03:33:11'),
(3, 4, 17, '2016-08-01', NULL, NULL, '2017-06-13 04:08:31', '2017-06-13 04:08:31'),
(4, 5, 2, '2016-08-01', NULL, NULL, '2017-06-13 04:09:53', '2017-06-13 04:09:53'),
(5, 6, 15, '2016-08-01', NULL, NULL, '2017-06-13 04:11:33', '2017-06-13 04:11:33'),
(6, 7, 16, '2016-08-01', NULL, NULL, '2017-06-13 04:12:34', '2017-06-13 04:12:34'),
(7, 8, 5, '2016-08-01', NULL, NULL, '2017-06-13 04:13:44', '2017-06-13 04:13:44'),
(8, 9, 3, '2016-08-01', NULL, NULL, '2017-06-13 04:14:45', '2017-06-13 04:14:45'),
(9, 10, 4, '2016-08-01', '2017-06-08', '', '2017-06-13 04:16:06', '2017-06-15 02:24:25'),
(10, 11, 11, '2016-08-01', NULL, NULL, '2017-06-13 04:17:06', '2017-06-13 04:17:06'),
(11, 12, 4, '2016-08-01', NULL, NULL, '2017-06-13 04:18:24', '2017-06-13 04:18:24'),
(12, 13, 11, '2016-08-01', NULL, NULL, '2017-06-13 04:19:58', '2017-06-13 04:19:58'),
(13, 14, 7, '2016-11-01', NULL, NULL, '2017-06-13 04:23:27', '2017-06-13 04:23:27'),
(14, 15, 9, '2016-11-01', NULL, NULL, '2017-06-13 04:24:56', '2017-06-13 04:24:56'),
(15, 16, 7, '2016-11-07', NULL, NULL, '2017-06-13 04:25:54', '2017-06-13 04:25:54'),
(16, 17, 12, '2016-11-17', NULL, NULL, '2017-06-13 04:26:58', '2017-06-13 04:26:58'),
(17, 18, 4, '2017-02-08', NULL, NULL, '2017-06-13 04:30:11', '2017-06-13 04:30:11'),
(18, 19, 7, '2017-05-03', NULL, NULL, '2017-06-13 04:31:47', '2017-06-13 04:31:47'),
(19, 20, 10, '2017-05-03', NULL, NULL, '2017-06-13 04:33:17', '2017-06-13 04:33:17'),
(20, 21, 9, '2017-05-08', NULL, NULL, '2017-06-13 04:34:42', '2017-06-13 04:34:42'),
(21, 22, 14, '2017-05-08', '2017-09-11', '', '2017-06-23 19:50:28', '2017-09-26 18:59:59'),
(22, 23, 18, '2016-12-01', NULL, NULL, '2017-07-11 23:02:40', '2017-07-11 23:02:40'),
(23, 24, 7, '2017-06-19', NULL, NULL, '2017-07-12 21:55:37', '2017-07-12 21:55:37'),
(24, 25, 13, '2017-08-01', NULL, NULL, '2017-08-01 23:39:18', '2017-08-01 23:39:18'),
(25, 26, 14, '2017-08-10', NULL, NULL, '2017-08-10 22:15:08', '2017-08-10 22:15:08'),
(26, 27, 16, '2017-09-05', NULL, NULL, '2017-09-11 19:36:50', '2017-09-11 19:36:50'),
(27, 28, 10, '2017-09-11', NULL, NULL, '2017-09-11 21:06:52', '2017-09-11 21:06:52'),
(28, 29, 10, '2017-09-11', NULL, NULL, '2017-09-11 21:07:52', '2017-09-11 21:07:52'),
(29, 30, 8, '2017-09-18', NULL, NULL, '2017-09-26 19:04:38', '2017-09-26 19:04:38'),
(30, 31, 16, '2017-10-03', NULL, NULL, '2017-10-04 21:40:35', '2017-10-04 21:40:35'),
(31, 32, 16, '2017-10-03', NULL, NULL, '2017-10-04 21:41:56', '2017-10-04 21:41:56');

-- --------------------------------------------------------

--
-- Table structure for table `user_documents`
--

CREATE TABLE IF NOT EXISTS `user_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `is_locked` int(11) NOT NULL DEFAULT '0',
  `document_type_id` int(11) DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `document_type_id` (`document_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `user_documents`
--

INSERT INTO `user_documents` (`id`, `user_id`, `is_locked`, `document_type_id`, `date_of_expiry`, `title`, `description`, `created_at`, `updated_at`) VALUES
(1, 14, 0, 1, '2018-01-01', 'Contract Aamir', '', '2017-06-13 21:47:14', '2017-06-13 21:47:14'),
(2, 14, 0, 5, '2018-01-01', 'Aamir NDA', '', '2017-06-13 21:47:35', '2017-06-13 21:47:35'),
(3, 14, 0, 4, '2018-01-01', 'Aamir Graduation', '', '2017-06-13 21:49:05', '2017-06-13 21:49:05'),
(4, 14, 0, 2, '2018-01-01', 'Aamir Experience', '', '2017-06-13 21:51:01', '2017-06-13 21:51:01'),
(5, 10, 0, 1, '2017-08-01', 'Contract', '', '2017-06-13 22:15:49', '2017-06-13 22:15:49'),
(6, 10, 0, 5, '2017-08-01', 'NDA wakeel', '', '2017-06-13 22:16:07', '2017-06-13 22:16:07'),
(7, 10, 0, 3, '2018-01-01', 'post', '', '2017-06-13 22:18:41', '2017-06-13 22:18:41'),
(8, 15, 0, 1, '2018-02-08', 'Contract all documents', '', '2017-06-13 22:37:47', '2017-06-13 22:37:47'),
(9, 7, 0, 1, '2017-08-01', 'Bilal all documents', '', '2017-06-13 22:47:06', '2017-06-13 22:47:06'),
(10, 8, 0, 1, '2017-08-01', 'Complete Documents (Asim)', '', '2017-06-13 22:54:29', '2017-06-13 22:54:29'),
(11, 13, 0, 1, '2018-01-03', 'All Documents (Zakir)', '', '2017-06-13 23:03:00', '2017-06-13 23:03:00'),
(12, 6, 0, 1, '2017-09-22', 'Contract (Arslan)', '', '2017-06-13 23:07:58', '2017-06-13 23:07:58'),
(13, 6, 0, 5, '2017-09-22', 'NDA (Arslan)', '', '2017-06-13 23:08:24', '2017-06-13 23:08:24'),
(14, 6, 0, 3, '2017-09-22', 'Post Gra (Arslan)', '', '2017-06-13 23:08:45', '2017-06-13 23:08:45'),
(15, 6, 0, 4, '2017-09-22', 'Grad(Arslan)', '', '2017-06-13 23:09:13', '2017-06-13 23:09:13'),
(16, 11, 0, 1, '2017-09-09', 'All Documents (maryam)', '', '2017-06-13 23:14:53', '2017-06-13 23:14:53'),
(17, 18, 0, 1, '2018-02-02', 'All Documents (Ovais)', '', '2017-06-13 23:22:19', '2017-06-13 23:22:19'),
(18, 9, 0, 1, '2017-10-30', 'All Documents (Raheel)', '', '2017-06-13 23:35:08', '2017-06-13 23:35:08'),
(19, 12, 0, 1, '2017-12-21', 'All Documents (Sohail)', '', '2017-06-13 23:40:36', '2017-06-13 23:40:36'),
(20, 17, 0, 1, '2017-11-17', 'All Documents (Umer)', '', '2017-06-13 23:43:57', '2017-06-13 23:43:57'),
(21, 5, 0, 1, '2017-08-01', 'All Documents (Zaheer)', '', '2017-06-13 23:48:11', '2017-06-13 23:48:11');

-- --------------------------------------------------------

--
-- Table structure for table `user_employments`
--

CREATE TABLE IF NOT EXISTS `user_employments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `date_of_leaving` date DEFAULT NULL,
  `leaving_remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Dumping data for table `user_employments`
--

INSERT INTO `user_employments` (`id`, `user_id`, `date_of_joining`, `date_of_leaving`, `leaving_remarks`, `created_at`, `updated_at`) VALUES
(2, 3, '2016-08-01', NULL, NULL, '2017-06-13 03:33:11', '2017-06-13 03:33:11'),
(3, 4, '2016-08-01', NULL, NULL, '2017-06-13 04:08:31', '2017-06-13 04:08:31'),
(4, 5, '2016-08-01', '2017-07-08', 'Volunteer resgin want to perform some family responsibilities', '2017-06-13 04:09:53', '2017-07-30 17:35:06'),
(5, 6, '2016-08-01', '2017-07-20', 'Had bahviour and i responsibilities isseus multiple times warning given but no improvement.', '2017-06-13 04:11:33', '2017-07-30 17:32:27'),
(6, 7, '2016-08-01', NULL, NULL, '2017-06-13 04:12:34', '2017-06-13 04:12:34'),
(7, 8, '2016-08-01', NULL, NULL, '2017-06-13 04:13:44', '2017-06-13 04:13:44'),
(8, 9, '2016-08-01', NULL, NULL, '2017-06-13 04:14:45', '2017-06-13 04:14:45'),
(9, 10, '2016-08-01', '2017-06-16', '', '2017-06-13 04:16:06', '2017-07-12 20:59:38'),
(10, 11, '2016-08-01', NULL, NULL, '2017-06-13 04:17:06', '2017-06-13 04:17:06'),
(11, 12, '2016-08-01', NULL, NULL, '2017-06-13 04:18:24', '2017-06-13 04:18:24'),
(12, 13, '2016-08-01', NULL, NULL, '2017-06-13 04:19:58', '2017-06-13 04:19:58'),
(13, 14, '2016-11-01', '2017-06-10', 'Want to start home construction', '2017-06-13 04:23:27', '2017-07-30 17:27:11'),
(14, 15, '2016-11-01', NULL, NULL, '2017-06-13 04:24:56', '2017-06-13 04:24:56'),
(15, 16, '2016-11-07', '2017-06-09', 'Voluntary Termination', '2017-06-13 04:25:54', '2017-06-19 19:15:45'),
(16, 17, '2016-11-17', NULL, NULL, '2017-06-13 04:26:58', '2017-06-13 04:26:58'),
(17, 18, '2017-02-08', NULL, NULL, '2017-06-13 04:30:11', '2017-06-13 04:30:11'),
(18, 19, '2017-05-03', NULL, NULL, '2017-06-13 04:31:47', '2017-06-13 04:31:47'),
(19, 20, '2017-05-03', NULL, NULL, '2017-06-13 04:33:17', '2017-06-13 04:33:17'),
(20, 21, '2017-05-08', '2017-08-03', '', '2017-06-13 04:34:42', '2017-09-26 19:02:02'),
(21, 22, '2017-05-08', NULL, NULL, '2017-06-23 19:50:28', '2017-06-23 19:50:28'),
(22, 23, '2016-12-01', NULL, NULL, '2017-07-11 23:02:40', '2017-07-11 23:02:40'),
(23, 24, '2017-06-19', NULL, NULL, '2017-07-12 21:55:37', '2017-07-12 21:55:37'),
(24, 25, '2017-08-01', '2017-08-25', '', '2017-08-01 23:39:18', '2017-09-26 18:59:21'),
(25, 26, '2017-08-10', NULL, NULL, '2017-08-10 22:15:08', '2017-08-10 22:15:08'),
(26, 27, '2017-09-05', NULL, NULL, '2017-09-11 19:36:50', '2017-09-11 19:36:50'),
(27, 28, '2017-09-11', NULL, NULL, '2017-09-11 21:06:52', '2017-09-11 21:06:52'),
(28, 29, '2017-09-11', NULL, NULL, '2017-09-11 21:07:52', '2017-09-11 21:07:52'),
(29, 30, '2017-09-18', NULL, NULL, '2017-09-26 19:04:38', '2017-09-26 19:04:38'),
(30, 31, '2017-10-03', NULL, NULL, '2017-10-04 21:40:35', '2017-10-04 21:40:35'),
(31, 32, '2017-10-03', NULL, NULL, '2017-10-04 21:41:56', '2017-10-04 21:41:56');

-- --------------------------------------------------------

--
-- Table structure for table `user_experiences`
--

CREATE TABLE IF NOT EXISTS `user_experiences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `is_locked` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_contact_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `job_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_experiences`
--

INSERT INTO `user_experiences` (`id`, `user_id`, `is_locked`, `company_name`, `company_address`, `company_contact_number`, `company_website`, `from_date`, `to_date`, `job_title`, `description`, `created_at`, `updated_at`) VALUES
(1, 3, 0, 'Appliconic', 'CLOSED', '03320595977', 'www.appliconic.com', '2012-08-14', '2016-07-31', 'COO', '', '2017-06-13 03:45:10', '2017-06-13 03:45:10'),
(2, 14, 0, 'xFlow Research', '', '', '', '2015-07-27', '2016-10-21', 'Software Design Engineer', '', '2017-06-13 21:54:47', '2017-06-13 21:54:47'),
(3, 15, 0, 'Marba Group', '', '', '', '2016-07-01', '2016-10-28', 'Software Eng', '', '2017-06-13 22:39:45', '2017-06-13 22:39:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_leaves`
--

CREATE TABLE IF NOT EXISTS `user_leaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Dumping data for table `user_leaves`
--

INSERT INTO `user_leaves` (`id`, `user_id`, `from_date`, `to_date`, `description`, `created_at`, `updated_at`) VALUES
(1, 3, '2016-08-01', '2017-08-01', '', '2017-06-13 03:41:59', '2017-06-13 03:41:59'),
(3, 15, '2016-11-01', '2017-11-01', '', '2017-06-15 22:37:32', '2017-06-15 22:37:32'),
(5, 8, '2016-08-01', '2017-08-01', '', '2017-06-15 22:41:57', '2017-06-15 22:41:57'),
(6, 9, '2016-08-01', '2017-08-01', '', '2017-06-19 09:56:33', '2017-06-19 09:56:33'),
(7, 20, '2017-05-01', '2017-07-01', '', '2017-06-19 09:56:53', '2017-06-19 09:56:53'),
(8, 18, '2016-08-01', '2017-08-01', '', '2017-06-19 09:58:12', '2017-06-19 09:58:12'),
(10, 6, '2016-08-01', '2017-08-01', '', '2017-06-19 09:58:50', '2017-06-19 09:58:50'),
(11, 19, '2016-08-01', '2017-08-01', '', '2017-06-19 09:59:07', '2017-06-19 09:59:07'),
(12, 13, '2016-08-01', '2017-08-01', '', '2017-06-19 09:59:30', '2017-06-19 09:59:30'),
(13, 11, '2016-08-01', '2017-08-01', '', '2017-07-12 00:42:42', '2017-07-12 00:42:42'),
(15, 23, '2016-12-01', '2017-12-01', '', '2017-07-25 00:49:58', '2017-07-25 00:49:58'),
(16, 17, '2016-08-17', '2017-08-17', '', '2017-07-25 19:59:22', '2017-07-25 19:59:22'),
(17, 25, '2017-07-31', '2018-08-01', '', '2017-08-04 17:43:56', '2017-08-04 17:43:56'),
(18, 24, '2017-06-19', '2018-06-19', '', '2017-08-04 18:18:45', '2017-08-04 18:18:45'),
(19, 12, '2016-10-03', '2017-10-03', '', '2017-08-04 18:30:24', '2017-08-04 18:30:24'),
(20, 7, '2017-08-01', '2018-08-01', '', '2017-08-16 23:03:16', '2017-08-16 23:03:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_leave_details`
--

CREATE TABLE IF NOT EXISTS `user_leave_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_leave_id` int(11) DEFAULT NULL,
  `leave_type_id` int(11) DEFAULT NULL,
  `leave_assigned` int(11) NOT NULL DEFAULT '0',
  `leave_used` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_leave_id` (`user_leave_id`),
  KEY `leave_type_id` (`leave_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=81 ;

--
-- Dumping data for table `user_leave_details`
--

INSERT INTO `user_leave_details` (`id`, `user_leave_id`, `leave_type_id`, `leave_assigned`, `leave_used`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 4, 0, '2017-06-13 03:41:59', '2017-06-13 03:41:59'),
(2, 1, 2, 4, 0, '2017-06-13 03:41:59', '2017-06-13 03:41:59'),
(3, 1, 3, 4, 0, '2017-06-13 03:41:59', '2017-06-13 03:41:59'),
(4, 1, 4, 4, 1, '2017-06-13 03:41:59', '2017-06-13 06:12:47'),
(9, 3, 1, 7, 0, '2017-06-15 22:37:32', '2017-06-15 22:37:32'),
(10, 3, 2, 3, 0, '2017-06-15 22:37:32', '2017-06-15 22:37:32'),
(11, 3, 3, 12, 0, '2017-06-15 22:37:32', '2017-06-15 22:37:32'),
(12, 3, 4, 0, 0, '2017-06-15 22:37:32', '2017-06-15 22:37:32'),
(17, 5, 1, 7, 0, '2017-06-15 22:41:57', '2017-06-15 22:41:57'),
(18, 5, 2, 1, 0, '2017-06-15 22:41:57', '2017-06-15 22:41:57'),
(19, 5, 3, 12, 0, '2017-06-15 22:41:57', '2017-06-15 22:41:57'),
(20, 5, 4, 0, 0, '2017-06-15 22:41:57', '2017-06-15 22:41:57'),
(21, 6, 1, 0, 0, '2017-06-19 09:56:33', '2017-06-19 09:56:33'),
(22, 6, 2, 0, 0, '2017-06-19 09:56:33', '2017-06-19 09:56:33'),
(23, 6, 3, 0, 0, '2017-06-19 09:56:33', '2017-06-19 09:56:33'),
(24, 6, 4, 0, 0, '2017-06-19 09:56:33', '2017-06-19 09:56:33'),
(25, 7, 1, 0, 0, '2017-06-19 09:56:53', '2017-06-19 09:56:53'),
(26, 7, 2, 0, 0, '2017-06-19 09:56:53', '2017-06-19 09:56:53'),
(27, 7, 3, 0, 0, '2017-06-19 09:56:53', '2017-06-19 09:56:53'),
(28, 7, 4, 0, 0, '2017-06-19 09:56:53', '2017-06-19 09:56:53'),
(29, 8, 1, 0, 0, '2017-06-19 09:58:12', '2017-06-19 09:58:12'),
(30, 8, 2, 0, 0, '2017-06-19 09:58:12', '2017-06-19 09:58:12'),
(31, 8, 3, 0, 0, '2017-06-19 09:58:12', '2017-06-19 09:58:12'),
(32, 8, 4, 0, 0, '2017-06-19 09:58:12', '2017-06-19 09:58:12'),
(37, 10, 1, 0, 0, '2017-06-19 09:58:50', '2017-06-19 09:58:50'),
(38, 10, 2, 0, 0, '2017-06-19 09:58:50', '2017-06-19 09:58:50'),
(39, 10, 3, 0, 0, '2017-06-19 09:58:50', '2017-06-19 09:58:50'),
(40, 10, 4, 0, 0, '2017-06-19 09:58:50', '2017-06-19 09:58:50'),
(41, 11, 1, 0, 0, '2017-06-19 09:59:07', '2017-06-19 09:59:07'),
(42, 11, 2, 0, 0, '2017-06-19 09:59:07', '2017-06-19 09:59:07'),
(43, 11, 3, 0, 0, '2017-06-19 09:59:07', '2017-06-19 09:59:07'),
(44, 11, 4, 0, 0, '2017-06-19 09:59:07', '2017-06-19 09:59:07'),
(45, 12, 1, 0, 0, '2017-06-19 09:59:30', '2017-06-19 09:59:30'),
(46, 12, 2, 0, 0, '2017-06-19 09:59:30', '2017-06-19 09:59:30'),
(47, 12, 3, 0, 0, '2017-06-19 09:59:30', '2017-06-19 09:59:30'),
(48, 12, 4, 0, 0, '2017-06-19 09:59:30', '2017-06-19 09:59:30'),
(49, 13, 1, 1, 0, '2017-07-12 00:42:42', '2017-07-12 00:42:42'),
(50, 13, 2, 3, 0, '2017-07-12 00:42:42', '2017-07-12 00:42:42'),
(51, 13, 3, 12, 0, '2017-07-12 00:42:42', '2017-07-12 00:42:42'),
(52, 13, 4, 6, 0, '2017-07-12 00:42:42', '2017-07-12 00:42:42'),
(57, 15, 1, 6, 0, '2017-07-25 00:49:58', '2017-07-25 00:49:58'),
(58, 15, 2, 4, 0, '2017-07-25 00:49:58', '2017-07-25 00:49:58'),
(59, 15, 3, 12, 0, '2017-07-25 00:49:58', '2017-07-25 00:49:58'),
(60, 15, 4, 12, 0, '2017-07-25 00:49:58', '2017-07-25 00:49:58'),
(61, 16, 1, 7, 0, '2017-07-25 19:59:22', '2017-07-25 19:59:22'),
(62, 16, 2, 1, 0, '2017-07-25 19:59:22', '2017-08-04 18:30:57'),
(63, 16, 3, 12, 0, '2017-07-25 19:59:22', '2017-07-25 19:59:22'),
(64, 16, 4, 12, 0, '2017-07-25 19:59:22', '2017-08-04 18:30:57'),
(65, 17, 1, 7, 0, '2017-08-04 17:43:56', '2017-08-04 17:43:56'),
(66, 17, 2, 6, 0, '2017-08-04 17:43:56', '2017-08-04 17:43:56'),
(67, 17, 3, 12, 0, '2017-08-04 17:43:56', '2017-08-04 17:43:56'),
(68, 17, 4, 12, 0, '2017-08-04 17:43:56', '2017-08-04 17:43:56'),
(69, 18, 1, 7, 0, '2017-08-04 18:18:45', '2017-08-04 18:18:45'),
(70, 18, 2, 6, 0, '2017-08-04 18:18:45', '2017-08-04 18:18:45'),
(71, 18, 3, 12, 0, '2017-08-04 18:18:45', '2017-08-04 18:18:45'),
(72, 18, 4, 12, 0, '2017-08-04 18:18:45', '2017-08-04 18:18:45'),
(73, 19, 1, 4, 0, '2017-08-04 18:30:24', '2017-08-04 18:30:24'),
(74, 19, 2, 1, 0, '2017-08-04 18:30:24', '2017-08-04 18:30:24'),
(75, 19, 3, 12, 0, '2017-08-04 18:30:24', '2017-08-04 18:30:24'),
(76, 19, 4, 12, 0, '2017-08-04 18:30:24', '2017-08-04 18:30:24'),
(77, 20, 1, 7, 0, '2017-08-16 23:03:16', '2017-08-16 23:03:16'),
(78, 20, 2, 6, 0, '2017-08-16 23:03:16', '2017-08-16 23:03:16'),
(79, 20, 3, 12, 0, '2017-08-16 23:03:16', '2017-08-16 23:03:16'),
(80, 20, 4, 22, 0, '2017-08-16 23:03:16', '2017-08-16 23:03:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_locations`
--

CREATE TABLE IF NOT EXISTS `user_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_locations`
--

INSERT INTO `user_locations` (`id`, `user_id`, `location_id`, `from_date`, `to_date`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2016-08-01', '2017-08-01', '', '2017-06-12 20:52:05', '2017-06-12 20:52:05'),
(2, 3, 1, '2016-08-01', '2017-08-01', '', '2017-06-13 03:40:57', '2017-06-13 03:40:57');

-- --------------------------------------------------------

--
-- Table structure for table `user_qualifications`
--

CREATE TABLE IF NOT EXISTS `user_qualifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `is_locked` int(11) NOT NULL DEFAULT '0',
  `institute_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `education_level_id` int(11) DEFAULT NULL,
  `qualification_language_id` int(11) DEFAULT NULL,
  `qualification_skill_id` int(11) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `education_level_id` (`education_level_id`),
  KEY `qualification_language_id` (`qualification_language_id`),
  KEY `qualification_skill_id` (`qualification_skill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_salaries`
--

CREATE TABLE IF NOT EXISTS `user_salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `hourly_rate` decimal(25,0) NOT NULL DEFAULT '0',
  `overtime_hourly_rate` decimal(25,0) NOT NULL DEFAULT '0',
  `late_hourly_rate` decimal(25,0) NOT NULL DEFAULT '0',
  `early_leaving_hourly_rate` decimal(25,0) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `currency_id` (`currency_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_salaries`
--

INSERT INTO `user_salaries` (`id`, `user_id`, `type`, `currency_id`, `from_date`, `to_date`, `hourly_rate`, `overtime_hourly_rate`, `late_hourly_rate`, `early_leaving_hourly_rate`, `description`, `created_at`, `updated_at`) VALUES
(1, 3, 'monthly', 1, '2017-06-01', '2017-08-01', '0', '1500', '1500', '1500', '', '2017-06-13 03:43:20', '2017-06-13 03:43:20');

-- --------------------------------------------------------

--
-- Table structure for table `user_salary_details`
--

CREATE TABLE IF NOT EXISTS `user_salary_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_salary_id` int(11) DEFAULT NULL,
  `salary_head_id` int(11) DEFAULT NULL,
  `amount` decimal(25,5) NOT NULL DEFAULT '0.00000',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_salary_id` (`user_salary_id`),
  KEY `salary_head_id` (`salary_head_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_shifts`
--

CREATE TABLE IF NOT EXISTS `user_shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `shift_id` int(11) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `overnight` int(11) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `shift_id` (`shift_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `user_shifts`
--

INSERT INTO `user_shifts` (`id`, `user_id`, `shift_id`, `from_date`, `to_date`, `in_time`, `out_time`, `overnight`, `description`, `created_at`, `updated_at`) VALUES
(1, 3, 1, '2016-08-01', '2017-08-01', NULL, NULL, 0, '', '2017-06-13 03:41:30', '2017-06-13 03:41:30'),
(2, 14, 1, '2017-01-02', '2018-01-02', NULL, NULL, 0, '', '2017-06-13 21:37:19', '2017-06-13 21:37:19'),
(3, 7, 1, '2016-08-01', '2017-08-01', NULL, NULL, 0, '', '2017-06-13 22:48:11', '2017-06-13 22:48:11'),
(4, 8, 1, '2016-08-01', '2017-08-01', NULL, NULL, 0, '', '2017-06-13 22:56:40', '2017-06-13 22:56:40'),
(5, 13, 1, '2017-01-03', '2018-01-01', NULL, NULL, 0, '', '2017-06-13 23:00:02', '2017-06-13 23:00:02'),
(6, 6, 1, '2016-09-22', '2017-09-22', NULL, NULL, 0, '', '2017-06-13 23:05:53', '2017-06-13 23:05:53'),
(7, 11, 1, '2016-09-09', '2017-09-09', NULL, NULL, 0, '', '2017-06-13 23:14:01', '2017-06-13 23:14:01'),
(8, 18, 1, '2017-02-08', '2018-02-02', NULL, NULL, 0, '', '2017-06-13 23:21:46', '2017-06-13 23:21:46'),
(9, 9, 1, '2016-10-30', '2017-10-30', NULL, NULL, 0, '', '2017-06-13 23:34:37', '2017-06-13 23:34:37'),
(10, 12, 1, '2016-12-21', '2017-12-21', NULL, NULL, 0, '', '2017-06-13 23:40:02', '2017-06-13 23:40:02'),
(11, 17, 1, '2016-11-17', '2017-11-17', NULL, NULL, 0, '', '2017-06-13 23:43:25', '2017-06-13 23:43:25'),
(12, 5, 1, '2016-08-01', '2017-08-01', NULL, NULL, 0, '', '2017-06-13 23:47:41', '2017-06-13 23:47:41');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activities_login_as_user_id_foreign` FOREIGN KEY (`login_as_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `announcement_designation`
--
ALTER TABLE `announcement_designation`
  ADD CONSTRAINT `announcement_designation_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `announcement_designation_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `announcement_user`
--
ALTER TABLE `announcement_user`
  ADD CONSTRAINT `announcement_user_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `announcement_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `awards`
--
ALTER TABLE `awards`
  ADD CONSTRAINT `awards_award_category_id_foreign` FOREIGN KEY (`award_category_id`) REFERENCES `award_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `awards_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `award_user`
--
ALTER TABLE `award_user`
  ADD CONSTRAINT `award_user_award_id_foreign` FOREIGN KEY (`award_id`) REFERENCES `awards` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `award_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bulk_uploads`
--
ALTER TABLE `bulk_uploads`
  ADD CONSTRAINT `bulk_uploads_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `chat_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `clocks`
--
ALTER TABLE `clocks`
  ADD CONSTRAINT `clocks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD CONSTRAINT `custom_field_values_custom_field_id_foreign` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `daily_reports`
--
ALTER TABLE `daily_reports`
  ADD CONSTRAINT `daily_reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `designations`
--
ALTER TABLE `designations`
  ADD CONSTRAINT `designations_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `designations_top_designation_id_foreign` FOREIGN KEY (`top_designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `expenses_expense_head_id_foreign` FOREIGN KEY (`expense_head_id`) REFERENCES `expense_heads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `expenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `expense_status_details`
--
ALTER TABLE `expense_status_details`
  ADD CONSTRAINT `esd_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `esd_expense_id_foreign` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_contract_type_id_foreign` FOREIGN KEY (`contract_type_id`) REFERENCES `contract_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leaves`
--
ALTER TABLE `leaves`
  ADD CONSTRAINT `leaves_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `leaves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `leave_status_details`
--
ALTER TABLE `leave_status_details`
  ADD CONSTRAINT `lsd_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `lsd_leave_id_foreign` FOREIGN KEY (`leave_id`) REFERENCES `leaves` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `locations`
--
ALTER TABLE `locations`
  ADD CONSTRAINT `locations_top_location_id_foreign` FOREIGN KEY (`top_location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_from_user_id_foreign` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messages_reply_id_foreign` FOREIGN KEY (`reply_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `messages_to_user_id_foreign` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payrolls`
--
ALTER TABLE `payrolls`
  ADD CONSTRAINT `payrolls_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payrolls_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payroll_details`
--
ALTER TABLE `payroll_details`
  ADD CONSTRAINT `payroll_details_payroll_id_foreign` FOREIGN KEY (`payroll_id`) REFERENCES `payrolls` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payroll_details_salary_head_id_foreign` FOREIGN KEY (`salary_head_id`) REFERENCES `salary_heads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `profiles_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `shift_details`
--
ALTER TABLE `shift_details`
  ADD CONSTRAINT `shift_details_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `starred_tasks`
--
ALTER TABLE `starred_tasks`
  ADD CONSTRAINT `starred_tasks_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `starred_tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sub_tasks`
--
ALTER TABLE `sub_tasks`
  ADD CONSTRAINT `sub_tasks_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sub_tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sub_task_ratings`
--
ALTER TABLE `sub_task_ratings`
  ADD CONSTRAINT `sub_task_ratings_sub_task_id_foreign` FOREIGN KEY (`sub_task_id`) REFERENCES `sub_tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `sub_task_ratings_sub_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `task_task_priority_id_foreign` FOREIGN KEY (`task_priority_id`) REFERENCES `task_priorities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tasks_task_category_id_foreign` FOREIGN KEY (`task_category_id`) REFERENCES `task_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tasks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_attachments`
--
ALTER TABLE `task_attachments`
  ADD CONSTRAINT `task_attachments_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `task_attachments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_comments`
--
ALTER TABLE `task_comments`
  ADD CONSTRAINT `task_comments_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `task_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_notes`
--
ALTER TABLE `task_notes`
  ADD CONSTRAINT `task_notes_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `task_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_signoff_requests`
--
ALTER TABLE `task_signoff_requests`
  ADD CONSTRAINT `task_signoff_requests_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `task_signoff_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_user`
--
ALTER TABLE `task_user`
  ADD CONSTRAINT `task_user_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `task_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ticket_category_id_foreign` FOREIGN KEY (`ticket_category_id`) REFERENCES `ticket_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tickets_ticket_priority_id_foreign` FOREIGN KEY (`ticket_priority_id`) REFERENCES `ticket_priorities` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ticket_replies`
--
ALTER TABLE `ticket_replies`
  ADD CONSTRAINT `ticket_replies_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ticket_replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `todos`
--
ALTER TABLE `todos`
  ADD CONSTRAINT `todos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `uploads`
--
ALTER TABLE `uploads`
  ADD CONSTRAINT `uploads_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_bank_accounts`
--
ALTER TABLE `user_bank_accounts`
  ADD CONSTRAINT `user_bank_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_contacts`
--
ALTER TABLE `user_contacts`
  ADD CONSTRAINT `user_contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_contracts`
--
ALTER TABLE `user_contracts`
  ADD CONSTRAINT `user_contracts_contract_type_id_foreign` FOREIGN KEY (`contract_type_id`) REFERENCES `contract_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_contracts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_designations`
--
ALTER TABLE `user_designations`
  ADD CONSTRAINT `user_designations_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_designations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_documents`
--
ALTER TABLE `user_documents`
  ADD CONSTRAINT `user_documents_document_type_id_foreign` FOREIGN KEY (`document_type_id`) REFERENCES `document_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_documents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_employments`
--
ALTER TABLE `user_employments`
  ADD CONSTRAINT `user_employments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_experiences`
--
ALTER TABLE `user_experiences`
  ADD CONSTRAINT `user_experiences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_leaves`
--
ALTER TABLE `user_leaves`
  ADD CONSTRAINT `user_leaves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_leave_details`
--
ALTER TABLE `user_leave_details`
  ADD CONSTRAINT `user_leave_details_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_leave_details_user_leave_id_foreign` FOREIGN KEY (`user_leave_id`) REFERENCES `user_leaves` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_locations`
--
ALTER TABLE `user_locations`
  ADD CONSTRAINT `user_locations_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_locations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_qualifications`
--
ALTER TABLE `user_qualifications`
  ADD CONSTRAINT `user_qualifications_education_level_id_foreign` FOREIGN KEY (`education_level_id`) REFERENCES `education_levels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_qualifications_qualification_language_id_foreign` FOREIGN KEY (`qualification_language_id`) REFERENCES `qualification_languages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_qualifications_qualification_skill_id_foreign` FOREIGN KEY (`qualification_skill_id`) REFERENCES `qualification_skills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_qualifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_salaries`
--
ALTER TABLE `user_salaries`
  ADD CONSTRAINT `user_salaries_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_salaries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_salary_details`
--
ALTER TABLE `user_salary_details`
  ADD CONSTRAINT `user_salary_details_salary_head_id_foreign` FOREIGN KEY (`salary_head_id`) REFERENCES `salary_heads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_salary_details_user_salary_id_foreign` FOREIGN KEY (`user_salary_id`) REFERENCES `user_salaries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_shifts`
--
ALTER TABLE `user_shifts`
  ADD CONSTRAINT `user_shifts_shift_id_foreign` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_shifts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
