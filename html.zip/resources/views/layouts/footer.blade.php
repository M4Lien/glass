
                <footer>
					@include('global.credit')
				</footer>