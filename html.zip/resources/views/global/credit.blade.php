
		<p class="text-center" style="margin-top: -50px;">&copy; <a href="{!! URL::to('/') !!}">{!! config('config.application_name') !!} {!! env('VERSION') !!}</a> {!! config('config.credit') !!}</p>