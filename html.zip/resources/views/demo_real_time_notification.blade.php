@extends('layouts.app')

	@section('breadcrumb')
		<ul class="breadcrumb">
		    <li><a href="/home">{!! trans('messages.home') !!}</a></li>
		</ul>
	@stop

	@section('content')
		<div class="row">
			<div class="col-md-12">
				<div class="box-info">
					

					<a href="#" data-source="/generate-real-time-notification" data-ajax="1" class="btn btn-primary"> Send Notification </a>
				</div>
			</div>
		</div>
	@stop