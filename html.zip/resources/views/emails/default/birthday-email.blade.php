<table align="center" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td valign="top">			
				<table align="center" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td height="90" width="600" align="right">
								<p>[COMPANY_LOGO]</p>
								<p style="text-align:left;font-size:16px;"><b>Happy Birthday</b></p>
							</td>
						</tr><tr><td style="background-color:#f5f5f5;border:1px solid #e0e0e0;font-family:Helvetica, Arial, sans-serif;" valign="top" width="600">						
								<table align="center"><tbody><tr><td height="10" width="560">&nbsp;</td>
										</tr><tr><td width="560">
												<p>Dear [NAME],</p><p>We wish you a Very Happy Birthday.</p><p>Have a Good Day!!</p>
											</td>
										</tr><tr><td height="10" width="560"></td>
										</tr></tbody></table></td>
						</tr><tr><td height="10" width="600">&nbsp;</td></tr><tr><td align="right">
								<span style="font-size:12px;color:#999999;font-family:Helvetica, Arial, sans-serif;">[COMPANY_NAME] <br>
								[COMPANY_EMAIL] <br>
								[COMPANY_PHONE] <br>
								[COMPANY_WEBSITE] <br></span>
							</td>
						</tr></tbody></table></td>
		</tr></tbody></table>