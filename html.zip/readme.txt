To install the application visit Installation Guide at http://support.wmlab.in/support/solutions/folders/17000098173

The documentation is available online & it is available at http://support.wmlab.in

Please note that support is available only to the client who have purchased the application from Code Canyon & have a valid purchase code It is also valid for a valid support period. Initially 6 month support is included when you purchase the application. You can always renew your support.

Item support includes:
-------------------------------------------------------
Availability of the author to answer questions
Answering technical questions about item�s features
Assistance with reported bugs and issues
Help with included 3rd party assets

However, item support does not include:
-------------------------------------------------------
Customization services
Installation services

You cannot upgrade to Version 3.2 from lower version. Read more at http://support.wmlab.in/solution/articles/17000048082-no-upgrade-to-version-3-2
You can only install a fresh version of 3.2 in your system. For which you need to release license from your previous installation.

IF YOU HAVE PURCHASING REGULAR LICENSE, THEN PLEASE NOTE THAT YOU WILL BE ABLE TO INSTALL THE APPLICATION ONLY AT ONE LOCATION AT A TIME. IF YOU WANT TO MOVE IT TO ANY OTHER LOCATION, YOU CAN RELEASE LICENSE FROM EXISTING LOCATION AND THEN INSTALL IT ON ANY OTHER LOCATION. 

PLEASE NOTE THAT IF YOU DELETE YOUR FILES AND DATABASE IT DOESN'T MEAN THAT YOU ARE UNINSTALLING THIS SCRIPT. YOU NEED TO CLICK ON THE RELEASE LICENSE LINK AVAILABLE IN THE HEADER MENU JUST ABOVE THE CHANGE PASSWORD LINK TO THE ADMIN USER. IF YOU FORGET TO RELEASE LICENSE AND DELETE YOUR FILES, WMLAB WILL NOT BE RESPONSIBLE FOR FURTHER SUPPORT.

ANYTIME IF IT IS FOUND THAT YOU ARE VIOLATING LICENSE TERMS AND CONDITIONS, YOUR SUPPORT AND YOUR PURCHASE CODE WILL BE BLOCKED IMMEDIATELY. FOR DETAILS VISIT LICENSE USAGE TERMS.

All rights reserved to WMLab www.wmlab.in