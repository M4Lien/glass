# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20190120041130) do

  create_table "chats", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer  "offer_id"
    t.integer  "user_id"
    t.string   "content",                             null: false
    t.boolean  "user_notification",    default: true, null: false
    t.boolean  "company_notification", default: true, null: false
    t.integer  "company_id",                          null: false
    t.datetime "created_at",                          null: false
    t.datetime "updated_at",                          null: false
    t.index ["offer_id"], name: "index_chats_on_offer_id", using: :btree
    t.index ["user_id"], name: "index_chats_on_user_id", using: :btree
  end

  create_table "comments", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "content",    null: false
    t.integer  "chat_id"
    t.string   "name",       null: false
    t.boolean  "company",    null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["chat_id"], name: "index_comments_on_chat_id", using: :btree
  end

  create_table "companies", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "name",                null: false
    t.string   "email",               null: false
    t.string   "password_digest",     null: false
    t.string   "company_image",       null: false
    t.string   "office_prefecture",   null: false
    t.string   "office_address",      null: false
    t.integer  "number_of_employees", null: false
    t.integer  "established_year",    null: false
    t.string   "representative"
    t.string   "information"
    t.string   "amount_of_sales"
    t.string   "suppliers"
    t.string   "homepage"
    t.string   "performance"
    t.string   "phone_number"
    t.datetime "created_at",          null: false
    t.datetime "updated_at",          null: false
    t.string   "customer"
  end

  create_table "offer_offertags", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer  "offer_id"
    t.integer  "offer_tag_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.index ["offer_id"], name: "index_offer_offertags_on_offer_id", using: :btree
    t.index ["offer_tag_id"], name: "index_offer_offertags_on_offer_tag_id", using: :btree
  end

  create_table "offer_tags", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "title",      null: false
    t.integer  "offer_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["offer_id"], name: "index_offer_tags_on_offer_id", using: :btree
  end

  create_table "offers", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer  "company_id"
    t.string   "title",             null: false
    t.string   "offer_image",       null: false
    t.string   "content",           null: false
    t.string   "job",               null: false
    t.string   "holiday",           null: false
    t.string   "treatment",         null: false
    t.string   "office_hours",      null: false
    t.string   "work_location",     null: false
    t.string   "access",            null: false
    t.string   "employment_status", null: false
    t.string   "feature"
    t.string   "qualification"
    t.integer  "allowance_lowest",  null: false
    t.integer  "allowance_highest", null: false
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.string   "game_title",        null: false
    t.index ["company_id"], name: "index_offers_on_company_id", using: :btree
  end

  create_table "users", force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string   "email",               null: false
    t.string   "password_digest",     null: false
    t.string   "last_name",           null: false
    t.string   "first_name",          null: false
    t.string   "phonetic_last_name",  null: false
    t.string   "phonetic_first_name", null: false
    t.string   "sex",                 null: false
    t.string   "prefectures"
    t.string   "address"
    t.string   "street_address"
    t.string   "building_name"
    t.string   "career"
    t.string   "score"
    t.string   "self_introduction"
    t.integer  "birth_year",          null: false
    t.integer  "birth_month",         null: false
    t.integer  "birth_day",           null: false
    t.integer  "phone_number"
    t.integer  "default"
    t.integer  "postal_code"
    t.datetime "created_at",          null: false
    t.datetime "updated_at",          null: false
    t.string   "name"
  end

  add_foreign_key "chats", "offers"
  add_foreign_key "chats", "users"
  add_foreign_key "comments", "chats"
  add_foreign_key "offer_offertags", "offer_tags"
  add_foreign_key "offer_offertags", "offers"
  add_foreign_key "offer_tags", "offers"
  add_foreign_key "offers", "companies"
end
