# # 19
# Offer.seed do |s|
#   s.company_id = Company.find_by(name: "amazon").id
#   s.title = 'amazonの募集　タグ持ち'
#   s.offer_image = 'amazon'
#   s.content = '新規募集の内容 僕アマゾン テスト用にたくさんのタグを持たせます'
#   s.job = '正規職員'
#   s.holiday = '777'
#   s.treatment = '福利厚生内容'
#   s.office_hours = '8時間くらい'
#   s.work_location = '東京都２３区のどこか'
#   s.access = '御茶ノ水駅より徒歩４分'
#   s.employment_status = '正規社員'
#   s.feature = '特徴は特になし'
#   s.qualification = '資格は特に必要なし'
#   s.allowance_lowest = 10
#   s.allowance_highest = 20
# end
# # 20
# Offer.seed do |s|
#   s.company_id = Company.find_by(name: "google").id
#   s.title = 'googleの社員募集　タグもち'
#   s.offer_image = 'aaa'
#   s.content = 'googleをおおおおお募集してますううううう'
#   s.job = '正規職員'
#   s.holiday = '完全週休２日制'
#   s.treatment = '福利厚生バッチリです'
#   s.office_hours = '６時間'
#   s.work_location = '愛知県トヨタし'
#   s.access = '御茶ノ水駅より徒歩４分'
#   s.employment_status = '正規社員'
#   s.feature = '福利厚生しっかりしています。また、社員もしっかりしています。'
#   s.qualification = '大卒以上'
#   s.allowance_lowest = 25
#   s.allowance_highest = 30
# end
# # 21
# Offer.seed do |s|
#   s.company_id = Company.find_by(name: "dentu").id
#   s.title = '電通の社員を募集してますう　タグもち'
#   s.offer_image = 'aaa'
#   s.content = '電通'
#   s.job = 'アルバイト'
#   s.holiday = '週休１日以上'
#   s.treatment = 'なし'
#   s.office_hours = '１０時間'
#   s.work_location = '東京都お台場'
#   s.access = '車で１０分'
#   s.employment_status = '正規社員'
#   s.feature = '特徴は特になし'
#   s.qualification = '資格は特に必要なし'
#   s.allowance_lowest = 5
#   s.allowance_highest = 10
# end
# # 22
# Offer.seed do |s|
#   s.company_id = Company.find_by(name: "nissan").id
#   s.title = '日産の職員を募集してますぅ　タグもち'
#   s.offer_image = 'aaa'
#   s.content = '新規職員大募集中です！　nissanの職員を募集しております。'
#   s.job = 'バイト'
#   s.holiday = '777'
#   s.treatment = '福利厚生内容'
#   s.office_hours = '６時間'
#   s.work_location = 'アメリカ'
#   s.access = 'ロサンゼルス付近'
#   s.employment_status = '正規社員'
#   s.feature = '特徴は特になし'
#   s.qualification = '資格は特に必要なし'
#   s.allowance_lowest = 7
#   s.allowance_highest = 10
# end
