# Offer.create!(title: "テスト??",offer_image: "aaa",content: "新規募集の内容",job: "正規職員",
# holiday: "777",treatment: "福利厚生内容",office_hours: "8時間くらい",work_location: "東京都２３区のどこか",access: "御茶ノ水駅より徒歩４分",
# employment_status: "正規社員",feature: "特徴は特になし",qualification: "資格は特に必要なし",allowance_lowest: 10,allowance_highest: 20,)

# 5.times do |no|
#   User.create!(
#     email: "sample#{no}@yahoo.co.jp",
#     password: "sample#{no}",
#     last_name: "サンプル",
#     first_name: "#{no}郎",
#     phonetic_last_name: "サンプル",
#     phonetic_first_name: "#{no}ロウ",
#     sex: "男",
#     prefectures: "愛知県",
#     address: "稲沢市木全町",
#     street_address: "庄前585-2",
#     birth_year: 1997,
#     birth_month: 9,
#     birth_day: 10,
#     )
# end

# company_arr = ["dentu","hakuhodo","nissan","amazon","google"]
# for var in company_arr do
#   Company.create!(
#     name: var,
#     email: "#{var}@yahoo.co.jp",
#     password: "company",
#     company_image: "#{var}_image",
#     office_prefecture: "#{var}県",
#     office_address: "#{var}市",
#     number_of_employees: 100,
#     established_year: 1997
#     )
# end

# OfferTag.create!(title: "未経験者歓迎")
# OfferTag.create!(title: "充実の福利厚生")
# OfferTag.create!(title: "昇給あり")
# OfferTag.create!(title: "国籍不問")

# OfferTag.create!(title: "実力主義")
# OfferTag.create!(title: "気軽に相談OK")
# OfferTag.create!(title: "経験者優遇")

