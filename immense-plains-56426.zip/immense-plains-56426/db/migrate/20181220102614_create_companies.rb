class CreateCompanies < ActiveRecord::Migration[5.0]
  def change
    create_table :companies do |t|
      t.string :name, :null => false
      t.string :email, :null => false
      t.string :password_digest, :null => false
      
      t.string :company_image, :null => false
      t.string :office_prefecture, :null => false
      t.string :office_address, :null => false
      t.string :company_image, :null => false
      t.string :office_prefecture, :null => false
      t.string :office_address, :null => false
      
      t.integer :number_of_employees, :null => false
      t.integer :established_year, :null => false
      
      t.string :representative
      t.string :information
      t.string :amount_of_sales
      t.string :suppliers
      t.string :homepage
      t.string :performance
      t.string :phone_number

      t.timestamps
    end
  end
end
