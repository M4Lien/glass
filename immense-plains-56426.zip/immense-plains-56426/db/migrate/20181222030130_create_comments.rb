class CreateComments < ActiveRecord::Migration[5.0]
  def change
    create_table :comments do |t|
      t.string :content
      t.references :chat, foreign_key: true
      
      t.string :name, :null => false
      t.string :content, :null => false
      
      t.boolean :company, :null => false

      t.timestamps
    end
  end
end
