class AddCustomer < ActiveRecord::Migration[5.0]
  def up
    add_column :companies, :customer, :string
  end
  def down
    remove_column :companies, :customer, :string
  end
end
