class AddGameTileColumn < ActiveRecord::Migration[5.0]
  def up
    add_column :offers, :game_title, :string, :null => false
  end
  def down
    remove_column :offers, :game_title, :string, :null => false
  end
end
