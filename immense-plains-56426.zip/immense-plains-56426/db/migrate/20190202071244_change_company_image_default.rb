class ChangeCompanyImageDefault < ActiveRecord::Migration[5.0]
  
  def up
    change_column_null :companies, :company_image, true
    change_column_null :companies, :number_of_employees, true
    change_column_null :companies, :established_year, true
  end
  
  def down
    change_column_null :companies, :company_image, false
    change_column_null :companies, :number_of_employees, false
    change_column_null :companies, :established_year, false
  end
  
end
