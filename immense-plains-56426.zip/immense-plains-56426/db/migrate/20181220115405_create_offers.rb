class CreateOffers < ActiveRecord::Migration[5.0]
  def change
    create_table :offers do |t|
      t.references :company, foreign_key: true
      
      t.string :title, :null => false
      t.string :offer_image, :null => false
      t.string :content, :null => false
      t.string :job, :null => false
      t.string :holiday, :null => false
      t.string :treatment, :null => false
      t.string :office_hours, :null => false
      t.string :work_location, :null => false
      t.string :access, :null => false
      t.string :employment_status, :null => false
      
      t.string :feature
      t.string :qualification

      t.integer :allowance_lowest, :null => false
      t.integer :allowance_highest, :null => false
      
      t.timestamps
    end
  end
end
