class CreateUsers < ActiveRecord::Migration[5.0]
  def change
    create_table :users do |t|
      # t.string :name
      t.string :email, :null => false
      t.string :password_digest, :null => false
      
      t.string :last_name, :null => false
      t.string :first_name, :null => false
      t.string :phonetic_last_name, :null => false
      t.string :phonetic_first_name, :null => false
      t.string :sex, :null => false
      
      t.string :prefectures
      t.string :address
      t.string :street_address
      t.string :building_name
      t.string :career
      t.string :score 
      t.string :self_introduction
      
      t.integer :birth_year, :null => false
      t.integer :birth_month, :null => false
      t.integer :birth_day, :null => false

      t.integer :phone_number, :default
      t.integer :postal_code
      
      t.timestamps
    end
  end
end
