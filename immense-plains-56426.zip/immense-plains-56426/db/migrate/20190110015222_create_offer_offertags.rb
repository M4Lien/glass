class CreateOfferOffertags < ActiveRecord::Migration[5.0]
  def change
    create_table :offer_offertags do |t|
      t.references :offer,  index: true, foreign_key: true
      t.references :offer_tag,  index: true, foreign_key: true

      t.timestamps
    end
  end
end
