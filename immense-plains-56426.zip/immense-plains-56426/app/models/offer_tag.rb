class OfferTag < ApplicationRecord
  has_many :offer_offertags
  has_many :offers, through: :offer_offertags
  # has_many :offers
end
