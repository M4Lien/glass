class Offer < ApplicationRecord
  belongs_to :company
  # has_many :offer_tags, :dependent => :destroy
  has_many :chats, :dependent => :destroy
  
  
  enum test: { foo: 1, bar: 2, piyo: 3 }
  
  has_many :offer_offertags,:dependent => :destroy
  has_many :offer_tags, through: :offer_offertags
  
  mount_uploader :offer_image, OfferImageUploader#ここではImageuploader
    
end
