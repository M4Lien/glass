class OfferOffertag < ApplicationRecord
  belongs_to :offer
  belongs_to :offer_tag
end
