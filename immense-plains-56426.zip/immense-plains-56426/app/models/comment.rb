class Comment < ApplicationRecord
  belongs_to :chat
end
