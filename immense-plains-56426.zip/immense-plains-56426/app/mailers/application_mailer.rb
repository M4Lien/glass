class ApplicationMailer < ActionMailer::Base
  default from: 'blair1230jp@gmail.com'
  layout 'mailer'
end
