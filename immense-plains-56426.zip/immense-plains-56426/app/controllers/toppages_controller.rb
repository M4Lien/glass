class ToppagesController < ApplicationController
  before_action :get_notification, only:[:index]
  # before_action :already_read, only:[:show]
  def index
    # @offers = Offer.all
    
    @search = Offer.ransack(params[:q])
    # 検索結果
    # @offers = @search.result
    @offers = @search.result.includes(:offer_tags)
    @offer_tags = OfferTag.all

    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
    # null省きたい
    @game_titles = Offer.all.pluck(:game_title).reject(&:blank?)
    
    @pickup_offers = Offer.all.order('created_at DESC').limit(6)
  end
  
  def form
  end
  
  def terms_of_service
  end
  
end
