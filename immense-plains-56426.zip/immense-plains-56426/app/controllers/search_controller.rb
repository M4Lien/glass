class SearchController < ApplicationController
  def prefecture
    @search = Offer.ransack(params[:q])
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
  end
  
  def menu1
    @search = Offer.ransack(params[:q])
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
  end
  
  def menu2
    @search = Offer.ransack(params[:q])
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
  end
  
  def menu3
    @search = Offer.ransack(params[:q])
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
  end
  
  def menu5
    @search = Offer.ransack(params[:q])
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
  end
  
end
