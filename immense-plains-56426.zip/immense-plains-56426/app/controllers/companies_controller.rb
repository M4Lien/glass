class CompaniesController < ApplicationController
  before_action :require_the_company,only:[:edit,:update,:profile_edit,:chat]
  
  def index
    @companies = Company.all.page(params[:page])
  end

  def show
    @company = Company.find(params[:id])
    
    @offers = @company.offers
    
    if current_company.present?
      @chats = Chat.where(company_id: current_company.id)
    end
    
  end

  def new
    @company = Company.new
  end

  def create
    @company = Company.new(company_params)
        
    if @company.save
      flash[:success] = 'ユーザを登録しました。'
      redirect_to company_login_path
    else
      flash.now[:danger] = 'ユーザの登録に失敗しました。'
      render :new
    end
  end
  
  def edit
    @company = current_company
  end
  
  def update
    @company = Company.find(params[:id])
    if @company.update_attributes(company_params)
      flash[:success] = '編集を保存しました。'
      redirect_to @company
    else
      flash.now[:danger] = '編集の保存に失敗しました。'
      redirect_to :back
    end
  end
  
  def offer
    @company = Company.find(params[:id])
    @offers = @company.offers.page(params[:page]).per(4)
  end
  
  def chat
    @company = Company.find(params[:id])
    @offers = @company.offers
  end
  
  def profile_edit
    @company = Company.find(params[:id])
  end
  
  private
  
  def company_params
    params.require(:company).permit(:name, :email, :password, :password_confirmation,:company_image,:office_prefecture,:office_address,:number_of_employees,:established_year,:information,:performance,:representative,:amount_of_sales)
  end
end
