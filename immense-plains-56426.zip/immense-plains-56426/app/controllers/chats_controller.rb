class ChatsController < ApplicationController
before_action :already_read, only:[:show]
before_action :chat_related, only:[:show,:adopt]
before_action :get_notification
  
  def index
    @company = current_company
    @chats = @company.offers.chat.all
    
  end
  
  def chat_related
    @chat = Chat.find(params[:id])
    if current_user.present? || current_company.present?
      if current_user == @chat.user
      elsif current_company == Company.find(@chat.company_id)
      else
        flash[:danger] = '表示できません'
        redirect_to root_path
      end
    else
      flash[:danger] = '表示できません'
      redirect_to root_path
    end
    
  end
  
  def create
    # offer id と　user id が必要
    @offer = Offer.find(params[:id])
    @chat = @offer.chats.new(content: "#{@offer.company.name}",offer_id: @offer.id, user_id: current_user.id,company_id: @offer.company.id)
    if @chat.save
      flash[:success] = '申し込みに成功しました。メッセージを送信しましょう'
      # @chat..offer.company.(notificationカラム)　= true　にしておく
      # company.saveもひつよう？
      redirect_to @chat
    else
      flash.now[:danger] = '申し込みに失敗しました。'
      redirect_to root_path
    end
  end
  
  def show
    @chat = Chat.find(params[:id])
    @company = Company.find(@chat.company_id)
    @comments = @chat.comments.all.order('created_at DESC')
    @comment = @chat.comments.new
    @user = @chat.user
  end
  
  def adopt
    Payjp.api_key = 'sk_live_37555f2914b499f1791c23c0e4bd6e1461620ce6ad391a7cc7b3a3e0'
    # どういうわけだか Customer.create か　Charge.createの　どちらか一方しか実行できない
    
      if current_company.customer.present?
      	Payjp::Charge.create(
          		:amount => 100000,
         		:currency => 'jpy',
          		:customer => current_company.customer,
      	)
      	flash[:success] = '採用が完了しました'
      	redirect_to :back
    	else
      	customer = Payjp::Customer.create(
      	  :card  => params['payjp-token']
      	)
      	current_company.customer =  customer.id
      	current_company.save
      	charge = Payjp::Charge.create(
      	  :amount => 100000,
      	  :card => params['payjp-token'], 
      	  :currency => 'jpy',
      	)
      	flash[:success] = '採用が完了しました'
      	redirect_to :back
    	end
    rescue => e
    redirect_to root_path
  end
  
  def send_comment
    # @comment = Comment.new
    @chat = Chat.find(params[:id])
    @comment = @chat.comments.new(content: params[:comment][:content])
    if current_company.present?
      # @chat.attributes = {user_notification: true,
      #   comments_attributes: [{content: params[:comment][:content]}]
      # }
      @comment.name = current_company.name
      @comment.company = true 
      @chat.attributes = {user_notification: true}
      @chat.save
    elsif current_user.present? then
      @chat.attributes = {company_notification: true}
      @comment.name = current_user.last_name + current_user.first_name
      @comment.company = false
      @chat.save
    else
    end
    redirect_to @chat
  end
  
  def already_read
    @chat = Chat.find(params[:id])
    
    if current_user.present?
      @chat.attributes = {user_notification: false}
      @chat.save
    elsif current_company.present? then
      @chat.attributes = {company_notification: false}
      @chat.save
    else
    end
    
    @chat.save
    
  end
  
  def update
  end  
end
