class UsersController < ApplicationController
  # before_action :require_user_logged_in, only: [:index, :show]
  before_action :company_or_the_person, only:[:show]
  before_action :require_the_user,only:[:show,:edit,:profile_edit,:update]
  
  def index
    @users = User.all.page(params[:page])
  end

  def show
    @user = User.find(params[:id])
    
    if current_user.present?
      @chats = current_user.chats.all.order('created_at DESC')
    end
    
    # UserMailer.send_mail(@user).deliver_now
  end
  
  def chat
    
    @user = User.find(current_user.id)
    if current_user.present?
      
      if current_user.id == params[:id].to_i
      else
        flash[:danger] = 'アクセスできません'
        redirect_to root_path
      end
      
    else
      flash[:danger] = 'アクセスできません'
      redirect_to root_path
    end
    @chats = current_user.chats.all.order('created_at DESC')
  end

  def new
    @user = User.new
  end

  def create
    @user = User.new(user_params)
    if @user.save
      flash[:success] = 'ユーザを登録しました。'
      redirect_to login_path
    else
      flash.now[:danger] = 'ユーザの登録に失敗しました。'
      render :new
    end
    
  end
  
  def edit
    @user = current_user
  end
  
  def update
    @user = User.find(params[:id])
    if @user.update_attributes(user_params)
      flash[:success] = '編集を保存しました。'
      redirect_to @user
    else
      flash.now[:danger] = '編集の保存に失敗しました。'
      redirect_to :back
    end
  end
  
  def profile_edit
    @user = current_user
  end

  
  private

  def user_params
    params.require(:user).permit(:email, :password, :password_confirmation,:last_name,:first_name,:phonetic_last_name,:phonetic_first_name,:sex,:prefectures,:address,:street_address,:building_name,:career,:score,:self_introduction,:birth_year,:birth_month,:birth_day,:phone_number,:default,:postal_code,:name)
  end
  
end
