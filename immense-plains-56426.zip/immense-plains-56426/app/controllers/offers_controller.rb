class OffersController < ApplicationController
  before_action :get_notification, except: [:destroy,:show]
  before_action :require_company_logged_in,only: [:new,:create,:edit,:destroy]
  def new
    @offer = Offer.new
    @offer_tags = OfferTag.all
  end
  
  def create
    @offer = current_company.offers.new(offer_params)
        
    if @offer.save
      
      for offer_tag_id in params[:offer][:offer_tags] do 
        OfferOffertag.create(offer_id: @offer.id, offer_tag_id: offer_tag_id)
      end
      
      flash[:success] = '募集を作成しました。'
      # params[:q][:offer_tags_id_in]これでタグのidが取得できる(配列）
        
      redirect_to root_path
    else
      flash.now[:danger] = '作成に失敗しました。'
      render :new
    end
    
    # rescue => e
    # flash[:danger] = 'エラーが発生しました'
    # redirect_to root_path
    
  end
  
  def show
    @offer = Offer.find(params[:id])
    @offers = Offer.all.limit(5)
  end
  
  def index
    @search = Offer.ransack(params[:q])
    @offers = @search.result.page(params[:page]).per(10)
    @count = @search.result.includes(:offer_tags).count
    @offer_tags = OfferTag.all
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
    if params[:q][:others].present?
      byebug
    else
    end
  end
  
  def search
    @search = Offer.ransack(params[:q])
    @offers = @search.result.includes(:offer_tags).order('created_at DESC').page(params[:page]).per(10)
    @count = @search.result.includes(:offer_tags).count
    @offer_tags = OfferTag.all
    @sidemenu_offers = Offer.all.order('created_at DESC').limit(5)
  end
  
  def edit
    @offer = Offer.find(params[:id])
    @offer_tags = OfferTag.all
  end
  
  def update
    @offer = Offer.find(params[:id])
    if @offer.update_attributes(offer_params)
      OfferOffertag.where(offer_id: @offer.id).destroy_all
      
      for offer_tag_id in params[:offer][:offer_tags] do 
        OfferOffertag.create(offer_id: @offer.id, offer_tag_id: offer_tag_id)
      end
      
      flash[:success] = '編集を保存しました。'
      redirect_to @offer
    else
      flash.now[:danger] = '募集の保存に失敗しました。'
      redirect_to :back
    end
  end
  
  def destroy
    @offer = Offer.find(params[:id])
    if @offer.destroy
      flash[:success] = '削除に成功しました'
      redirect_to current_company
    else
      flash[:danger] = '削除に失敗しました'
      redirect_to current_company
    end
  end
  
  
  private
  
  def offer_params
    params.require(:offer).permit(:title,:offer_image,:content,:job,:holiday,:treatment,:office_hours,:work_location,:access,:employment_status,:feature,:qualification,:allowance_lowest,:allowance_highest,:game_title)
  end
  
  def search_params
    params.require(:q).permit(:content_cont,:title_cont,:game_title_cont,:job_cont,:holiday_cont,:treatment_cont,:office_hours_cont,:work_location_cont,:work_location_not_cont,:access_cont,:employment_status_cont,:feature_cont,:qualification_cont,:allowance_lowest_gteq,:allowance_highest_lteq)
  end
  
end

  