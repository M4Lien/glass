class ApplicationController < ActionController::Base
  before_action :get_notification
  protect_from_forgery with: :exception
  
  include SessionsHelper
  
  # rescue_from StandardError, with: :render_500 unless Rails.env.development?
  # rescue_from StandardError, with: :render_500
  rescue_from NoMethodError, with: :render_404 unless Rails.env.development?
  # rescue_from NoMethodError, with: :render_404

  def render_404(e = nil)
    if e
      logger.error e 
      logger.error e.backtrace.join("\n") 
    end
    
    flash[:danger] = 'エラーが発生しました'
    redirect_to root_path
  end
  
  def render_500(e = nil)
    if e
      logger.error e 
      logger.error e.backtrace.join("\n") 
    end
    flash[:danger] = 'エラーが発生しました'
    redirect_to root_path
  end
  
  
  
  private

  def require_user_logged_in
    unless logged_in?
      redirect_to login_url
    end
  end
  
  def require_company_logged_in
    unless company_logged_in?
      redirect_to root_path
    end
  end  
  
  def company_or_the_person
    
    if company_logged_in? || current_user == User.find(params[:id])
      
    else
       flash[:danger] = 'アクセスできません'
       redirect_to root_path
    end
  end
  
  def the_company
    @the_company = false
    if current_company.present || current_company == Company.find(params[:id])
      @the_company = true
      return @the_company
    else
      return @the_company
    end
  end
  
  def require_the_company
    
    if current_company.present?
      if current_company == Company.find(params[:id])
      else
        flash[:danger] = '表示できません'
        redirect_to root_path
      end
    else
      flash[:danger] = '表示できません'
      redirect_to root_path
    end
  end
  
  def require_the_user
    
    if current_user.present?
      if current_user == User.find(params[:id])
      else
        flash[:danger] = '表示できません'
        redirect_to root_path
      end
    elsif current_company.present?
    else
      flash[:danger] = '表示できません'
      redirect_to root_path
    end
  end
  
  def get_notification
    
    @notification = false
    all_chats = []

    if current_user.present?
      user_notification_column = current_user.chats.pluck(:user_notification)
       @notification_count = 0
      for boolean in user_notification_column
        if boolean
          @notification_count += 1
        else
        end
      end
      @notification = user_notification_column.include?(true)
      
      return @notification,@notification_count
      
    elsif current_company.present? then
      @company_chats = Chat.where(company_id: current_company.id)
      company_notification_column = @company_chats.pluck(:company_notification)
      @notification_count = 0
      for boolean in company_notification_column
        if boolean
          @notification_count += 1
        else
        end
      end
      @notification = company_notification_column.include?(true)
      return @notification,@notification_count
    
    else 
      return @notification
    end
    
  end
  
  
end
