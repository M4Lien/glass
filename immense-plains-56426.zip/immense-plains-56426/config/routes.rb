Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root to: 'toppages#index'
  # root to: 'offers#index'
  get 'search', to: 'offers#search'
  
  get 'login', to: 'sessions#new'
  post 'login', to: 'sessions#create'
  delete 'logout', to: 'sessions#destroy'
  
  
  get 'company_login', to: 'sessions#company_new'
  post 'company_login', to: 'sessions#company_create'
  delete 'company_logout', to: 'sessions#company_destroy'
  get 'company_signup', to: 'companies#new'
  resources :companies, only: [:index, :show, :new, :create]
  get 'companies/:id/offer', to: 'companies#offer'
  get 'companies/:id/chat', to: 'companies#chat'
  
  get 'signup', to: 'users#new'
  resources :users, only: [:index, :show, :new, :create,:edit,:update]
  get 'users/:id/chat', to: 'users#chat'
  
  
  resources :companies
  resources :offers
  resources :offer_tags
  
  get 'offers/:id/chats', to: 'chats#create'
  post 'offers/:id/chats', to: 'comments#create'
  
  post 'chats/:id/send_comment', to: 'chats#send_comment'
  
  resources :chats
  resources :comments
  
  get 'search/prefecture', to: 'search#prefecture'
  get 'search/menu1', to: 'search#menu1'
  get 'search/menu2', to: 'search#menu2'
  get 'search/menu3', to: 'search#menu3'
  get 'search/menu5', to: 'search#menu5'
  
  post 'chats/:id/adopt' => 'chats#adopt'
  
  get 'toppage/form', to: 'toppages#form'
  get 'offers/edit/:id', to: 'offers#edit'
  
  get 'terms_of_service', to: 'toppages#terms_of_service'
  
  get 'users/:id/profile_edit', to: 'users#profile_edit'
  get 'companies/:id/profile_edit', to: 'companies#profile_edit'
  
end
