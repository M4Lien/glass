<?php
/**
 * login
 *
 * PHP version 5
 *
 * @category  PHP
 * @package   Universal_Form_Builder
 * @author    Softdiscover <info@softdiscover.com>
 * @copyright 2013 Softdiscover
 * @license   http://www.php.net/license/3_01.txt  PHP License 3.01
 * @version   CVS: $Id: index.php, v1.20 2014-04-28 02:52:40 Softdiscover $
 * @link      http://universal-form-builder.softdiscover.com/
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
?>
hi, copy & paste the url or just click on next:

<a href="<?php echo site_url(); ?>default/intranet/changepassword/<?php echo $token;?>"><?php echo site_url(); ?>default/intranet/changepassword/<?php echo $token;?></a> 
	
