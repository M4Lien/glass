<form class="rockfm-form" 
      action="" 
      name="" 
      method="post" 
      enctype="multipart/form-data" 
      id="rockfm_form_1">

    
    <input type="hidden" value="1" id="_rockfm_form_id" name="_rockfm_form_id">
    <div class="space10"></div>
    <div class="rockfm-fields-wrap" 
         id="rockfm_form_1_fields_wrap">
        <?php echo $html_textbox;?>
        <a href="javascript:void(0);" onclick="javascript:rocketfm.submitForm(this,'1');return false;">Send</a>
        <!--<input type="submit" 
               rel="5" 
               value="Send" 
               id=""
               onclick="javascript:rocketfm.submitForm(this,'rockfm_form_1');return false;"
               class="rockfm_field_20" 
               name="_rockfm_field_20">-->
    </div>
</form>