<?php
/**
 * Intranet
 *
 * PHP version 5
 *
 * @category  PHP
 * @package   Rocket_form
 * @author    Softdiscover <info@softdiscover.com>
 * @copyright 2015 Softdiscover
 * @license   http://www.php.net/license/3_01.txt  PHP License 3.01
 * @link      http://www.zigaform.com/wordpress-form-builder
 */
if (!defined('BASEPATH')) {exit('No direct script access allowed');}
ob_start();
?>
<?php 
$id_field=(!empty($id_field))?$id_field:'';
?>
<div id="<?php echo $id_field;?>" data-typefield="1" data-iscontainer="1" class="uiform-gridsytem-table uiform-gridsystem-one uiform-field">
        <div class="uiform-field-wrap uiform-field-move">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tr>
                        <td  data-maxpercent="100" data-blocks="12" width="100%">
                            <div class="uiform-items-container uiform-grid-inner-col">
                                
                            </div>
                        </td>   
                    </tr>
            </table>
            
          <?php echo $quick_options;?>
       </div>
    </div>
<?php
$cntACmp = ob_get_contents();
/*$cntACmp = str_replace("\n", '', $cntACmp);
$cntACmp = str_replace("\t", '', $cntACmp);
$cntACmp = str_replace("\r", '', $cntACmp);
$cntACmp = str_replace("//-->", ' ', $cntACmp);
$cntACmp = str_replace("//<!--", ' ', $cntACmp);
$cntACmp = Uiform_Form_Helper::sanitize_output($cntACmp);*/
ob_end_clean();
echo $cntACmp;
?>
